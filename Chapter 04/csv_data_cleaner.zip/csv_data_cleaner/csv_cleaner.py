# csv_cleaner.py
import os
import re
import yaml
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Any, Tuple, Optional, Union


class CSVCleaner:
    """A configurable tool for cleaning and validating CSV data."""
    
    def __init__(self, config_path: str):
        """Initialize the cleaner with a configuration file."""
        with open(config_path, "r") as f:
            self.config = yaml.safe_load(f)
        
        self.input_file = self.config["input_file"]
        self.output_file = self.config["output_file"]
        self.report_file = self.config["report_file"]
        self.columns = self.config["columns"]
        self.global_transformations = self.config.get("global_transformations", [])
        
        self.original_df = None
        self.cleaned_df = None
        self.report = []
        
    def log(self, message: str) -> None:
        """Add a message to the report."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.report.append(f"[{timestamp}] {message}")
        print(message)
    
    def load_data(self) -> None:
        """Load data from the input file."""
        self.log(f"Loading data from {self.input_file}")
        
        try:
            self.original_df = pd.read_csv(self.input_file)
            self.cleaned_df = self.original_df.copy()
            self.log(f"Loaded {len(self.original_df)} rows and {len(self.original_df.columns)} columns")
        except Exception as e:
            self.log(f"Error loading data: {str(e)}")
            raise
    
    def check_required_columns(self) -> None:
        """Check if all required columns are present."""
        self.log("Checking required columns")
        
        missing_columns = []
        for col_name, col_config in self.columns.items():
            if col_config.get("required", False) and col_name not in self.cleaned_df.columns:
                missing_columns.append(col_name)
        
        if missing_columns:
            self.log(f"Missing required columns: {', '.join(missing_columns)}")
            raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")
        
        self.log("All required columns are present")
    
    def apply_column_transformations(self) -> None:
        """Apply transformations to individual columns."""
        self.log("Applying column transformations")
        
        for col_name, col_config in self.columns.items():
            if col_name not in self.cleaned_df.columns:
                self.log(f"Column '{col_name}' not found, skipping transformations")
                continue
            
            transformations = col_config.get("transformations", [])
            if not transformations:
                continue
            
            self.log(f"Transforming column: {col_name}")
            
            # Get column type
            col_type = col_config.get("type", "string")
            
            # Apply transformations
            for transform in transformations:
                if isinstance(transform, str):
                    transform_name = transform
                    transform_args = {}
                else:
                    transform_name = list(transform.keys())[0]
                    transform_args = transform[transform_name]
                
                self.log(f"  - Applying {transform_name} to {col_name}")
                
                # String transformations
                if transform_name == "strip_whitespace" and col_type == "string":
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(str).str.strip()
                
                elif transform_name == "lowercase" and col_type == "string":
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(str).str.lower()
                
                elif transform_name == "uppercase" and col_type == "string":
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(str).str.upper()
                
                elif transform_name == "title_case" and col_type == "string":
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(str).str.title()
                
                # Numeric transformations
                elif transform_name == "remove_currency" and col_type in ["float", "int"]:
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(str).str.replace(r'[$,]', '', regex=True)
                    self.cleaned_df[col_name] = pd.to_numeric(self.cleaned_df[col_name], errors="coerce")
                
                # Date transformations
                elif transform_name == "standardize_date" and col_type == "date":
                    date_format = col_config.get("format", "%Y-%m-%d")
                    self.cleaned_df[col_name] = pd.to_datetime(self.cleaned_df[col_name], errors="coerce")
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].dt.strftime(date_format)
                
                else:
                    self.log(f"    Unknown transformation: {transform_name} for type {col_type}")
        
        self.log("Column transformations completed")
    
    def apply_global_transformations(self) -> None:
        """Apply global transformations to the entire DataFrame."""
        self.log("Applying global transformations")
        
        for transform in self.global_transformations:
            if isinstance(transform, str):
                transform_name = transform
                transform_args = {}
            else:
                transform_name = list(transform.keys())[0]
                transform_args = transform[transform_name]
            
            self.log(f"  - Applying {transform_name}")
            
            # Handle duplicates
            if transform_name == "drop_duplicates":
                subset = transform_args.get("subset")
                keep = transform_args.get("keep", "first")
                
                before_count = len(self.cleaned_df)
                self.cleaned_df = self.cleaned_df.drop_duplicates(subset=subset, keep=keep)
                after_count = len(self.cleaned_df)
                
                self.log(f"    Removed {before_count - after_count} duplicate rows")
            
            # Handle missing values
            elif transform_name == "handle_missing":
                strategies = transform_args.get("strategies", {})
                
                for col, strategy in strategies.items():
                    if col not in self.cleaned_df.columns:
                        self.log(f"    Column '{col}' not found, skipping")
                        continue
                    
                    missing_count = self.cleaned_df[col].isna().sum()
                    
                    if strategy == "drop":
                        before_count = len(self.cleaned_df)
                        self.cleaned_df = self.cleaned_df.dropna(subset=[col])
                        after_count = len(self.cleaned_df)
                        self.log(f"    Dropped {before_count - after_count} rows with missing values in '{col}'")
                    
                    elif strategy == "mean":
                        if pd.api.types.is_numeric_dtype(self.cleaned_df[col]):
                            mean_value = self.cleaned_df[col].mean()
                            self.cleaned_df[col] = self.cleaned_df[col].fillna(mean_value)
                            self.log(f"    Filled {missing_count} missing values in '{col}' with mean: {mean_value:.2f}")
                        else:
                            self.log(f"    Cannot apply mean strategy to non-numeric column '{col}'")
                    
                    elif strategy == "median":
                        if pd.api.types.is_numeric_dtype(self.cleaned_df[col]):
                            median_value = self.cleaned_df[col].median()
                            self.cleaned_df[col] = self.cleaned_df[col].fillna(median_value)
                            self.log(f"    Filled {missing_count} missing values in '{col}' with median: {median_value:.2f}")
                        else:
                            self.log(f"    Cannot apply median strategy to non-numeric column '{col}'")
                    
                    elif strategy == "mode":
                        mode_value = self.cleaned_df[col].mode()[0]
                        self.cleaned_df[col] = self.cleaned_df[col].fillna(mode_value)
                        self.log(f"    Filled {missing_count} missing values in '{col}' with mode: {mode_value}")
                    
                    elif strategy == "constant":
                        value_key = f"{col}_value"
                        constant_value = transform_args.get(value_key, "")
                        self.cleaned_df[col] = self.cleaned_df[col].fillna(constant_value)
                        self.log(f"    Filled {missing_count} missing values in '{col}' with constant: {constant_value}")
                    
                    else:
                        self.log(f"    Unknown missing value strategy: {strategy} for column '{col}'")
        
        self.log("Global transformations completed")
    
    def convert_data_types(self) -> None:
        """Convert columns to their specified data types."""
        self.log("Converting data types")
        
        for col_name, col_config in self.columns.items():
            if col_name not in self.cleaned_df.columns:
                continue
            
            col_type = col_config.get("type", "string")
            nullable = col_config.get("nullable", True)
            
            self.log(f"  - Converting {col_name} to {col_type}")
            
            try:
                if col_type == "int":
                    # Handle non-nullable columns
                    if not nullable:
                        # Fill missing values with 0 before conversion
                        self.cleaned_df[col_name] = self.cleaned_df[col_name].fillna(0)
                    
                    self.cleaned_df[col_name] = pd.to_numeric(self.cleaned_df[col_name], errors="coerce")
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(pd.Int64Dtype())
                
                elif col_type == "float":
                    # Handle non-nullable columns
                    if not nullable:
                        # Fill missing values with 0.0 before conversion
                        self.cleaned_df[col_name] = self.cleaned_df[col_name].fillna(0.0)
                    
                    self.cleaned_df[col_name] = pd.to_numeric(self.cleaned_df[col_name], errors="coerce")
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(float)
                
                elif col_type == "boolean":
                    # Handle non-nullable columns
                    if not nullable:
                        # Fill missing values with False before conversion
                        self.cleaned_df[col_name] = self.cleaned_df[col_name].fillna(False)
                    
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(bool)
                
                elif col_type == "date":
                    date_format = col_config.get("format", "%Y-%m-%d")
                    
                    # Handle non-nullable columns
                    if not nullable:
                        # Fill missing dates with today's date
                        today = datetime.now().strftime(date_format)
                        self.cleaned_df[col_name] = self.cleaned_df[col_name].fillna(today)
                    
                    self.cleaned_df[col_name] = pd.to_datetime(
                        self.cleaned_df[col_name], 
                        errors="coerce", 
                        format=date_format
                    )
                
                elif col_type == "string":
                    # Handle non-nullable columns
                    if not nullable:
                        # Fill missing strings with empty string
                        self.cleaned_df[col_name] = self.cleaned_df[col_name].fillna("")
                    
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].astype(str)
                    # Replace 'nan' strings with empty strings
                    self.cleaned_df[col_name] = self.cleaned_df[col_name].replace("nan", "")
                
                else:
                    self.log(f"    Unknown column type: {col_type}")
            
            except Exception as e:
                self.log(f"    Error converting {col_name} to {col_type}: {str(e)}")
        
        self.log("Data type conversion completed")
    
    def validate_data(self) -> Tuple[bool, List[str]]:
        """Validate the data against the defined rules."""
        self.log("Validating data")
        
        all_valid = True
        validation_errors = []
        
        for col_name, col_config in self.columns.items():
            if col_name not in self.cleaned_df.columns:
                continue
            
            validations = col_config.get("validations", [])
            if not validations:
                continue
            
            self.log(f"  - Validating column: {col_name}")
            
            for validation in validations:
                if isinstance(validation, str):
                    validation_name = validation
                    validation_args = {}
                else:
                    validation_name = list(validation.keys())[0]
                    validation_args = validation[validation_name]
                
                self.log(f"    - Applying {validation_name}")
                
                # Email format validation
                if validation_name == "email_format":
                    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
                    mask = ~self.cleaned_df[col_name].str.match(email_pattern)
                    invalid_count = mask.sum()
                    
                    if invalid_count > 0:
                        all_valid = False
                        error = f"Column '{col_name}' has {invalid_count} values that are not valid email addresses"
                        validation_errors.append(error)
                        self.log(f"      FAIL: {error}")
                    else:
                        self.log(f"      PASS: All values in '{col_name}' are valid email addresses")
                
                # Range validation
                elif validation_name == "range":
                    min_val = validation_args.get("min")
                    max_val = validation_args.get("max")
                    
                    if min_val is not None:
                        mask = self.cleaned_df[col_name] < min_val
                        invalid_count = mask.sum()
                        
                        if invalid_count > 0:
                            all_valid = False
                            error = f"Column '{col_name}' has {invalid_count} values less than minimum ({min_val})"
                            validation_errors.append(error)
                            self.log(f"      FAIL: {error}")
                        else:
                            self.log(f"      PASS: All values in '{col_name}' are >= {min_val}")
                    
                    if max_val is not None:
                        mask = self.cleaned_df[col_name] > max_val
                        invalid_count = mask.sum()
                        
                        if invalid_count > 0:
                            all_valid = False
                            error = f"Column '{col_name}' has {invalid_count} values greater than maximum ({max_val})"
                            validation_errors.append(error)
                            self.log(f"      FAIL: {error}")
                        else:
                            self.log(f"      PASS: All values in '{col_name}' are <= {max_val}")
                
                # Allowed values validation
                elif validation_name == "allowed_values":
                    allowed = validation_args.get("values", [])
                    mask = ~self.cleaned_df[col_name].isin(allowed)
                    invalid_count = mask.sum()
                    
                    if invalid_count > 0:
                        all_valid = False
                        error = f"Column '{col_name}' has {invalid_count} values not in allowed set: {', '.join(allowed)}"
                        validation_errors.append(error)
                        self.log(f"      FAIL: {error}")
                    else:
                        self.log(f"      PASS: All values in '{col_name}' are in the allowed set")
                
                # Regex pattern validation
                elif validation_name == "regex_pattern":
                    pattern = validation_args.get("pattern", "")
                    mask = ~self.cleaned_df[col_name].astype(str).str.match(pattern)
                    invalid_count = mask.sum()
                    
                    if invalid_count > 0:
                        all_valid = False
                        error = f"Column '{col_name}' has {invalid_count} values that don't match pattern '{pattern}'"
                        validation_errors.append(error)
                        self.log(f"      FAIL: {error}")
                    else:
                        self.log(f"      PASS: All values in '{col_name}' match the pattern")
                
                else:
                    self.log(f"      Unknown validation: {validation_name}")
        
        if all_valid:
            self.log("All validations passed")
        else:
            self.log(f"Validation failed with {len(validation_errors)} errors")
        
        return all_valid, validation_errors
    
    def save_cleaned_data(self) -> None:
        """Save the cleaned data to the output file."""
        self.log(f"Saving cleaned data to {self.output_file}")
        
        # Create directory if it doesn't exist
        output_dir = os.path.dirname(self.output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        try:
            self.cleaned_df.to_csv(self.output_file, index=False)
            self.log(f"Saved {len(self.cleaned_df)} rows to {self.output_file}")
        except Exception as e:
            self.log(f"Error saving data: {str(e)}")
            raise
    
    def save_report(self) -> None:
        """Save the cleaning report to a file."""
        self.log(f"Saving cleaning report to {self.report_file}")
        
        # Create directory if it doesn't exist
        report_dir = os.path.dirname(self.report_file)
        if report_dir and not os.path.exists(report_dir):
            os.makedirs(report_dir)
        
        try:
            with open(self.report_file, "w") as f:
                f.write("\n".join(self.report))
            self.log(f"Report saved to {self.report_file}")
        except Exception as e:
            self.log(f"Error saving report: {str(e)}")
            raise
    
    def run(self) -> bool:
        """Run the complete cleaning process."""
        try:
            # Load the data
            self.load_data()
            
            # Check required columns
            self.check_required_columns()
            
            # Apply transformations
            self.apply_column_transformations()
            self.apply_global_transformations()
            
            # Convert data types
            self.convert_data_types()
            
            # Validate the data
            all_valid, _ = self.validate_data()
            
            # Save the cleaned data and report
            self.save_cleaned_data()
            self.save_report()
            
            self.log("Cleaning process completed")
            return all_valid
        
        except Exception as e:
            self.log(f"Error during cleaning process: {str(e)}")
            self.save_report()
            return False


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python csv_cleaner.py <config_file>")
        sys.exit(1)
    
    config_file = sys.argv[1]
    
    cleaner = CSVCleaner(config_file)
    success = cleaner.run()
    
    if not success:
        print("Cleaning process completed with validation errors. See the report for details.")
        sys.exit(1)
    
    print("Cleaning process completed successfully.")