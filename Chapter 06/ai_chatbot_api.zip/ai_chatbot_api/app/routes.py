from fastapi import APIRouter, HTTPException, status, BackgroundTasks, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import uuid
import asyncio
import random

from app.services.websocket_manager import manager
from app.db.memory import conversations_db
from app.services.chat_service import (
    get_conversation,
    generate_bot_response,
    process_message_async
)

router = APIRouter()

class Message(BaseModel):
    id: Optional[str] = None
    role: str
    content: str
    created_at: Optional[datetime] = None

class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None

class ChatResponse(BaseModel):
    message: Message
    conversation_id: str
    conversation_history: List[Message]

@router.post("/chat", response_model=ChatResponse)
async def chat(chat_request: ChatRequest, background_tasks: BackgroundTasks):
    current_time = datetime.now()

    if chat_request.conversation_id:
        conversation = get_conversation(chat_request.conversation_id)
        conversation_id = chat_request.conversation_id
    else:
        conversation_id = str(uuid.uuid4())
        conversation = {
            "id": conversation_id,
            "messages": [],
            "created_at": current_time,
            "updated_at": current_time
        }
        conversations_db[conversation_id] = conversation

    user_message = {
        "id": str(uuid.uuid4()),
        "role": "user",
        "content": chat_request.message,
        "created_at": current_time
    }
    conversation["messages"].append(user_message)
    conversation["updated_at"] = current_time

    assistant_message = await process_message_async(conversation_id, chat_request.message)

    return ChatResponse(
        message=assistant_message,
        conversation_id=conversation_id,
        conversation_history=conversation["messages"]
    )
@router.get("/")
def read_root():
    return {"message": "Welcome to the AI Chatbot API"}
    
@router.get("/conversations/{conversation_id}", response_model=dict)
async def get_conversation_history(conversation_id: str):
    return get_conversation(conversation_id)

@router.delete("/conversations/{conversation_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_conversation(conversation_id: str):
    if conversation_id in conversations_db:
        del conversations_db[conversation_id]
    return None

@router.get("/healthcheck")
async def healthcheck():
    return {"status": "healthy", "timestamp": datetime.now()}

@router.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await manager.connect(websocket, client_id)
    try:
        while True:
            data = await websocket.receive_json()
            user_message = data.get("message", "")
            conversation_id = data.get("conversation_id")

            response = {
                "role": "assistant",
                "content": generate_bot_response(user_message),
                "timestamp": datetime.now().isoformat()
            }
            await manager.send_message(client_id, response)
    except WebSocketDisconnect:
        manager.disconnect(client_id)
