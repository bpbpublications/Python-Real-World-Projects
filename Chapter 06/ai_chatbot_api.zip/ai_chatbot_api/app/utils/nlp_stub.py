import random

SAMPLE_RESPONSES = {
    "hello": ["Hi there!", "Hello! How can I assist you?"],
    "python": ["Python is a great language for beginners and experts alike.", 
               "Python is known for its readability and versatility."],
    "fastapi": ["FastAPI is a high-performance Python web framework for APIs.", 
                "FastAPI simplifies building APIs with automatic docs and validation."],
    "help": ["Sure, I’m here to help. What do you need?", 
             "Ask me anything — I’ll do my best to assist!"]
}

DEFAULT_RESPONSES = [
    "I’m just a demo bot for now — real brains coming soon!",
    "Can you tell me a bit more so I can understand better?",
    "Interesting... Let me think about that.",
    "In a full version, I’d use a language model to help you better."
]

def generate_stub_response(user_message: str) -> str:
    user_message = user_message.lower()
    for keyword, responses in SAMPLE_RESPONSES.items():
        if keyword in user_message:
            return random.choice(responses)
    return random.choice(DEFAULT_RESPONSES)
