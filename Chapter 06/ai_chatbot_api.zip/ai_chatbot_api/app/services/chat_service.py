from fastapi import HTTPException
from datetime import datetime
import uuid
import asyncio
import random

from app.db.memory import conversations_db

SAMPLE_RESPONSES = {
    "hello": ["Hello! How can I help you today?", "Hi there! What can I assist you with?"],
    "python": ["Python is a powerful programming language loved for its simplicity.", 
               "Python is widely used in data science, automation, and web development."],
    "fastapi": ["FastAPI is a high-performance Python framework for APIs.", 
                "FastAPI makes API development fast and intuitive."],
    "help": ["I'm here to assist! Ask me anything about tech or coding.", 
             "Let me know how I can help you today."]
}

DEFAULT_RESPONSES = [
    "I'm a simple demo bot. In a real app, I'd use an NLP model.",
    "That's interesting. Can you elaborate a bit more?",
    "I'm trying to understand. Could you give more details?",
    "I'm a FastAPI-based demo bot. Try asking me about Python or FastAPI."
]

def get_conversation(conversation_id: str) -> dict:
    if conversation_id not in conversations_db:
        raise HTTPException(status_code=404, detail=f"Conversation with ID {conversation_id} not found")
    return conversations_db[conversation_id]

def generate_bot_response(user_message: str) -> str:
    lower_message = user_message.lower()
    for keyword, responses in SAMPLE_RESPONSES.items():
        if keyword in lower_message:
            return random.choice(responses)
    return random.choice(DEFAULT_RESPONSES)

async def process_message_async(conversation_id: str, user_message: str) -> dict:
    await asyncio.sleep(1)  # Simulate response time

    response_text = generate_bot_response(user_message)
    message_id = str(uuid.uuid4())
    current_time = datetime.now()

    assistant_message = {
        "id": message_id,
        "role": "assistant",
        "content": response_text,
        "created_at": current_time
    }

    conversation = conversations_db[conversation_id]
    conversation["messages"].append(assistant_message)
    conversation["updated_at"] = current_time

    return assistant_message

async def process_message_async(conversation_id: str, user_message: str) -> dict:
    await asyncio.sleep(1)  # Simulate response time

    response_text = generate_bot_response(user_message)
    message_id = str(uuid.uuid4())
    current_time = datetime.now()

    assistant_message = {
        "id": message_id,
        "role": "assistant",
        "content": response_text,
        "created_at": current_time
    }

    conversation = conversations_db[conversation_id]
    conversation["messages"].append(assistant_message)
    conversation["updated_at"] = current_time

    return assistant_message

