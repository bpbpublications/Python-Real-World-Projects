# This dictionary will act as our in-memory "database"
conversations_db = {}
