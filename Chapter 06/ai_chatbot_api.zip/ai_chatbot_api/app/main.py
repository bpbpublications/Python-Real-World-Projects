from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routes import router as api_router

app = FastAPI(
    title="AI Chatbot API",
    description="A simple AI chatbot API that demonstrates FastAPI features",
    version="1.0.0"
)

# Allow cross-origin requests (used by front-end apps)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Use specific origins in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all API routes
app.include_router(api_router)
