# Portfolio Website Images

This directory contains images for the portfolio website:

- profile.jpg - Professional headshot photo
- project-placeholder.jpg - Placeholder for project screenshots
- task_management_screenshot.png - Screenshot of task management system
- cloud_deployment_screenshot.png - Screenshot of cloud deployment blog
- advanced_web_app_screenshot.png - Screenshot of advanced web app
- og-image.jpg - Open Graph image for social media sharing
- favicon.ico - Website favicon

## Image Guidelines

- Profile images should be 300x300px minimum
- Project screenshots should be 800x600px minimum
- All images should be optimized for web use
- Use appropriate alt text for accessibility

