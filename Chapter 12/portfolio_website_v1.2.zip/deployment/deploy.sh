#!/bin/bash

# Portfolio Website Deployment Script
# Supports multiple deployment platforms

set -e

echo "🚀 Portfolio Website Deployment Script"
echo "======================================"

# Function to deploy to Vercel
deploy_vercel() {
    echo "📦 Deploying to Vercel..."
    
    # Check if Vercel CLI is installed
    if ! command -v vercel &> /dev/null; then
        echo "❌ Vercel CLI not found. Installing..."
        npm install -g vercel
    fi
    
    # Copy deployment files
    cp deployment/vercel.json ./
    
    # Deploy to Vercel
    vercel --prod
    
    echo "✅ Deployed to Vercel successfully!"
}

# Function to deploy to Heroku
deploy_heroku() {
    echo "🔧 Deploying to Heroku..."
    
    # Check if Heroku CLI is installed
    if ! command -v heroku &> /dev/null; then
        echo "❌ Heroku CLI not found. Please install it first."
        exit 1
    fi
    
    # Copy deployment files
    cp deployment/Procfile ./
    cp deployment/runtime.txt ./
    
    # Create Heroku app if it doesn't exist
    read -p "Enter Heroku app name: " app_name
    heroku create $app_name || true
    
    # Deploy to Heroku
    git add .
    git commit -m "Deploy to Heroku" || true
    git push heroku main
    
    echo "✅ Deployed to Heroku successfully!"
}

# Function to deploy to traditional hosting
deploy_traditional() {
    echo "🌐 Preparing for traditional hosting..."
    
    # Create deployment package
    mkdir -p dist
    
    # Copy application files
    cp -r templates dist/
    cp -r static dist/
    cp app.py dist/
    cp requirements.txt dist/
    cp README.md dist/
    
    # Create .htaccess for Apache
    cat > dist/.htaccess << 'EOF'
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ app.py/$1 [QSA,L]
EOF
    
    # Create deployment instructions
    cat > dist/DEPLOYMENT_INSTRUCTIONS.md << 'EOF'
# Traditional Hosting Deployment

## Requirements
- Python 3.8+
- Web server with Python support (Apache/Nginx)
- SSL certificate (recommended)

## Setup Steps
1. Upload all files to your web server
2. Install Python dependencies: `pip install -r requirements.txt`
3. Configure your web server to serve the Flask application
4. Set up SSL certificate
5. Configure environment variables

## Environment Variables
- Set SECRET_KEY for production
- Configure database URL if using external database
- Set FLASK_ENV=production

## Web Server Configuration
See your hosting provider's documentation for Python/Flask setup.
EOF
    
    echo "✅ Traditional hosting package created in 'dist' folder!"
}

# Main menu
echo "Select deployment target:"
echo "1. Vercel (Recommended)"
echo "2. Heroku"
echo "3. Traditional Hosting"
echo "4. Exit"

read -p "Enter your choice (1-4): " choice

case $choice in
    1)
        deploy_vercel
        ;;
    2)
        deploy_heroku
        ;;
    3)
        deploy_traditional
        ;;
    4)
        echo "👋 Goodbye!"
        exit 0
        ;;
    *)
        echo "❌ Invalid choice. Please select 1-4."
        exit 1
        ;;
esac

echo ""
echo "🎉 Deployment completed!"
echo "💡 Don't forget to:"
echo "   - Test your deployed application"
echo "   - Configure custom domain (if needed)"
echo "   - Set up analytics and monitoring"
echo "   - Update your resume and social media links"