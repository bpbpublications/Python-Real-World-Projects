"""
Complete Portfolio Website - Flask Application
A professional portfolio showcasing Python web development projects

Features:
- Responsive design with Bootstrap 5
- Project showcase with detailed pages
- Skills and experience sections
- Contact form functionality
- Blog/Articles section
- GitHub integration
- SEO optimization
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, Response
from datetime import datetime
import os
import json

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'portfolio-secret-key-change-in-production')

# Portfolio data - In a real application, this would come from a database
PORTFOLIO_DATA = {
    'personal_info': {
        'name': 'Alex Johnson',
        'title': 'Python Web Developer',
        'bio': 'Passionate Python developer with expertise in web development, data analysis, and machine learning. Experienced in building scalable web applications using Flask, FastAPI, and modern frontend technologies.',
        'location': 'San Francisco, CA',
        'email': 'alex.johnson@example.com',
        'phone': '+1 (555) 123-4567',
        'github': 'https://github.com/alexjohnson',
        'linkedin': 'https://linkedin.com/in/alexjohnson',
        'twitter': 'https://twitter.com/alexjohnson',
        'resume_url': '/static/files/alex_johnson_resume.pdf'
    },
    'skills': {
        'programming_languages': ['Python', 'JavaScript', 'HTML/CSS', 'SQL', 'TypeScript'],
        'frameworks': ['Flask', 'FastAPI', 'Django', 'React', 'Bootstrap', 'Tailwind CSS'],
        'databases': ['PostgreSQL', 'MongoDB', 'SQLite', 'Redis'],
        'tools': ['Git', 'Docker', 'AWS', 'Heroku', 'Vercel', 'VS Code'],
        'specialties': ['Web Development', 'API Design', 'Database Design', 'UI/UX', 'Data Analysis']
    },
    'experience': [
        {
            'title': 'Senior Python Developer',
            'company': 'Tech Innovations Inc.',
            'period': '2023 - Present',
            'description': 'Lead development of web applications using Flask and FastAPI. Mentor junior developers and architect scalable solutions.',
            'achievements': [
                'Built 5+ production web applications serving 10,000+ users',
                'Reduced application response time by 40% through optimization',
                'Implemented CI/CD pipelines improving deployment efficiency by 60%'
            ]
        },
        {
            'title': 'Web Developer',
            'company': 'Digital Solutions LLC',
            'period': '2022 - 2023',
            'description': 'Developed full-stack web applications and RESTful APIs using Python and JavaScript.',
            'achievements': [
                'Created responsive web interfaces with modern JavaScript frameworks',
                'Designed and implemented RESTful APIs with comprehensive documentation',
                'Collaborated with design team to improve user experience'
            ]
        }
    ],
    'education': [
        {
            'degree': 'Bachelor of Science in Computer Science',
            'institution': 'University of California, Berkeley',
            'period': '2018 - 2022',
            'gpa': '3.8/4.0',
            'relevant_coursework': ['Data Structures', 'Algorithms', 'Database Systems', 'Software Engineering', 'Web Development']
        }
    ]
}

# Projects data - showcasing the course projects
PROJECTS_DATA = {
    'task_management': {
        'id': 'task_management',
        'title': 'Task Management System',
        'subtitle': 'Chapter 10 - Flask Web Application',
        'description': 'A comprehensive task management system built with Flask, featuring user authentication, task categories, and real-time updates.',
        'long_description': '''This full-featured task management system demonstrates advanced Flask development techniques including user authentication, database design, and responsive web interfaces. The application provides a complete solution for managing tasks with categories, priorities, and due dates.

Key features include secure user registration and login, task creation and editing with rich form validation, category management for organization, search and filtering capabilities, and a responsive Bootstrap interface that works on all devices.

The technical implementation showcases Flask-SQLAlchemy for database operations, Flask-Login for session management, Flask-WTF for form handling and CSRF protection, and comprehensive error handling with custom error pages.''',
        'technologies': ['Flask', 'SQLAlchemy', 'Bootstrap 5', 'SQLite', 'Flask-Login', 'Flask-WTF'],
        'features': [
            'User authentication and authorization',
            'Task CRUD operations with categories',
            'Search and filtering functionality',
            'Responsive Bootstrap 5 interface',
            'Form validation and error handling',
            'Database relationship management'
        ],
        'github_url': 'https://github.com/alexjohnson/task-management-system',
        'live_url': 'http://localhost:5000',
        'screenshot': '/static/img/task_management_screenshot.png',
        'code_snippet': '''@app.route('/tasks', methods=['GET', 'POST'])
@login_required
def tasks():
    """List all tasks with filtering and search"""
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    status = request.args.get('status', '')
    
    query = Task.query.filter_by(user_id=current_user.id)
    
    if search:
        query = query.filter(Task.title.contains(search))
    if category:
        query = query.filter_by(category_id=category)
    if status:
        query = query.filter_by(status=status)
    
    tasks = query.order_by(Task.created_at.desc()).all()
    categories = Category.query.all()
    
    return render_template('tasks.html', 
                         tasks=tasks, 
                         categories=categories,
                         search=search,
                         selected_category=category,
                         selected_status=status)''',
        'lessons_learned': [
            'Flask application structure and organization',
            'Database design with SQLAlchemy relationships',
            'User authentication and session management',
            'Form handling and validation techniques',
            'Responsive web design principles'
        ],
        'chapter': 'Chapter 10',
        'completion_date': '2025-07-15'
    },
    'cloud_deployment': {
        'id': 'cloud_deployment',
        'title': 'Cloud Deployment Blog',
        'subtitle': 'Chapter 11 - Cloud-Ready Flask Application',
        'description': 'A blog application designed for cloud deployment with support for multiple cloud platforms including Google App Engine and Heroku.',
        'long_description': '''This cloud-ready blog application demonstrates best practices for deploying Flask applications to major cloud platforms. The project includes comprehensive deployment configurations and demonstrates how to structure applications for scalability and maintainability in cloud environments.

The application features a complete blog management system with post creation, editing, and publishing capabilities. It includes search functionality, responsive design, and RESTful API endpoints for programmatic access.

Technical highlights include configuration management for different environments, deployment scripts for Google App Engine and Heroku, Docker containerization support, and comprehensive logging and monitoring setup.''',
        'technologies': ['Flask', 'Bootstrap 5', 'Google App Engine', 'Heroku', 'Docker', 'SQLite'],
        'features': [
            'Multi-cloud deployment support',
            'Blog post management system',
            'Search and filtering capabilities',
            'RESTful API endpoints',
            'Responsive design with Bootstrap 5',
            'Environment-specific configurations'
        ],
        'github_url': 'https://github.com/alexjohnson/cloud-deployment-blog',
        'live_url': 'http://localhost:5002',
        'screenshot': '/static/img/cloud_deployment_screenshot.png',
        'code_snippet': '''# app.yaml - Google App Engine configuration
runtime: python39

handlers:
- url: /static
  static_dir: static

- url: /.*
  script: auto

env_variables:
  SECRET_KEY: your-secret-key-here
  DATABASE_URL: sqlite:///blog.db

automatic_scaling:
  min_instances: 1
  max_instances: 10
  target_cpu_utilization: 0.6''',
        'lessons_learned': [
            'Cloud deployment strategies and configurations',
            'Environment management and configuration',
            'Scalability considerations for web applications',
            'Platform-specific deployment requirements',
            'Monitoring and logging in cloud environments'
        ],
        'chapter': 'Chapter 11',
        'completion_date': '2025-07-15'
    },
    'advanced_web_app': {
        'id': 'advanced_web_app',
        'title': 'Advanced Web Application',
        'subtitle': 'Chapter 12 - Real-time Features & Authentication',
        'description': 'A sophisticated web application with real-time chat, user authentication, blog management, and comprehensive API endpoints.',
        'long_description': '''This advanced web application represents the culmination of modern Flask development techniques, incorporating real-time communication, comprehensive authentication systems, and sophisticated user interfaces. The application demonstrates enterprise-level features including WebSocket integration, role-based access control, and comprehensive API development.

The real-time chat system supports multiple rooms, online presence indicators, and typing notifications. The authentication system includes secure user registration, login, and role-based permissions with admin panel functionality.

The technical architecture showcases Flask-SocketIO for real-time communication, Flask-Login for session management, comprehensive error handling, and modern JavaScript for enhanced user experience. The application includes progressive web app features and accessibility compliance.''',
        'technologies': ['Flask', 'Flask-SocketIO', 'WebSocket', 'Bootstrap 5', 'JavaScript', 'SQLAlchemy'],
        'features': [
            'Real-time chat with WebSocket support',
            'User authentication and role-based access',
            'Blog management with comments and likes',
            'Admin panel with user management',
            'RESTful API with authentication',
            'Progressive web app features'
        ],
        'github_url': 'https://github.com/alexjohnson/advanced-web-app',
        'live_url': 'http://localhost:5003',
        'screenshot': '/static/img/advanced_web_app_screenshot.png',
        'code_snippet': '''@socketio.on('send_message')
def handle_send_message(data):
    """Handle real-time message sending"""
    if not current_user.is_authenticated:
        return False
    
    room = data.get('room')
    message = data.get('message', '').strip()
    
    if not message or len(message) > 500:
        return False
    
    # Save message to database
    chat_message = ChatMessage(
        content=message,
        room_id=room,
        user_id=current_user.id,
        message_type='text'
    )
    db.session.add(chat_message)
    db.session.commit()
    
    # Emit to room
    emit('receive_message', {
        'message': message,
        'username': current_user.username,
        'timestamp': datetime.utcnow().isoformat(),
        'user_id': current_user.id
    }, room=room)''',
        'lessons_learned': [
            'Real-time web application development',
            'WebSocket implementation with Flask-SocketIO',
            'Advanced authentication and authorization',
            'Progressive web app development',
            'Enterprise-level error handling and logging'
        ],
        'chapter': 'Chapter 12',
        'completion_date': '2025-07-15'
    }
}

# Blog articles data
ARTICLES_DATA = [
    {
        'id': 'flask_best_practices',
        'title': 'Flask Best Practices for Production Applications',
        'excerpt': 'Learn essential patterns and practices for building scalable Flask applications ready for production deployment.',
        'content': '''Building production-ready Flask applications requires careful attention to architecture, security, and performance. This article covers essential best practices learned through building multiple Flask projects.

## Application Structure

A well-organized Flask application follows a clear structure that separates concerns and promotes maintainability:

```python
app/
├── __init__.py
├── models.py
├── views.py
├── forms.py
├── static/
├── templates/
└── config.py
```

## Database Design

Use SQLAlchemy for database operations and follow these principles:
- Define clear model relationships
- Use database migrations for schema changes
- Implement proper indexing for performance
- Handle database connections efficiently

## Security Considerations

Security should be built into every aspect of your application:
- Use CSRF protection for all forms
- Implement proper input validation
- Hash passwords securely
- Use HTTPS in production
- Validate and sanitize all user inputs

## Performance Optimization

Optimize your Flask application for better performance:
- Use database query optimization
- Implement caching strategies
- Optimize static file serving
- Use connection pooling
- Monitor application performance

These practices ensure your Flask applications are robust, secure, and ready for production use.''',
        'author': 'Alex Johnson',
        'date': '2025-07-15',
        'tags': ['Flask', 'Python', 'Web Development', 'Best Practices']
    },
    {
        'id': 'real_time_web_apps',
        'title': 'Building Real-time Web Applications with Flask-SocketIO',
        'excerpt': 'Explore how to add real-time features to your Flask applications using WebSocket technology.',
        'content': '''Real-time features can transform user experience in web applications. This guide demonstrates how to implement real-time functionality using Flask-SocketIO.

## Setting Up Flask-SocketIO

First, install and configure Flask-SocketIO:

```python
from flask import Flask
from flask_socketio import SocketIO, emit

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")
```

## Implementing Real-time Chat

Create a basic chat system with these components:

```python
@socketio.on('connect')
def handle_connect():
    print(f'User {current_user.username} connected')
    
@socketio.on('send_message')
def handle_message(data):
    emit('receive_message', data, broadcast=True)
```

## Best Practices

- Handle connection errors gracefully
- Implement proper authentication
- Use rooms for private conversations
- Optimize message broadcasting
- Test with multiple concurrent users

Real-time features add significant value to web applications and create engaging user experiences.''',
        'author': 'Alex Johnson',
        'date': '2025-07-14',
        'tags': ['Flask-SocketIO', 'Real-time', 'WebSocket', 'Python']
    }
]

@app.route('/')
def index():
    """Homepage with portfolio overview"""
    return render_template('index.html', 
                         personal_info=PORTFOLIO_DATA['personal_info'],
                         skills=PORTFOLIO_DATA['skills'],
                         recent_projects=list(PROJECTS_DATA.values())[:3])

@app.route('/about')
def about():
    """About page with detailed information"""
    return render_template('about.html',
                         personal_info=PORTFOLIO_DATA['personal_info'],
                         skills=PORTFOLIO_DATA['skills'],
                         experience=PORTFOLIO_DATA['experience'],
                         education=PORTFOLIO_DATA['education'])

@app.route('/projects')
def projects():
    """Projects showcase page"""
    return render_template('projects.html', projects=PROJECTS_DATA)

@app.route('/project/<project_id>')
def project_detail(project_id):
    """Individual project detail page"""
    project = PROJECTS_DATA.get(project_id)
    if not project:
        return render_template('404.html'), 404
    
    # Get related projects
    related_projects = [p for p in PROJECTS_DATA.values() if p['id'] != project_id][:2]
    
    return render_template('project_detail.html', 
                         project=project, 
                         related_projects=related_projects)

@app.route('/blog')
def blog():
    """Blog/articles listing page"""
    return render_template('blog.html', articles=ARTICLES_DATA)

@app.route('/blog/<article_id>')
def article_detail(article_id):
    """Individual article detail page"""
    article = next((a for a in ARTICLES_DATA if a['id'] == article_id), None)
    if not article:
        return render_template('404.html'), 404
    
    return render_template('article_detail.html', article=article)

@app.route('/contact')
def contact():
    """Contact page"""
    return render_template('contact.html', 
                         personal_info=PORTFOLIO_DATA['personal_info'])

@app.route('/contact', methods=['POST'])
def contact_submit():
    """Handle contact form submission"""
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    message = request.form.get('message', '').strip()
    
    if not all([name, email, message]):
        flash('Please fill in all fields.', 'error')
        return redirect(url_for('contact'))
    
    # In a real application, you would send an email or save to database
    # For now, we'll just show a success message
    flash(f'Thank you, {name}! Your message has been sent. I\'ll get back to you soon.', 'success')
    return redirect(url_for('contact'))

@app.route('/resume')
def resume():
    """Resume/CV page"""
    return render_template('resume.html',
                         personal_info=PORTFOLIO_DATA['personal_info'],
                         skills=PORTFOLIO_DATA['skills'],
                         experience=PORTFOLIO_DATA['experience'],
                         education=PORTFOLIO_DATA['education'])

# API Routes
@app.route('/api/projects')
def api_projects():
    """API endpoint for projects data"""
    return jsonify(list(PROJECTS_DATA.values()))

@app.route('/api/project/<project_id>')
def api_project_detail(project_id):
    """API endpoint for individual project"""
    project = PROJECTS_DATA.get(project_id)
    if not project:
        return jsonify({'error': 'Project not found'}), 404
    return jsonify(project)

@app.route('/api/skills')
def api_skills():
    """API endpoint for skills data"""
    return jsonify(PORTFOLIO_DATA['skills'])

@app.route('/api/contact', methods=['POST'])
def api_contact():
    """API endpoint for contact form"""
    data = request.get_json()
    if not data or not all(key in data for key in ['name', 'email', 'message']):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # In a real application, process the contact form
    return jsonify({'message': 'Contact form submitted successfully'})

@app.route('/api/health')
def api_health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    })

# Image generation routes
@app.route('/static/img/profile.jpg')
def generate_profile_image():
    """Generate a professional profile SVG image"""
    svg_content = '''<svg width="300" height="300" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
            </linearGradient>
        </defs>
        <circle cx="150" cy="150" r="150" fill="url(#grad1)"/>
        <circle cx="150" cy="120" r="45" fill="#fff" opacity="0.9"/>
        <path d="M 90 220 Q 150 180 210 220 Q 210 250 150 270 Q 90 250 90 220" fill="#fff" opacity="0.9"/>
        <text x="150" y="290" text-anchor="middle" fill="#fff" font-family="Arial, sans-serif" font-size="14" font-weight="bold">Alex Johnson</text>
    </svg>'''
    return Response(svg_content, mimetype='image/svg+xml')

@app.route('/static/img/project-placeholder.jpg')
def generate_project_placeholder():
    """Generate a project placeholder SVG image"""
    svg_content = '''<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#f8f9fa;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#e9ecef;stop-opacity:1" />
            </linearGradient>
        </defs>
        <rect width="400" height="300" fill="url(#grad2)"/>
        <rect x="50" y="50" width="300" height="200" fill="#6c757d" opacity="0.3" rx="10"/>
        <circle cx="200" cy="120" r="30" fill="#6c757d" opacity="0.5"/>
        <rect x="150" y="170" width="100" height="10" fill="#6c757d" opacity="0.4" rx="5"/>
        <rect x="170" y="190" width="60" height="8" fill="#6c757d" opacity="0.3" rx="4"/>
        <text x="200" y="280" text-anchor="middle" fill="#6c757d" font-family="Arial, sans-serif" font-size="12">Project Screenshot</text>
    </svg>'''
    return Response(svg_content, mimetype='image/svg+xml')

@app.route('/static/img/task_management_screenshot.png')
def generate_task_management_icon():
    """Generate Task Management System icon"""
    svg_content = '''<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="taskGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#007bff;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#0056b3;stop-opacity:1" />
            </linearGradient>
        </defs>
        <rect width="400" height="300" fill="url(#taskGrad)"/>
        <circle cx="200" cy="150" r="80" fill="#fff" opacity="0.9"/>
        <rect x="160" y="120" width="80" height="8" fill="#007bff" rx="4"/>
        <rect x="160" y="140" width="60" height="8" fill="#28a745" rx="4"/>
        <rect x="160" y="160" width="70" height="8" fill="#ffc107" rx="4"/>
        <rect x="160" y="180" width="50" height="8" fill="#6c757d" rx="4"/>
        <circle cx="145" cy="124" r="4" fill="#007bff"/>
        <circle cx="145" cy="144" r="4" fill="#28a745"/>
        <circle cx="145" cy="164" r="4" fill="#ffc107"/>
        <circle cx="145" cy="184" r="4" fill="#6c757d"/>
        <text x="200" y="260" text-anchor="middle" fill="#fff" font-family="Arial, sans-serif" font-size="16" font-weight="bold">Task Management</text>
    </svg>'''
    return Response(svg_content, mimetype='image/svg+xml')

@app.route('/static/img/cloud_deployment_screenshot.png')
def generate_cloud_deployment_icon():
    """Generate Cloud Deployment Blog icon"""
    svg_content = '''<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="cloudGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#6f42c1;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#5a2d91;stop-opacity:1" />
            </linearGradient>
        </defs>
        <rect width="400" height="300" fill="url(#cloudGrad)"/>
        <ellipse cx="200" cy="130" rx="60" ry="35" fill="#fff" opacity="0.9"/>
        <ellipse cx="170" cy="110" rx="35" ry="20" fill="#fff" opacity="0.8"/>
        <ellipse cx="230" cy="110" rx="35" ry="20" fill="#fff" opacity="0.8"/>
        <ellipse cx="150" cy="140" rx="25" ry="15" fill="#fff" opacity="0.7"/>
        <ellipse cx="250" cy="140" rx="25" ry="15" fill="#fff" opacity="0.7"/>
        <path d="M 170 170 L 200 190 L 230 170" stroke="#fff" stroke-width="3" fill="none"/>
        <path d="M 190 190 L 200 200 L 210 190" stroke="#fff" stroke-width="2" fill="none"/>
        <text x="200" y="260" text-anchor="middle" fill="#fff" font-family="Arial, sans-serif" font-size="16" font-weight="bold">Cloud Deployment</text>
    </svg>'''
    return Response(svg_content, mimetype='image/svg+xml')

@app.route('/static/img/advanced_web_app_screenshot.png')
def generate_advanced_web_app_icon():
    """Generate Advanced Web App icon"""
    svg_content = '''<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="webGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#dc3545;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#b02a37;stop-opacity:1" />
            </linearGradient>
        </defs>
        <rect width="400" height="300" fill="url(#webGrad)"/>
        <rect x="120" y="80" width="160" height="120" fill="#fff" opacity="0.9" rx="10"/>
        <rect x="130" y="90" width="140" height="8" fill="#dc3545" rx="4"/>
        <rect x="130" y="110" width="100" height="6" fill="#6c757d" rx="3"/>
        <rect x="130" y="125" width="120" height="6" fill="#6c757d" rx="3"/>
        <rect x="130" y="140" width="80" height="6" fill="#6c757d" rx="3"/>
        <circle cx="145" cy="170" r="12" fill="#28a745"/>
        <circle cx="175" cy="170" r="12" fill="#007bff"/>
        <circle cx="205" cy="170" r="12" fill="#ffc107"/>
        <circle cx="235" cy="170" r="12" fill="#6f42c1"/>
        <text x="200" y="260" text-anchor="middle" fill="#fff" font-family="Arial, sans-serif" font-size="16" font-weight="bold">Advanced Web App</text>
    </svg>'''
    return Response(svg_content, mimetype='image/svg+xml')

# Error handlers
@app.errorhandler(404)
def not_found(error):
    """404 error handler"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """500 error handler"""
    return render_template('500.html'), 500

# Template filters
@app.template_filter('datetime')
def datetime_filter(value):
    """Format datetime for display"""
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    return value.strftime('%B %d, %Y')

@app.template_global()
def current_year():
    """Get current year for copyright"""
    return datetime.now().year

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5004))
    app.run(host='0.0.0.0', port=port, debug=True)