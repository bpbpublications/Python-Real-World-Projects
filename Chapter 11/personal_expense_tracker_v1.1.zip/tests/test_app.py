import pytest
import os
import tempfile
from app import app, db, User, Category, Expense

@pytest.fixture
def client():
    # Create a temporary database file
    db_fd, app.config['DATABASE'] = tempfile.mkstemp()
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()
    
    os.close(db_fd)
    os.unlink(app.config['DATABASE'])

def test_index_page(client):
    """Test the index page loads correctly"""
    rv = client.get('/')
    assert rv.status_code == 200
    assert b'Track Your Expenses' in rv.data

def test_user_registration(client):
    """Test user registration"""
    rv = client.post('/register', data={
        'username': 'testuser',
        'email': 'test@example.com',
        'password': 'testpassword',
        'first_name': 'Test',
        'last_name': 'User'
    })
    assert rv.status_code == 302  # Redirect after successful registration

def test_user_login(client):
    """Test user login"""
    # First create a user
    with app.app_context():
        user = User(
            username='testuser',
            email='test@example.com',
            first_name='Test',
            last_name='User'
        )
        user.set_password('testpassword')
        db.session.add(user)
        db.session.commit()
    
    # Now test login
    rv = client.post('/login', data={
        'email': 'test@example.com',
        'password': 'testpassword'
    })
    assert rv.status_code == 302  # Redirect after successful login

def test_dashboard_requires_login(client):
    """Test that dashboard requires authentication"""
    rv = client.get('/dashboard')
    assert rv.status_code == 302  # Redirect to login

def test_health_check(client):
    """Test health check endpoint"""
    rv = client.get('/health')
    assert rv.status_code == 200
    assert b'healthy' in rv.data

def test_add_expense(client):
    """Test adding an expense"""
    # Create and login user
    with app.app_context():
        user = User(
            username='testuser',
            email='test@example.com',
            first_name='Test',
            last_name='User'
        )
        user.set_password('testpassword')
        db.session.add(user)
        db.session.commit()
    
    # Login
    client.post('/login', data={
        'email': 'test@example.com',
        'password': 'testpassword'
    })
    
    # Add expense
    rv = client.post('/expenses/add', data={
        'description': 'Test expense',
        'amount': '50.00',
        'date': '2025-01-01'
    })
    assert rv.status_code == 302  # Redirect after successful add

def test_create_category(client):
    """Test creating a category"""
    # Create and login user
    with app.app_context():
        user = User(
            username='testuser',
            email='test@example.com',
            first_name='Test',
            last_name='User'
        )
        user.set_password('testpassword')
        db.session.add(user)
        db.session.commit()
    
    # Login
    client.post('/login', data={
        'email': 'test@example.com',
        'password': 'testpassword'
    })
    
    # Create category
    rv = client.post('/categories/add', data={
        'name': 'Test Category',
        'description': 'Test description',
        'color': '#ff0000',
        'icon': 'tag'
    })
    assert rv.status_code == 302  # Redirect after successful add