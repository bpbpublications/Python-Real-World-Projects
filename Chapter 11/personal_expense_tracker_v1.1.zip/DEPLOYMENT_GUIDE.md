# Deployment Guide - Personal Expense Tracker

This guide provides detailed instructions for deploying the Personal Expense Tracker application to various cloud platforms.

## Prerequisites

- Python 3.11 or higher
- PostgreSQL (for production deployment)
- Git
- Account on your chosen deployment platform

## Local Development Setup

1. **Clone the repository:**
```bash
git clone https://github.com/yourusername/personal-expense-tracker.git
cd personal-expense-tracker
```

2. **Run the automated setup script:**
```bash
chmod +x deploy/local_setup.sh
./deploy/local_setup.sh
```

3. **Start the application:**
```bash
source venv/bin/activate
python app.py
```

## Heroku Deployment

### Method 1: Automated Script (Recommended)

1. **Install Heroku CLI:**
   - Visit: https://devcenter.heroku.com/articles/heroku-cli
   - Follow installation instructions for your OS

2. **Login to Heroku:**
```bash
heroku login
```

3. **Run deployment script:**
```bash
chmod +x deploy/heroku_deploy.sh
./deploy/heroku_deploy.sh
```

### Method 2: Manual Deployment

1. **Create Heroku app:**
```bash
heroku create your-app-name
```

2. **Set environment variables:**
```bash
heroku config:set SECRET_KEY="your-secret-key-here"
heroku config:set FLASK_ENV=production
```

3. **Add PostgreSQL addon:**
```bash
heroku addons:create heroku-postgresql:mini
```

4. **Deploy:**
```bash
git push heroku main
```

5. **Initialize database:**
```bash
heroku run python -c "from app import init_db; init_db()"
```

## AWS ECS Deployment

### Prerequisites

- AWS CLI configured
- Docker installed
- ECR repository created

### Method 1: Automated Script

1. **Configure AWS CLI:**
```bash
aws configure
```

2. **Run deployment script:**
```bash
chmod +x deploy/aws_deploy.sh
./deploy/aws_deploy.sh
```

### Method 2: Manual Deployment

1. **Create ECR repository:**
```bash
aws ecr create-repository --repository-name expense-tracker
```

2. **Build and push Docker image:**
```bash
docker build -t expense-tracker .
docker tag expense-tracker:latest YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/expense-tracker:latest
docker push YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/expense-tracker:latest
```

3. **Create ECS cluster:**
```bash
aws ecs create-cluster --cluster-name expense-tracker-cluster
```

4. **Create RDS instance:**
```bash
aws rds create-db-instance \
  --db-instance-identifier expense-tracker-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --master-username expenseuser \
  --master-user-password your-password \
  --allocated-storage 20
```

5. **Create task definition and service (see aws_deploy.sh for details)**

## Docker Deployment

### Using Docker Compose (Recommended)

1. **Create environment file:**
```bash
cp .env.example .env
# Edit .env with your configuration
```

2. **Start services:**
```bash
docker-compose up -d
```

### Using Docker only

1. **Build image:**
```bash
docker build -t expense-tracker .
```

2. **Run container:**
```bash
docker run -p 5000:5000 \
  -e DATABASE_URL=postgresql://user:pass@host:5432/db \
  -e SECRET_KEY=your-secret-key \
  expense-tracker
```

## Environment Variables

### Required Variables

- `SECRET_KEY`: Flask secret key for session management
- `DATABASE_URL`: PostgreSQL connection string
- `FLASK_ENV`: Set to 'production' for production deployments

### Optional Variables

- `PORT`: Port number (default: 5000)
- `WTF_CSRF_ENABLED`: Enable CSRF protection (default: True)
- `SESSION_COOKIE_SECURE`: Use secure cookies (default: False for development)

## Database Setup

### PostgreSQL (Production)

1. **Create database:**
```sql
CREATE DATABASE expense_tracker;
CREATE USER expenseuser WITH PASSWORD 'your-password';
GRANT ALL PRIVILEGES ON DATABASE expense_tracker TO expenseuser;
```

2. **Update DATABASE_URL:**
```env
DATABASE_URL=postgresql://expenseuser:your-password@localhost:5432/expense_tracker
```

### SQLite (Development)

For local development, you can use SQLite:
```env
DATABASE_URL=sqlite:///expenses.db
```

## SSL/TLS Configuration

### Heroku
- SSL is automatically provided by Heroku
- Use `https://` URLs in production

### AWS
- Configure Application Load Balancer with SSL certificate
- Use AWS Certificate Manager for free SSL certificates

### Custom Domain
- Update DNS settings to point to your deployment
- Configure SSL certificate for your domain

## Monitoring and Logging

### Heroku
```bash
# View logs
heroku logs --tail

# Monitor performance
heroku ps
```

### AWS
- Use CloudWatch for monitoring
- Set up log groups for application logs
- Configure alerts for errors and performance metrics

## Backup and Recovery

### Database Backups

#### Heroku
```bash
# Create backup
heroku pg:backups:capture

# Download backup
heroku pg:backups:download
```

#### AWS RDS
```bash
# Create snapshot
aws rds create-db-snapshot \
  --db-instance-identifier expense-tracker-db \
  --db-snapshot-identifier expense-tracker-snapshot-$(date +%Y%m%d)
```

### Application Backups
- Source code: Use Git for version control
- Configuration: Store in separate repository or secure location
- User data: Regular database backups

## Security Considerations

1. **Environment Variables:**
   - Never commit secrets to Git
   - Use platform-specific secret management
   - Rotate secrets regularly

2. **Database Security:**
   - Use strong passwords
   - Enable SSL connections
   - Regular security updates

3. **Application Security:**
   - Keep dependencies updated
   - Use HTTPS in production
   - Enable CSRF protection

## Troubleshooting

### Common Issues

1. **Database Connection Error:**
   - Check DATABASE_URL format
   - Verify database credentials
   - Ensure database server is running

2. **Port Already in Use:**
   - Change PORT environment variable
   - Kill existing processes on the port

3. **Missing Dependencies:**
   - Run `pip install -r requirements.txt`
   - Check Python version compatibility

4. **Static Files Not Loading:**
   - Ensure static files are properly configured
   - Check file permissions

### Getting Help

1. **Check logs:**
   - Heroku: `heroku logs --tail`
   - AWS: CloudWatch logs
   - Local: Check terminal output

2. **Debug mode:**
   - Set `FLASK_ENV=development` for detailed errors
   - Never use debug mode in production

3. **Health check:**
   - Visit `/health` endpoint
   - Check application status

## Performance Optimization

### Production Settings

1. **Use production WSGI server:**
   - Gunicorn (included in requirements.txt)
   - Configure workers based on CPU cores

2. **Database optimization:**
   - Use connection pooling
   - Enable query optimization
   - Regular database maintenance

3. **Caching:**
   - Add Redis for session storage
   - Implement query caching
   - Use CDN for static files

## Scaling

### Horizontal Scaling

1. **Heroku:**
```bash
heroku ps:scale web=3
```

2. **AWS ECS:**
```bash
aws ecs update-service \
  --cluster expense-tracker-cluster \
  --service expense-tracker-service \
  --desired-count 3
```

### Vertical Scaling

1. **Heroku:**
```bash
heroku ps:resize web=standard-2x
```

2. **AWS:**
   - Update task definition with more CPU/memory
   - Use larger EC2 instances

## Maintenance

### Regular Tasks

1. **Database maintenance:**
   - Regular backups
   - Index optimization
   - Clean up old data

2. **Security updates:**
   - Update dependencies
   - Apply security patches
   - Review access logs

3. **Performance monitoring:**
   - Monitor response times
   - Check error rates
   - Optimize slow queries

### Automated Maintenance

Use the included GitHub Actions workflow for:
- Automated testing
- Security scanning
- Dependency updates
- Deployment automation

## Support

For deployment issues:
1. Check this guide first
2. Review application logs
3. Consult platform documentation
4. Create GitHub issue with details

## Additional Resources

- [Heroku Python Documentation](https://devcenter.heroku.com/articles/getting-started-with-python)
- [AWS ECS Documentation](https://docs.aws.amazon.com/ecs/)
- [Docker Documentation](https://docs.docker.com/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [Flask Deployment Options](https://flask.palletsprojects.com/en/2.3.x/deploying/)