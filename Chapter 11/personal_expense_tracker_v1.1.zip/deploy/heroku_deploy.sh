#!/bin/bash

# Heroku Deployment Script for Personal Expense Tracker

set -e

echo "🚀 Starting Heroku deployment..."

# Check if Heroku CLI is installed
if ! command -v heroku &> /dev/null; then
    echo "❌ Heroku CLI not found. Please install it first."
    echo "Visit: https://devcenter.heroku.com/articles/heroku-cli"
    exit 1
fi

# Check if user is logged in to Heroku
if ! heroku auth:whoami &> /dev/null; then
    echo "❌ Not logged in to Heroku. Please login first."
    echo "Run: heroku login"
    exit 1
fi

# Get app name from user or use default
read -p "Enter your Heroku app name (or press Enter for 'personal-expense-tracker'): " APP_NAME
APP_NAME=${APP_NAME:-personal-expense-tracker}

echo "📋 Using app name: $APP_NAME"

# Check if app exists, create if not
if ! heroku apps:info $APP_NAME &> /dev/null; then
    echo "📦 Creating Heroku app: $APP_NAME"
    heroku create $APP_NAME
else
    echo "✅ App $APP_NAME already exists"
fi

# Set environment variables
echo "🔧 Setting up environment variables..."
heroku config:set SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')" --app $APP_NAME
heroku config:set FLASK_ENV=production --app $APP_NAME

# Add PostgreSQL addon
echo "🗄️ Adding PostgreSQL database..."
heroku addons:create heroku-postgresql:mini --app $APP_NAME || echo "PostgreSQL addon already exists"

# Add Redis addon for caching (optional)
echo "🔄 Adding Redis for caching..."
heroku addons:create heroku-redis:mini --app $APP_NAME || echo "Redis addon already exists"

# Set git remote
echo "🔗 Setting up git remote..."
heroku git:remote -a $APP_NAME

# Deploy to Heroku
echo "🚀 Deploying to Heroku..."
git add .
git commit -m "Deploy to Heroku" || echo "No changes to commit"
git push heroku main

# Run database migrations
echo "🗄️ Running database migrations..."
heroku run python -c "from app import init_db; init_db()" --app $APP_NAME

# Scale dynos
echo "📈 Scaling dynos..."
heroku ps:scale web=1 --app $APP_NAME

# Open the app
echo "🌐 Opening app in browser..."
heroku open --app $APP_NAME

echo "✅ Deployment completed successfully!"
echo "🔗 App URL: https://$APP_NAME.herokuapp.com"
echo "📊 Logs: heroku logs --tail --app $APP_NAME"
echo "⚙️ Config: heroku config --app $APP_NAME"