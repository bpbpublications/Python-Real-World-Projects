#!/bin/bash

# Local Setup Script for Personal Expense Tracker

set -e

echo "🚀 Setting up Personal Expense Tracker locally..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.8 or higher."
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo "🐍 Python version: $PYTHON_VERSION"

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 not found. Please install pip."
    exit 1
fi

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv venv

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "📄 Creating .env file..."
    cp .env.example .env
    
    # Generate secret key
    SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')
    
    # Update .env file
    sed -i "s/your-secret-key-change-in-production/$SECRET_KEY/" .env
    
    echo "✅ .env file created with generated secret key"
fi

# Check if PostgreSQL is installed and running
if command -v psql &> /dev/null; then
    echo "🗄️ PostgreSQL found. Setting up database..."
    
    # Create database
    createdb expense_tracker || echo "Database might already exist"
    
    # Update .env with PostgreSQL URL
    sed -i 's|DATABASE_URL=.*|DATABASE_URL=postgresql://localhost/expense_tracker|' .env
    
    echo "✅ PostgreSQL database configured"
else
    echo "⚠️ PostgreSQL not found. Using SQLite for development."
    echo "📋 To use PostgreSQL, install it and update DATABASE_URL in .env"
    
    # Use SQLite for development
    sed -i 's|DATABASE_URL=.*|DATABASE_URL=sqlite:///expenses.db|' .env
fi

# Initialize the database
echo "🗄️ Initializing database..."
python3 -c "from app import init_db; init_db()"

# Create sample data (optional)
read -p "Do you want to create sample data? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "📊 Creating sample data..."
    python3 -c "
from app import app, db
from app import User, Category, Expense
from datetime import datetime, timedelta
import random

with app.app_context():
    # Create sample user
    user = User(
        username='demo',
        email='demo@example.com',
        first_name='Demo',
        last_name='User',
        monthly_budget=2000.0
    )
    user.set_password('demo123')
    db.session.add(user)
    db.session.commit()
    
    # Create sample categories
    categories = [
        {'name': 'Groceries', 'color': '#28a745', 'icon': 'shopping-cart'},
        {'name': 'Gas', 'color': '#ffc107', 'icon': 'car'},
        {'name': 'Restaurants', 'color': '#dc3545', 'icon': 'utensils'},
        {'name': 'Entertainment', 'color': '#17a2b8', 'icon': 'music'},
    ]
    
    category_objects = []
    for cat in categories:
        category = Category(
            name=cat['name'],
            color=cat['color'],
            icon=cat['icon'],
            user_id=user.id
        )
        db.session.add(category)
        category_objects.append(category)
    
    db.session.commit()
    
    # Create sample expenses
    expenses = [
        {'description': 'Weekly groceries', 'amount': 85.50, 'category': 0},
        {'description': 'Gas station', 'amount': 45.00, 'category': 1},
        {'description': 'Lunch at restaurant', 'amount': 25.75, 'category': 2},
        {'description': 'Movie tickets', 'amount': 30.00, 'category': 3},
        {'description': 'Coffee shop', 'amount': 12.50, 'category': 2},
        {'description': 'Grocery store', 'amount': 67.25, 'category': 0},
        {'description': 'Gas fill up', 'amount': 52.00, 'category': 1},
        {'description': 'Dinner out', 'amount': 89.00, 'category': 2},
    ]
    
    for i, exp in enumerate(expenses):
        expense = Expense(
            description=exp['description'],
            amount=exp['amount'],
            category_id=category_objects[exp['category']].id,
            user_id=user.id,
            date=datetime.now() - timedelta(days=random.randint(0, 30))
        )
        db.session.add(expense)
    
    db.session.commit()
    print('Sample data created successfully!')
    print('Demo user: demo@example.com / demo123')
"
fi

# Check if everything is working
echo "🧪 Testing application..."
python3 -c "
from app import app
with app.app_context():
    print('✅ Application test passed!')
"

echo "🎉 Setup completed successfully!"
echo ""
echo "📋 Quick Start:"
echo "1. Activate virtual environment: source venv/bin/activate"
echo "2. Run the application: python app.py"
echo "3. Open browser: http://localhost:5000"
echo ""
echo "🔧 Configuration:"
echo "- Edit .env file to customize settings"
echo "- Database: $(grep DATABASE_URL .env | cut -d'=' -f2)"
echo ""
echo "📚 Documentation:"
echo "- README.md for detailed information"
echo "- API documentation available at /health endpoint"
echo ""
echo "🚀 Deployment:"
echo "- Heroku: ./deploy/heroku_deploy.sh"
echo "- AWS: ./deploy/aws_deploy.sh"
echo "- Docker: docker-compose up"