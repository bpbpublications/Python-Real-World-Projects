#!/bin/bash

# AWS Deployment Script for Personal Expense Tracker
# This script deploys the application to AWS ECS with RDS PostgreSQL

set -e

echo "🚀 Starting AWS deployment..."

# Check if AWS CLI is installed
if ! command -v aws &> /dev/null; then
    echo "❌ AWS CLI not found. Please install it first."
    echo "Visit: https://aws.amazon.com/cli/"
    exit 1
fi

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker not found. Please install it first."
    echo "Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

# Configuration
AWS_REGION="us-east-1"
ECR_REPOSITORY="expense-tracker"
CLUSTER_NAME="expense-tracker-cluster"
SERVICE_NAME="expense-tracker-service"
TASK_DEFINITION_NAME="expense-tracker-task"

# Get AWS account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ECR_URI="$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"

echo "📋 AWS Account ID: $ACCOUNT_ID"
echo "📋 ECR Repository: $ECR_URI/$ECR_REPOSITORY"

# Create ECR repository if it doesn't exist
echo "🐳 Creating ECR repository..."
aws ecr describe-repositories --repository-names $ECR_REPOSITORY --region $AWS_REGION || \
aws ecr create-repository --repository-name $ECR_REPOSITORY --region $AWS_REGION

# Login to ECR
echo "🔐 Logging in to ECR..."
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $ECR_URI

# Build and tag Docker image
echo "🏗️ Building Docker image..."
docker build -t $ECR_REPOSITORY:latest .
docker tag $ECR_REPOSITORY:latest $ECR_URI/$ECR_REPOSITORY:latest

# Push image to ECR
echo "📤 Pushing image to ECR..."
docker push $ECR_URI/$ECR_REPOSITORY:latest

# Create ECS cluster if it doesn't exist
echo "🏭 Setting up ECS cluster..."
aws ecs describe-clusters --clusters $CLUSTER_NAME --region $AWS_REGION || \
aws ecs create-cluster --cluster-name $CLUSTER_NAME --region $AWS_REGION

# Create RDS subnet group
echo "🗄️ Setting up RDS subnet group..."
aws rds create-db-subnet-group \
    --db-subnet-group-name expense-tracker-subnet-group \
    --db-subnet-group-description "Subnet group for expense tracker RDS" \
    --subnet-ids subnet-12345678 subnet-87654321 \
    --region $AWS_REGION || echo "Subnet group already exists"

# Create RDS instance
echo "🗄️ Setting up RDS PostgreSQL instance..."
aws rds create-db-instance \
    --db-instance-identifier expense-tracker-db \
    --db-instance-class db.t3.micro \
    --engine postgres \
    --engine-version 15.4 \
    --master-username expenseuser \
    --master-user-password "$(python -c 'import secrets; print(secrets.token_urlsafe(16))')" \
    --allocated-storage 20 \
    --db-name expense_tracker \
    --db-subnet-group-name expense-tracker-subnet-group \
    --vpc-security-group-ids sg-12345678 \
    --region $AWS_REGION || echo "RDS instance already exists"

# Wait for RDS instance to be available
echo "⏳ Waiting for RDS instance to be ready..."
aws rds wait db-instance-available --db-instance-identifier expense-tracker-db --region $AWS_REGION

# Get RDS endpoint
RDS_ENDPOINT=$(aws rds describe-db-instances \
    --db-instance-identifier expense-tracker-db \
    --query 'DBInstances[0].Endpoint.Address' \
    --output text \
    --region $AWS_REGION)

echo "🗄️ RDS Endpoint: $RDS_ENDPOINT"

# Create task definition
echo "📋 Creating ECS task definition..."
cat > task-definition.json << EOF
{
    "family": "$TASK_DEFINITION_NAME",
    "networkMode": "awsvpc",
    "requiresCompatibilities": ["FARGATE"],
    "cpu": "256",
    "memory": "512",
    "executionRoleArn": "arn:aws:iam::$ACCOUNT_ID:role/ecsTaskExecutionRole",
    "containerDefinitions": [
        {
            "name": "expense-tracker",
            "image": "$ECR_URI/$ECR_REPOSITORY:latest",
            "portMappings": [
                {
                    "containerPort": 5000,
                    "protocol": "tcp"
                }
            ],
            "environment": [
                {
                    "name": "DATABASE_URL",
                    "value": "postgresql://expenseuser:$(python -c 'import secrets; print(secrets.token_urlsafe(16))')@$RDS_ENDPOINT:5432/expense_tracker"
                },
                {
                    "name": "SECRET_KEY",
                    "value": "$(python -c 'import secrets; print(secrets.token_hex(32))')"
                },
                {
                    "name": "FLASK_ENV",
                    "value": "production"
                }
            ],
            "logConfiguration": {
                "logDriver": "awslogs",
                "options": {
                    "awslogs-group": "/ecs/expense-tracker",
                    "awslogs-region": "$AWS_REGION",
                    "awslogs-stream-prefix": "ecs"
                }
            }
        }
    ]
}
EOF

# Register task definition
aws ecs register-task-definition --cli-input-json file://task-definition.json --region $AWS_REGION

# Create service
echo "🚀 Creating ECS service..."
aws ecs create-service \
    --cluster $CLUSTER_NAME \
    --service-name $SERVICE_NAME \
    --task-definition $TASK_DEFINITION_NAME \
    --desired-count 1 \
    --launch-type FARGATE \
    --network-configuration "awsvpcConfiguration={subnets=[subnet-12345678,subnet-87654321],securityGroups=[sg-12345678],assignPublicIp=ENABLED}" \
    --region $AWS_REGION || echo "Service already exists"

# Update service to use new task definition
echo "🔄 Updating ECS service..."
aws ecs update-service \
    --cluster $CLUSTER_NAME \
    --service $SERVICE_NAME \
    --task-definition $TASK_DEFINITION_NAME \
    --region $AWS_REGION

# Wait for service to be stable
echo "⏳ Waiting for service to stabilize..."
aws ecs wait services-stable --cluster $CLUSTER_NAME --services $SERVICE_NAME --region $AWS_REGION

# Get service details
echo "📊 Getting service details..."
aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --region $AWS_REGION

echo "✅ AWS deployment completed successfully!"
echo "🔗 Your application is now running on AWS ECS"
echo "📊 Monitor: https://console.aws.amazon.com/ecs/home?region=$AWS_REGION#/clusters/$CLUSTER_NAME"
echo "🗄️ Database: $RDS_ENDPOINT"

# Clean up
rm -f task-definition.json