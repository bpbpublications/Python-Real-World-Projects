# Personal Expense Tracker

A comprehensive Flask-based web application for tracking personal expenses with user authentication, categorization, data visualization, and cloud deployment support.

## Features

- **User Authentication**: Secure registration and login system
- **Expense Management**: Add, edit, delete, and categorize expenses
- **Budget Tracking**: Set monthly budgets and track spending progress
- **Data Visualization**: Interactive charts and reports
- **Category Management**: Custom expense categories with colors and icons
- **Responsive Design**: Mobile-friendly interface with Bootstrap 5
- **Cloud Deployment**: Ready for Heroku and AWS deployment
- **CI/CD Integration**: GitHub Actions for automated testing and deployment

## Technology Stack

- **Backend**: Flask, SQLAlchemy, PostgreSQL
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Charts**: Chart.js for data visualization
- **Authentication**: Flask-Login, Flask-WTF
- **Deployment**: Heroku, AWS ECS, Docker
- **CI/CD**: GitHub Actions

## Quick Start

### Local Development

1. Clone the repository:
```bash
git clone https://github.com/yourusername/personal-expense-tracker.git
cd personal-expense-tracker
```

2. Run the setup script:
```bash
chmod +x deploy/local_setup.sh
./deploy/local_setup.sh
```

3. Start the application:
```bash
source venv/bin/activate
python app.py
```

4. Open your browser to `http://localhost:5000`

### Using Docker

1. Build and run with Docker Compose:
```bash
docker-compose up --build
```

2. Access the application at `http://localhost:5000`

## Deployment

### Heroku Deployment

1. Make sure you have the Heroku CLI installed
2. Run the deployment script:
```bash
chmod +x deploy/heroku_deploy.sh
./deploy/heroku_deploy.sh
```

### AWS Deployment

1. Configure AWS CLI and Docker
2. Run the deployment script:
```bash
chmod +x deploy/aws_deploy.sh
./deploy/aws_deploy.sh
```

## Configuration

### Environment Variables

Create a `.env` file based on `.env.example`:

```env
SECRET_KEY=your-secret-key-here
DATABASE_URL=postgresql://username:password@localhost/expense_tracker
FLASK_ENV=development
```

### Database Configuration

The application supports both SQLite (development) and PostgreSQL (production):

- **SQLite**: `DATABASE_URL=sqlite:///expenses.db`
- **PostgreSQL**: `DATABASE_URL=postgresql://user:password@host:port/database`

## API Documentation

The application provides a REST API for programmatic access:

### Authentication Required Endpoints

- `GET /api/chart-data?type=monthly` - Monthly expense data
- `GET /api/chart-data?type=category` - Category breakdown data

### Public Endpoints

- `GET /health` - Health check endpoint

## Testing

Run the test suite:

```bash
# Install test dependencies
pip install pytest pytest-flask pytest-cov

# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ -v --cov=app --cov-report=html
```

## Database Schema

### Users Table
- `id`: Primary key
- `username`: Unique username
- `email`: User email address
- `password_hash`: Hashed password
- `first_name`: User's first name
- `last_name`: User's last name
- `monthly_budget`: Monthly spending budget
- `created_at`: Account creation timestamp

### Categories Table
- `id`: Primary key
- `name`: Category name
- `description`: Category description
- `color`: Category color (hex)
- `icon`: Font Awesome icon name
- `user_id`: Foreign key to users table

### Expenses Table
- `id`: Primary key
- `description`: Expense description
- `amount`: Expense amount
- `date`: Expense date
- `category_id`: Foreign key to categories table
- `user_id`: Foreign key to users table
- `created_at`: Record creation timestamp
- `updated_at`: Last update timestamp

## Security Features

- **Password Hashing**: Uses Werkzeug's secure password hashing
- **CSRF Protection**: Flask-WTF CSRF tokens on all forms
- **Session Management**: Secure session handling with Flask-Login
- **Input Validation**: Server-side validation for all user inputs
- **SQL Injection Prevention**: SQLAlchemy ORM protects against SQL injection

## Performance Optimizations

- **Database Connection Pooling**: Configured for production use
- **Static File Optimization**: Minified CSS and JavaScript
- **Caching**: Redis caching for frequently accessed data
- **Database Indexing**: Optimized database queries

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/new-feature`
3. Make your changes and add tests
4. Commit your changes: `git commit -am 'Add new feature'`
5. Push to the branch: `git push origin feature/new-feature`
6. Submit a pull request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, please contact [support@example.com](mailto:support@example.com) or create an issue on GitHub.

## Changelog

### v1.0.0 (2025-07-17)
- Initial release
- User authentication system
- Expense tracking and categorization
- Budget management
- Data visualization
- Heroku and AWS deployment support
- CI/CD pipeline with GitHub Actions

## Roadmap

- [ ] Mobile app (React Native)
- [ ] Receipt scanning with OCR
- [ ] Expense sharing with family members
- [ ] Advanced reporting and analytics
- [ ] Integration with bank APIs
- [ ] Multi-currency support
- [ ] Export data to CSV/PDF
- [ ] Dark mode theme
- [ ] Email notifications for budget alerts

## Architecture

The application follows a modular architecture:

```
personal_expense_tracker/
├── app.py              # Main application file
├── templates/          # Jinja2 templates
├── static/            # CSS, JS, images
├── deploy/            # Deployment scripts
├── .github/           # GitHub Actions workflows
├── tests/             # Test files
├── requirements.txt   # Python dependencies
├── Dockerfile        # Docker configuration
├── docker-compose.yml # Docker Compose configuration
└── README.md         # This file
```

## Development

### Code Style

- Follow PEP 8 for Python code
- Use meaningful variable and function names
- Add docstrings to all functions and classes
- Keep functions small and focused

### Database Migrations

The application uses Flask-SQLAlchemy with automatic table creation. For production, consider implementing proper database migrations.

### Monitoring

In production, consider adding:
- Application performance monitoring (APM)
- Error tracking (Sentry)
- Log aggregation (ELK Stack)
- Health check monitoring

## FAQ

**Q: How do I reset my password?**
A: Currently, password reset is not implemented. Contact support for assistance.

**Q: Can I import data from other expense tracking apps?**
A: Data import functionality is planned for future releases.

**Q: Is my data secure?**
A: Yes, all data is encrypted in transit and at rest. Passwords are hashed using industry-standard algorithms.

**Q: Can I use this for business expenses?**
A: The application is designed for personal use but can be adapted for business expenses with minor modifications.

## Credits

- Built with Flask and SQLAlchemy
- UI components from Bootstrap 5
- Icons from Font Awesome
- Charts powered by Chart.js
- Deployment scripts inspired by best practices from Heroku and AWS documentation