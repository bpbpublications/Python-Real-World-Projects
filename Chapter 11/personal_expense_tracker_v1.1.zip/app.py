"""
Personal Expense Tracker - Flask Application
A comprehensive expense tracking application with user authentication,
expense management, and data visualization features.
"""

import os
import logging
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
try:
    import psycopg2
except ImportError:
    psycopg2 = None
from urllib.parse import urlparse

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Enable proper proxy handling for deployment
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///expenses.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
}

# Fix for PostgreSQL URL format
if app.config['SQLALCHEMY_DATABASE_URI'].startswith('postgres://'):
    app.config['SQLALCHEMY_DATABASE_URI'] = app.config['SQLALCHEMY_DATABASE_URI'].replace('postgres://', 'postgresql://', 1)

# Initialize extensions
db = SQLAlchemy(app)
csrf = CSRFProtect(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Database Models
class User(db.Model):
    """User model for authentication"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    monthly_budget = db.Column(db.Float, default=0.0)
    
    # Relationships
    expenses = db.relationship('Expense', backref='user', lazy=True, cascade='all, delete-orphan')
    categories = db.relationship('Category', backref='user', lazy=True, cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if password is correct"""
        return check_password_hash(self.password_hash, password)
    
    def get_id(self):
        return str(self.id)
    
    def is_authenticated(self):
        return True
    
    def is_active(self):
        return True
    
    def is_anonymous(self):
        return False
    
    def get_monthly_total(self, month=None, year=None, transaction_type='expense'):
        """Get total expenses or income for a specific month"""
        if not month:
            month = datetime.now().month
        if not year:
            year = datetime.now().year
        
        start_date = datetime(year, month, 1)
        if month == 12:
            end_date = datetime(year + 1, 1, 1)
        else:
            end_date = datetime(year, month + 1, 1)
        
        total = db.session.query(db.func.sum(Expense.amount)).filter(
            Expense.user_id == self.id,
            Expense.transaction_type == transaction_type,
            Expense.date >= start_date,
            Expense.date < end_date
        ).scalar()
        
        return total or 0.0
    
    def get_monthly_net(self, month=None, year=None):
        """Get net amount (income - expenses) for a specific month"""
        income = self.get_monthly_total(month, year, 'income')
        expenses = self.get_monthly_total(month, year, 'expense')
        return income - expenses

class Category(db.Model):
    """Category model for expense categorization"""
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    color = db.Column(db.String(7), default='#007bff')
    icon = db.Column(db.String(50), default='tag')
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    expenses = db.relationship('Expense', backref='category', lazy=True)
    
    def get_monthly_total(self, month=None, year=None, transaction_type='expense'):
        """Get total expenses or income for this category in a specific month"""
        if not month:
            month = datetime.now().month
        if not year:
            year = datetime.now().year
        
        start_date = datetime(year, month, 1)
        if month == 12:
            end_date = datetime(year + 1, 1, 1)
        else:
            end_date = datetime(year, month + 1, 1)
        
        total = db.session.query(db.func.sum(Expense.amount)).filter(
            Expense.category_id == self.id,
            Expense.transaction_type == transaction_type,
            Expense.date >= start_date,
            Expense.date < end_date
        ).scalar()
        
        return total or 0.0

class Expense(db.Model):
    """Expense model for tracking expenses and income"""
    __tablename__ = 'expenses'
    
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(200), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False, default='expense')  # 'expense' or 'income'
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    receipt_url = db.Column(db.String(255))  # For future file upload feature
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=True)

# Routes
@app.route('/')
def index():
    """Homepage"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if request.method == 'POST':
        # Get form data
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        
        # Validate input
        if not all([username, email, password, first_name, last_name]):
            flash('All fields are required.', 'error')
            return render_template('auth/register.html')
        
        # Check if user exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'error')
            return render_template('auth/register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists.', 'error')
            return render_template('auth/register.html')
        
        # Create user
        user = User(
            username=username,
            email=email,
            first_name=first_name,
            last_name=last_name
        )
        user.set_password(password)
        
        try:
            db.session.add(user)
            db.session.commit()
            
            # Create default categories
            default_categories = [
                # Expense categories
                {'name': 'Food & Dining', 'color': '#ff6b6b', 'icon': 'utensils'},
                {'name': 'Transportation', 'color': '#4ecdc4', 'icon': 'car'},
                {'name': 'Shopping', 'color': '#45b7d1', 'icon': 'shopping-bag'},
                {'name': 'Entertainment', 'color': '#96ceb4', 'icon': 'music'},
                {'name': 'Bills & Utilities', 'color': '#ffeaa7', 'icon': 'file-text'},
                {'name': 'Healthcare', 'color': '#fd79a8', 'icon': 'heart'},
                {'name': 'Education', 'color': '#a29bfe', 'icon': 'book'},
                # Income categories
                {'name': 'Salary', 'color': '#00b894', 'icon': 'dollar-sign'},
                {'name': 'Freelance', 'color': '#00cec9', 'icon': 'briefcase'},
                {'name': 'Investment', 'color': '#6c5ce7', 'icon': 'trending-up'},
                {'name': 'Bonus', 'color': '#a29bfe', 'icon': 'gift'},
                {'name': 'Other Income', 'color': '#74b9ff', 'icon': 'plus-circle'},
                {'name': 'Other', 'color': '#636e72', 'icon': 'tag'}
            ]
            
            for cat_data in default_categories:
                category = Category(
                    name=cat_data['name'],
                    color=cat_data['color'],
                    icon=cat_data['icon'],
                    user_id=user.id
                )
                db.session.add(category)
            
            db.session.commit()
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Registration error: {str(e)}")
            flash('An error occurred during registration. Please try again.', 'error')
    
    return render_template('auth/register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('Email and password are required.', 'error')
            return render_template('auth/login.html')
        
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        
        flash('Invalid email or password.', 'error')
    
    return render_template('auth/login.html')

@app.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard with expense overview"""
    # Get current month data
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    # Monthly totals
    monthly_expenses = current_user.get_monthly_total(current_month, current_year, 'expense')
    monthly_income = current_user.get_monthly_total(current_month, current_year, 'income')
    monthly_net = monthly_income - monthly_expenses
    
    # Recent transactions
    recent_transactions = Expense.query.filter_by(user_id=current_user.id)\
        .order_by(Expense.date.desc())\
        .limit(10).all()
    
    # Category totals for current month (expenses only)
    category_totals = []
    for category in current_user.categories:
        expense_total = category.get_monthly_total(current_month, current_year, 'expense')
        if expense_total > 0:
            category_totals.append({
                'name': category.name,
                'total': expense_total,
                'color': category.color
            })
    
    # Budget progress
    budget_progress = 0
    if current_user.monthly_budget > 0:
        budget_progress = (monthly_expenses / current_user.monthly_budget) * 100
    
    return render_template('dashboard.html',
                         monthly_expenses=monthly_expenses,
                         monthly_income=monthly_income,
                         monthly_net=monthly_net,
                         recent_transactions=recent_transactions,
                         category_totals=category_totals,
                         budget_progress=budget_progress,
                         monthly_budget=current_user.monthly_budget)

@app.route('/expenses')
@login_required
def expenses():
    """List all expenses"""
    page = request.args.get('page', 1, type=int)
    category_id = request.args.get('category')
    
    query = Expense.query.filter_by(user_id=current_user.id)
    
    if category_id:
        query = query.filter_by(category_id=int(category_id))
    
    expenses = query.order_by(Expense.date.desc())\
        .paginate(page=page, per_page=20, error_out=False)
    
    categories = Category.query.filter_by(user_id=current_user.id).all()
    
    return render_template('expenses/list.html',
                         expenses=expenses,
                         categories=categories,
                         selected_category=category_id)

@app.route('/expenses/add', methods=['GET', 'POST'])
@login_required
def add_expense():
    """Add new expense or income"""
    if request.method == 'POST':
        description = request.form.get('description')
        amount = request.form.get('amount')
        transaction_type = request.form.get('transaction_type', 'expense')
        category_id = request.form.get('category_id')
        date = request.form.get('date')
        
        if not all([description, amount]):
            flash('Description and amount are required.', 'error')
            return redirect(url_for('add_expense'))
        
        try:
            expense = Expense(
                description=description,
                amount=float(amount),
                transaction_type=transaction_type,
                category_id=int(category_id) if category_id else None,
                date=datetime.strptime(date, '%Y-%m-%d') if date else datetime.now(),
                user_id=current_user.id
            )
            
            db.session.add(expense)
            db.session.commit()
            
            if transaction_type == 'income':
                flash('Income added successfully!', 'success')
            else:
                flash('Expense added successfully!', 'success')
                
            return redirect(url_for('expenses'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error adding transaction: {str(e)}")
            flash('Error adding transaction. Please try again.', 'error')
    
    categories = Category.query.filter_by(user_id=current_user.id).all()
    return render_template('expenses/add.html', categories=categories)

@app.route('/expenses/<int:expense_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_expense(expense_id):
    """Edit expense"""
    expense = Expense.query.filter_by(id=expense_id, user_id=current_user.id).first_or_404()
    
    if request.method == 'POST':
        description = request.form.get('description')
        amount = request.form.get('amount')
        category_id = request.form.get('category_id')
        date = request.form.get('date')
        
        if not all([description, amount]):
            flash('Description and amount are required.', 'error')
            return redirect(url_for('edit_expense', expense_id=expense_id))
        
        try:
            expense.description = description
            expense.amount = float(amount)
            expense.transaction_type = request.form.get('transaction_type', expense.transaction_type)
            expense.category_id = int(category_id) if category_id else None
            expense.date = datetime.strptime(date, '%Y-%m-%d') if date else expense.date
            expense.updated_at = datetime.utcnow()
            
            db.session.commit()
            flash('Expense updated successfully!', 'success')
            return redirect(url_for('expenses'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating expense: {str(e)}")
            flash('Error updating expense. Please try again.', 'error')
    
    categories = Category.query.filter_by(user_id=current_user.id).all()
    return render_template('expenses/edit.html', expense=expense, categories=categories)

@app.route('/expenses/<int:expense_id>/delete', methods=['POST'])
@login_required
def delete_expense(expense_id):
    """Delete expense"""
    expense = Expense.query.filter_by(id=expense_id, user_id=current_user.id).first_or_404()
    
    try:
        db.session.delete(expense)
        db.session.commit()
        flash('Expense deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting expense: {str(e)}")
        flash('Error deleting expense. Please try again.', 'error')
    
    return redirect(url_for('expenses'))

@app.route('/categories')
@login_required
def categories():
    """List all categories"""
    categories = Category.query.filter_by(user_id=current_user.id).all()
    return render_template('categories/list.html', categories=categories)

@app.route('/categories/add', methods=['GET', 'POST'])
@login_required
def add_category():
    """Add new category"""
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        color = request.form.get('color')
        icon = request.form.get('icon')
        
        if not name:
            flash('Category name is required.', 'error')
            return redirect(url_for('add_category'))
        
        try:
            category = Category(
                name=name,
                description=description,
                color=color or '#007bff',
                icon=icon or 'tag',
                user_id=current_user.id
            )
            
            db.session.add(category)
            db.session.commit()
            flash('Category added successfully!', 'success')
            return redirect(url_for('categories'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error adding category: {str(e)}")
            flash('Error adding category. Please try again.', 'error')
    
    return render_template('categories/add.html')

@app.route('/reports')
@login_required
def reports():
    """Expense reports and analytics"""
    # Monthly data for the last 12 months
    monthly_data = []
    for i in range(12):
        date = datetime.now() - timedelta(days=30 * i)
        month = date.month
        year = date.year
        expenses = current_user.get_monthly_total(month, year, 'expense')
        income = current_user.get_monthly_total(month, year, 'income')
        monthly_data.append({
            'month': date.strftime('%B %Y'),
            'expenses': expenses,
            'income': income,
            'net': income - expenses
        })
    
    monthly_data.reverse()
    
    # Category breakdown for current month (expenses only)
    category_data = []
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    for category in current_user.categories:
        expense_total = category.get_monthly_total(current_month, current_year, 'expense')
        if expense_total > 0:
            category_data.append({
                'name': category.name,
                'total': expense_total,
                'color': category.color
            })
    
    return render_template('reports.html',
                         monthly_data=monthly_data,
                         category_data=category_data)

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    """User settings"""
    if request.method == 'POST':
        monthly_budget = request.form.get('monthly_budget')
        
        try:
            current_user.monthly_budget = float(monthly_budget) if monthly_budget else 0.0
            db.session.commit()
            flash('Settings updated successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating settings: {str(e)}")
            flash('Error updating settings. Please try again.', 'error')
    
    return render_template('settings.html')

@app.route('/api/chart-data')
@login_required
def chart_data():
    """API endpoint for chart data"""
    chart_type = request.args.get('type', 'monthly')
    
    if chart_type == 'monthly':
        # Monthly expenses for the last 12 months
        data = []
        for i in range(12):
            date = datetime.now() - timedelta(days=30 * i)
            month = date.month
            year = date.year
            total = current_user.get_monthly_total(month, year)
            data.append({
                'month': date.strftime('%B %Y'),
                'total': float(total)
            })
        data.reverse()
        return jsonify(data)
    
    elif chart_type == 'category':
        # Category breakdown for current month
        data = []
        for category in current_user.categories:
            total = category.get_monthly_total()
            if total > 0:
                data.append({
                    'name': category.name,
                    'total': float(total),
                    'color': category.color
                })
        return jsonify(data)
    
    return jsonify([])

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    })

@app.errorhandler(404)
def not_found(error):
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('errors/500.html'), 500

def add_income_categories_to_all_users():
    """Add income categories to all users if they don't exist"""
    income_categories = [
        {'name': 'Salary', 'color': '#28a745', 'icon': 'briefcase'},
        {'name': 'Freelance', 'color': '#17a2b8', 'icon': 'laptop'},
        {'name': 'Investment', 'color': '#ffc107', 'icon': 'chart-line'},
        {'name': 'Other Income', 'color': '#6c757d', 'icon': 'plus-circle'}
    ]
    
    users = User.query.all()
    for user in users:
        for cat_data in income_categories:
            existing_category = Category.query.filter_by(
                name=cat_data['name'],
                user_id=user.id
            ).first()
            
            if not existing_category:
                category = Category(
                    name=cat_data['name'],
                    color=cat_data['color'],
                    icon=cat_data['icon'],
                    user_id=user.id
                )
                db.session.add(category)
    
    try:
        db.session.commit()
        logger.info("Added income categories to all users")
    except Exception as e:
        logger.error(f"Error adding income categories: {str(e)}")
        db.session.rollback()

# Initialize database
def init_db():
    """Initialize database tables"""
    with app.app_context():
        db.create_all()
        
        # Add transaction_type column if it doesn't exist
        try:
            # Check if the column exists in a fresh transaction
            db.session.rollback()  # Clean any previous failed transaction
            result = db.session.execute(db.text("SELECT transaction_type FROM expenses LIMIT 1"))
            result.fetchone()
        except Exception:
            # Column doesn't exist, add it
            try:
                db.session.rollback()  # Clean any previous failed transaction
                db.session.execute(db.text("ALTER TABLE expenses ADD COLUMN transaction_type VARCHAR(20) DEFAULT 'expense'"))
                db.session.commit()
                logger.info("Added transaction_type column to expenses table")
            except Exception as e:
                logger.error(f"Error adding transaction_type column: {str(e)}")
                db.session.rollback()
        
        # Add income categories to every user
        add_income_categories_to_all_users()
        
        logger.info("Database tables created successfully")

if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 5005))
    app.run(host='0.0.0.0', port=port, debug=os.environ.get('FLASK_ENV') == 'development')