// Personal Expense Tracker - JavaScript Application

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize form validation
    initializeFormValidation();
    
    // Initialize tooltips
    initializeTooltips();
    
    // Initialize date inputs
    initializeDateInputs();
    
    // Initialize confirmation modals
    initializeConfirmationModals();
    
    // Initialize charts if on dashboard/reports page
    if (window.location.pathname === '/dashboard' || window.location.pathname === '/reports') {
        initializeCharts();
    }
    
    // Initialize category color picker
    initializeCategoryColorPicker();
    
    // Initialize auto-save for forms
    initializeAutoSave();
    
    console.log('Personal Expense Tracker initialized successfully');
}

// Form validation
function initializeFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(form)) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            // Add loading state to submit button
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner"></span> Processing...';
            }
        });
        
        // Real-time validation
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(input);
            });
        });
    });
}

function validateForm(form) {
    let isValid = true;
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    
    inputs.forEach(input => {
        if (!validateField(input)) {
            isValid = false;
        }
    });
    
    return isValid;
}

function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.getAttribute('name');
    let isValid = true;
    let errorMessage = '';
    
    // Clear previous error states
    field.classList.remove('is-invalid');
    const errorDiv = field.parentNode.querySelector('.invalid-feedback');
    if (errorDiv) {
        errorDiv.remove();
    }
    
    // Required field validation
    if (field.hasAttribute('required') && !value) {
        isValid = false;
        errorMessage = 'This field is required';
    }
    
    // Email validation
    if (field.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            isValid = false;
            errorMessage = 'Please enter a valid email address';
        }
    }
    
    // Number validation
    if (field.type === 'number' && value) {
        const num = parseFloat(value);
        if (isNaN(num) || num < 0) {
            isValid = false;
            errorMessage = 'Please enter a valid positive number';
        }
    }
    
    // Password validation
    if (fieldName === 'password' && value) {
        if (value.length < 6) {
            isValid = false;
            errorMessage = 'Password must be at least 6 characters long';
        }
    }
    
    // Show error if invalid
    if (!isValid) {
        field.classList.add('is-invalid');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback';
        errorDiv.textContent = errorMessage;
        field.parentNode.appendChild(errorDiv);
    }
    
    return isValid;
}

// Initialize tooltips
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Initialize date inputs
function initializeDateInputs() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    
    dateInputs.forEach(input => {
        // Set default date to today if empty
        if (!input.value) {
            const today = new Date();
            const dateString = today.toISOString().split('T')[0];
            input.value = dateString;
        }
        
        // Set max date to today
        const today = new Date();
        const maxDate = today.toISOString().split('T')[0];
        input.setAttribute('max', maxDate);
    });
}

// Initialize confirmation modals
function initializeConfirmationModals() {
    const deleteButtons = document.querySelectorAll('form[onsubmit*="confirm"]');
    
    deleteButtons.forEach(form => {
        form.addEventListener('submit', function(e) {
            const confirmMessage = form.getAttribute('onsubmit').match(/confirm\('([^']+)'\)/)[1];
            if (!confirm(confirmMessage)) {
                e.preventDefault();
            }
        });
    });
}

// Initialize charts
function initializeCharts() {
    // This function is called when Chart.js is loaded
    // Chart initialization is handled in the template scripts
    if (typeof Chart !== 'undefined') {
        Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        Chart.defaults.color = '#495057';
        Chart.defaults.borderColor = '#dee2e6';
        Chart.defaults.backgroundColor = 'rgba(0, 123, 255, 0.1)';
    }
}

// Initialize category color picker
function initializeCategoryColorPicker() {
    const colorPickers = document.querySelectorAll('input[type="color"]');
    
    colorPickers.forEach(picker => {
        picker.addEventListener('change', function() {
            // Update preview if exists
            const preview = document.querySelector('.color-preview');
            if (preview) {
                preview.style.backgroundColor = this.value;
            }
        });
    });
}

// Initialize auto-save for forms
function initializeAutoSave() {
    const forms = document.querySelectorAll('form[data-auto-save]');
    
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            input.addEventListener('input', debounce(function() {
                saveFormData(form);
            }, 1000));
        });
        
        // Load saved data on page load
        loadFormData(form);
    });
}

function saveFormData(form) {
    const formData = new FormData(form);
    const data = {};
    
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    
    const formId = form.getAttribute('id') || 'default';
    localStorage.setItem(`expense-tracker-form-${formId}`, JSON.stringify(data));
}

function loadFormData(form) {
    const formId = form.getAttribute('id') || 'default';
    const savedData = localStorage.getItem(`expense-tracker-form-${formId}`);
    
    if (savedData) {
        const data = JSON.parse(savedData);
        
        Object.keys(data).forEach(key => {
            const input = form.querySelector(`[name="${key}"]`);
            if (input && input.type !== 'hidden') {
                input.value = data[key];
            }
        });
    }
}

function clearFormData(form) {
    const formId = form.getAttribute('id') || 'default';
    localStorage.removeItem(`expense-tracker-form-${formId}`);
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    }).format(new Date(date));
}

// API helper functions
function apiRequest(url, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCsrfToken()
        }
    };
    
    const mergedOptions = { ...defaultOptions, ...options };
    
    return fetch(url, mergedOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .catch(error => {
            console.error('API request failed:', error);
            throw error;
        });
}

function getCsrfToken() {
    const token = document.querySelector('input[name="csrf_token"]');
    return token ? token.value : '';
}

// Chart data fetching
function fetchChartData(type) {
    return apiRequest(`/api/chart-data?type=${type}`);
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 1050; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Export functions for global use
window.ExpenseTracker = {
    showNotification,
    formatCurrency,
    formatDate,
    apiRequest,
    fetchChartData
};

// Handle page-specific functionality
function handlePageSpecificFunctionality() {
    const path = window.location.pathname;
    
    switch (path) {
        case '/dashboard':
            initializeDashboard();
            break;
        case '/reports':
            initializeReports();
            break;
        case '/expenses':
            initializeExpensesList();
            break;
        default:
            break;
    }
}

function initializeDashboard() {
    // Dashboard-specific initialization
    console.log('Dashboard initialized');
}

function initializeReports() {
    // Reports-specific initialization
    console.log('Reports initialized');
}

function initializeExpensesList() {
    // Expenses list-specific initialization
    console.log('Expenses list initialized');
}

// Call page-specific initialization
document.addEventListener('DOMContentLoaded', handlePageSpecificFunctionality);