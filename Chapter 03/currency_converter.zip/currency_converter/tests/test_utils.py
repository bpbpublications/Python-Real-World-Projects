import pytest
from currency_converter.utils import convert_amount, format_currency_code


def test_convert_amount():
    """Test the convert_amount function."""
    # Test basic conversion
    assert convert_amount(100, 0.85) == 85.0

    # Test with different values
    assert convert_amount(1, 1.5) == 1.5
    assert convert_amount(100, 2) == 200
    assert convert_amount(50, 0.5) == 25


def test_format_currency_code():
    """Test the format_currency_code function."""
    # Test uppercase conversion
    assert format_currency_code("usd") == "USD"
    assert format_currency_code("eur") == "EUR"

    # Test already uppercase
    assert format_currency_code("USD") == "USD"

    # Test mixed case
    assert format_currency_code("uSd") == "USD"