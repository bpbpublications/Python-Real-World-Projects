import pytest
from unittest.mock import patch, MagicMock
from currency_converter.api import get_exchange_rates, get_exchange_rate, get_available_currencies


@pytest.fixture
def mock_response():
    """Create a mock API response."""
    mock = MagicMock()
    mock.status_code = 200
    mock.json.return_value = {
        "base": "USD",
        "rates": {
            "EUR": 0.85,
            "GBP": 0.75,
            "JPY": 110.0,
            "CAD": 1.25
        }
    }
    return mock


@pytest.fixture
def mock_error_response():
    """Create a mock API error response."""
    mock = MagicMock()
    mock.status_code = 400
    mock.json.return_value = {
        "error": "Invalid currency"
    }
    return mock


@patch("requests.get")
def test_get_exchange_rates_success(mock_get, mock_response):
    """Test successful API response for get_exchange_rates."""
    mock_get.return_value = mock_response

    rates, error = get_exchange_rates("USD")

    assert error is None
    assert isinstance(rates, dict)
    assert len(rates) == 4
    assert rates["EUR"] == 0.85
    assert rates["GBP"] == 0.75
    mock_get.assert_called_once_with("https://api.exchangerate-api.com/v4/latest/USD")


@patch("requests.get")
def test_get_exchange_rates_error(mock_get, mock_error_response):
    """Test API error response for get_exchange_rates."""
    mock_get.return_value = mock_error_response

    rates, error = get_exchange_rates("XYZ")  # Invalid currency

    assert rates is None
    assert error is not None
    assert "API Error" in error
    assert "Invalid currency" in error


@patch("currency_converter.api.get_exchange_rates")
def test_get_exchange_rate_success(mock_get_rates):
    """Test successful exchange rate retrieval."""
    mock_get_rates.return_value = ({"EUR": 0.85, "GBP": 0.75}, None)

    rate, error = get_exchange_rate("USD", "EUR")

    assert error is None
    assert rate == 0.85
    mock_get_rates.assert_called_once_with("USD")


@patch("currency_converter.api.get_exchange_rates")
def test_get_exchange_rate_currency_not_found(mock_get_rates):
    """Test exchange rate retrieval with unknown currency."""
    mock_get_rates.return_value = ({"EUR": 0.85, "GBP": 0.75}, None)

    rate, error = get_exchange_rate("USD", "XYZ")  # XYZ not in rates

    assert rate is None
    assert error is not None
    assert "Currency not found" in error


@patch("currency_converter.api.get_exchange_rates")
def test_get_exchange_rate_api_error(mock_get_rates):
    """Test exchange rate retrieval with API error."""
    mock_get_rates.return_value = (None, "API Error: Something went wrong")

    rate, error = get_exchange_rate("USD", "EUR")

    assert rate is None
    assert error == "API Error: Something went wrong"


@patch("currency_converter.api.get_exchange_rates")
def test_get_available_currencies_success(mock_get_rates):
    """Test successful currency list retrieval."""
    mock_get_rates.return_value = ({"EUR": 0.85, "GBP": 0.75, "JPY": 110.0}, None)

    currencies, error = get_available_currencies()

    assert error is None
    assert isinstance(currencies, list)
    assert len(currencies) == 4  # USD + 3 others
    assert "USD" in currencies
    assert "EUR" in currencies
    assert "GBP" in currencies
    assert "JPY" in currencies
    assert currencies == ["EUR", "GBP", "JPY", "USD"]  # Should be sorted


@patch("currency_converter.api.get_exchange_rates")
def test_get_available_currencies_error(mock_get_rates):
    """Test currency list retrieval with API error."""
    mock_get_rates.return_value = (None, "API Error: Something went wrong")

    currencies, error = get_available_currencies()

    assert currencies is None
    assert error == "API Error: Something went wrong"