# Currency Converter CLI

A command-line application for converting between currencies using real-time exchange rates.

## Installation

```bash
pip install -e .

# Get the exchange rate between two currencies
currency_converter rate USD EUR

# Convert an amount from one currency to another
currency_converter convert 100 USD EUR

# List available currencies
currency_converter list