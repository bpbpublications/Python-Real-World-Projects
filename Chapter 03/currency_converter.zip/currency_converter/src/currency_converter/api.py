import requests
from typing import Dict, Tuple, Optional, List


def get_exchange_rates(base_currency: str) -> Tuple[Optional[Dict[str, float]], Optional[str]]:
    """
    Fetch exchange rates for a base currency.

    Args:
        base_currency: The currency code to get rates for (e.g., 'USD')

    Returns:
        A tuple containing (rates_dict, error_message)
        - rates_dict: Dictionary of currency codes to exchange rates, or None if an error occurred
        - error_message: Error message if an error occurred, or None if successful
    """
    url = f"https://api.exchangerate-api.com/v4/latest/{base_currency.upper()}"

    try:
        response = requests.get(url)
        data = response.json()

        if response.status_code != 200:
            message = data.get("error", "Unknown error")
            return None, f"API Error: {message}"

        if "rates" not in data:
            return None, "Unexpected API response format"

        return data["rates"], None

    except requests.exceptions.ConnectionError:
        return None, "Connection error: Could not connect to the API"
    except requests.exceptions.Timeout:
        return None, "Timeout error: The API request timed out"
    except requests.exceptions.RequestException as e:
        return None, f"Request error: {e}"
    except Exception as e:
        return None, f"Unexpected error: {e}"


def get_exchange_rate(from_currency: str, to_currency: str) -> Tuple[Optional[float], Optional[str]]:
    """
    Get the exchange rate between two currencies.

    Args:
        from_currency: Currency code to convert from
        to_currency: Currency code to convert to

    Returns:
        A tuple containing (exchange_rate, error_message)
        - exchange_rate: The exchange rate as a float, or None if an error occurred
        - error_message: Error message if an error occurred, or None if successful
    """
    from_currency = from_currency.upper()
    to_currency = to_currency.upper()

    rates, error = get_exchange_rates(from_currency)
    if error:
        return None, error

    if to_currency not in rates:
        return None, f"Currency not found: {to_currency}"

    return rates[to_currency], None


def get_available_currencies() -> Tuple[Optional[List[str]], Optional[str]]:
    """
    Get a list of available currency codes.

    Returns:
        A tuple containing (currency_list, error_message)
        - currency_list: List of currency codes, or None if an error occurred
        - error_message: Error message if an error occurred, or None if successful
    """
    # Using USD as base currency to get all available currencies
    rates, error = get_exchange_rates("USD")
    if error:
        return None, error

    # Get all currency codes (including USD which isn't in the rates)
    currencies = ["USD"] + list(rates.keys())
    return sorted(currencies), None