"""Currency Converter CLI - Convert between currencies using real-time exchange rates."""

__version__ = "0.1.0"