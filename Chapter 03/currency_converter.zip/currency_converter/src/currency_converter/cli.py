import argparse
import sys
from typing import List, Optional

from . import __version__
from .api import get_exchange_rate, get_available_currencies
from .utils import (
    convert_amount,
    display_exchange_rate,
    display_conversion,
    display_currencies,
    display_error
)


def parse_args(args: Optional[List[str]] = None) -> argparse.Namespace:
    """
    Parse command-line arguments.

    Args:
        args: List of command-line arguments (defaults to sys.argv[1:])

    Returns:
        The parsed arguments
    """
    # Create the top-level parser
    parser = argparse.ArgumentParser(
        description="Currency Converter CLI - Convert between currencies using real-time exchange rates",
        epilog="Example: currency_converter convert 100 USD EUR"
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"Currency Converter CLI v{__version__}"
    )

    # Create subparsers for different commands
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Parser for the "rate" command
    rate_parser = subparsers.add_parser(
        "rate",
        help="Get the exchange rate between two currencies"
    )
    rate_parser.add_argument(
        "from_currency",
        help="Currency to convert from (e.g., USD)"
    )
    rate_parser.add_argument(
        "to_currency",
        help="Currency to convert to (e.g., EUR)"
    )

    # Parser for the "convert" command
    convert_parser = subparsers.add_parser(
        "convert",
        help="Convert an amount from one currency to another"
    )
    convert_parser.add_argument(
        "amount",
        type=float,
        help="Amount to convert"
    )
    convert_parser.add_argument(
        "from_currency",
        help="Currency to convert from (e.g., USD)"
    )
    convert_parser.add_argument(
        "to_currency",
        help="Currency to convert to (e.g., EUR)"
    )

    # Parser for the "list" command
    subparsers.add_parser(
        "list",
        help="List available currencies"
    )

    return parser.parse_args(args)


def rate_command(from_currency: str, to_currency: str) -> int:
    """
    Execute the "rate" command.

    Args:
        from_currency: Currency to convert from
        to_currency: Currency to convert to

    Returns:
        Exit code (0 for success, non-zero for errors)
    """
    rate, error = get_exchange_rate(from_currency, to_currency)

    if error:
        display_error(error)
        return 1

    display_exchange_rate(from_currency, to_currency, rate)
    return 0


def convert_command(amount: float, from_currency: str, to_currency: str) -> int:
    """
    Execute the "convert" command.

    Args:
        amount: Amount to convert
        from_currency: Currency to convert from
        to_currency: Currency to convert to

    Returns:
        Exit code (0 for success, non-zero for errors)
    """
    if amount < 0:
        display_error("Amount cannot be negative")
        return 1

    rate, error = get_exchange_rate(from_currency, to_currency)

    if error:
        display_error(error)
        return 1

    converted_amount = convert_amount(amount, rate)
    display_conversion(amount, from_currency, to_currency, converted_amount)
    return 0


def list_command() -> int:
    """
    Execute the "list" command.

    Returns:
        Exit code (0 for success, non-zero for errors)
    """
    currencies, error = get_available_currencies()

    if error:
        display_error(error)
        return 1

    display_currencies(currencies)
    return 0


def main(args: Optional[List[str]] = None) -> int:
    """
    Main entry point for the CLI application.

    Args:
        args: Command-line arguments (defaults to sys.argv[1:])

    Returns:
        Exit code (0 for success, non-zero for errors)
    """
    parsed_args = parse_args(args)

    if parsed_args.command == "rate":
        return rate_command(parsed_args.from_currency, parsed_args.to_currency)

    elif parsed_args.command == "convert":
        return convert_command(
            parsed_args.amount,
            parsed_args.from_currency,
            parsed_args.to_currency
        )

    elif parsed_args.command == "list":
        return list_command()

    else:
        # If no command is provided, show help
        parse_args(["--help"])
        return 1


if __name__ == "__main__":
    sys.exit(main())