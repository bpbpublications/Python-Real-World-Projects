from typing import Dict, List, Tuple
from rich.console import Console
from rich.table import Table

# Create a console for rich output
console = Console()


def convert_amount(amount: float, rate: float) -> float:
    """
    Convert an amount using the given exchange rate.

    Args:
        amount: The amount to convert
        rate: The exchange rate

    Returns:
        The converted amount
    """
    return amount * rate


def format_currency_code(code: str) -> str:
    """Format a currency code for display."""
    return code.upper()


def display_exchange_rate(from_currency: str, to_currency: str, rate: float) -> None:
    """
    Display the exchange rate between two currencies.

    Args:
        from_currency: Currency code to convert from
        to_currency: Currency code to convert to
        rate: The exchange rate
    """
    from_currency = format_currency_code(from_currency)
    to_currency = format_currency_code(to_currency)

    console.print(f"Exchange rate: ", end="")
    console.print(f"1 {from_currency} = [bold green]{rate:.4f}[/bold green] {to_currency}")


def display_conversion(amount: float, from_currency: str, to_currency: str,
                       converted_amount: float) -> None:
    """
    Display the result of a currency conversion.

    Args:
        amount: Original amount
        from_currency: Currency code converted from
        to_currency: Currency code converted to
        converted_amount: The converted amount
    """
    from_currency = format_currency_code(from_currency)
    to_currency = format_currency_code(to_currency)

    console.print(f"{amount:.2f} {from_currency} = ", end="")
    console.print(f"[bold green]{converted_amount:.2f}[/bold green] {to_currency}")


def display_error(message: str) -> None:
    """
    Display an error message.

    Args:
        message: The error message to display
    """
    console.print(f"[bold red]Error:[/bold red] {message}")


def display_currencies(currencies: List[str], currency_names: Dict[str, str] = None) -> None:
    """
    Display a table of available currencies.

    Args:
        currencies: List of currency codes
        currency_names: Optional dictionary mapping currency codes to their names
    """
    table = Table(title="Available Currencies")
    table.add_column("Code", style="bold")

    if currency_names:
        table.add_column("Currency Name")

        for code in currencies:
            name = currency_names.get(code, "Unknown")
            table.add_row(code, name)
    else:
        # Simple list if we don't have names
        # Create rows of 5 currencies each for compact display
        row_size = 5
        for i in range(0, len(currencies), row_size):
            row = currencies[i:i + row_size]
            table.add_row(" ".join(row))

    console.print(table)