import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from datetime import datetime, timedelta


def create_line_plot():
    """Create a simple line plot."""
    # Generate data
    x = np.linspace(0, 10, 100)
    y = np.sin(x)

    # Create a line plot
    plt.figure(figsize=(10, 6))
    plt.plot(x, y, 'b-', linewidth=2, label='sin(x)')
    plt.title('Simple Line Plot')
    plt.xlabel('x')
    plt.ylabel('sin(x)')
    plt.grid(True)
    plt.legend()

    # Save the plot
    plt.savefig('line_plot.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_bar_chart():
    """Create a simple bar chart."""
    categories = ['Category A', 'Category B', 'Category C', 'Category D']
    values = [4, 7, 3, 8]

    plt.figure(figsize=(10, 6))
    plt.bar(categories, values, color='skyblue')
    plt.title('Simple Bar Chart')
    plt.xlabel('Categories')
    plt.ylabel('Values')
    plt.grid(True, axis='y')

    # Save the plot
    plt.savefig('bar_chart.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_scatter_plot():
    """Create a scatter plot."""
    # Generate random data
    np.random.seed(42)  # For reproducibility
    x = np.random.rand(50)
    y = np.random.rand(50)
    sizes = np.random.rand(50) * 1000
    colors = np.random.rand(50)

    plt.figure(figsize=(10, 6))
    scatter = plt.scatter(x, y, s=sizes, c=colors, alpha=0.7)
    plt.title('Scatter Plot')
    plt.xlabel('X Value')
    plt.ylabel('Y Value')
    plt.colorbar(scatter, label='Color Value')
    plt.grid(True)

    # Save the plot
    plt.savefig('scatter_plot.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_histogram():
    """Create a histogram."""
    # Generate random data
    np.random.seed(42)  # For reproducibility
    data = np.random.randn(1000)

    plt.figure(figsize=(10, 6))
    plt.hist(data, bins=30, alpha=0.7, color='skyblue', edgecolor='black')
    plt.title('Histogram')
    plt.xlabel('Value')
    plt.ylabel('Frequency')
    plt.grid(True, axis='y')

    # Save the plot
    plt.savefig('histogram.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_multiple_plots():
    """Create multiple plots on the same axes."""
    x = np.linspace(0, 10, 100)

    plt.figure(figsize=(10, 6))
    plt.plot(x, np.sin(x), 'b-', label='sin(x)')
    plt.plot(x, np.cos(x), 'r--', label='cos(x)')
    plt.title('Sine and Cosine Functions')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.grid(True)

    # Save the plot
    plt.savefig('multiple_plots.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_subplots():
    """Create subplots."""
    x = np.linspace(0, 10, 100)

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))

    # Top-left subplot
    axes[0, 0].plot(x, np.sin(x), 'b-')
    axes[0, 0].set_title('Sine Function')
    axes[0, 0].grid(True)

    # Top-right subplot
    axes[0, 1].plot(x, np.cos(x), 'r-')
    axes[0, 1].set_title('Cosine Function')
    axes[0, 1].grid(True)

    # Bottom-left subplot
    axes[1, 0].plot(x, np.sin(x) * np.cos(x), 'g-')
    axes[1, 0].set_title('Sine * Cosine')
    axes[1, 0].grid(True)

    # Bottom-right subplot
    axes[1, 1].plot(x, np.sin(x) + np.cos(x), 'm-')
    axes[1, 1].set_title('Sine + Cosine')
    axes[1, 1].grid(True)

    plt.tight_layout()

    # Save the plot
    plt.savefig('subplots.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_styled_plot():
    """Create a styled plot."""
    # Use a predefined style
    plt.style.use('seaborn-v0_8-darkgrid')

    x = np.linspace(0, 10, 100)
    y = np.sin(x)

    plt.figure(figsize=(10, 6))
    plt.plot(x, y, 'o-', color='#ff7f0e', linewidth=2, markersize=4, alpha=0.8)
    plt.title('Styled Line Plot', fontsize=16)
    plt.xlabel('X Axis', fontsize=12)
    plt.ylabel('Y Axis', fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)

    # Save the plot
    plt.savefig('styled_plot.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_time_series_plot():
    """Create a time series plot."""
    # Generate time series data
    dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
    values = np.cumsum(np.random.randn(100))

    plt.figure(figsize=(12, 6))
    plt.plot(dates, values, 'b-', linewidth=2)
    plt.title('Time Series Plot')
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.grid(True)
    plt.tight_layout()

    # Format date axis
    plt.gcf().autofmt_xdate()

    # Save the plot
    plt.savefig('time_series.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_pie_chart():
    """Create a pie chart."""
    labels = ['A', 'B', 'C', 'D', 'E']
    sizes = [15, 30, 25, 10, 20]
    explode = (0, 0.1, 0, 0, 0)  # Explode the 2nd slice

    plt.figure(figsize=(10, 8))
    plt.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
            shadow=True, startangle=90)
    plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
    plt.title('Pie Chart')

    # Save the plot
    plt.savefig('pie_chart.png', dpi=300, bbox_inches='tight')
    plt.close()


if __name__ == "__main__":
    create_line_plot()
    create_bar_chart()
    create_scatter_plot()
    create_histogram()
    create_multiple_plots()
    create_subplots()
    create_styled_plot()
    create_time_series_plot()
    create_pie_chart()

    print("All plots have been created and saved as PNG files.")