import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def create_distribution_plot():
    """Create a distribution plot."""
    # Set the style
    sns.set_style("whitegrid")

    # Generate data
    np.random.seed(42)  # For reproducibility
    data = np.random.normal(0, 1, 1000)

    # Distribution plot
    plt.figure(figsize=(10, 6))
    sns.histplot(data, kde=True, bins=30, color='skyblue')
    plt.title('Distribution Plot')
    plt.xlabel('Value')
    plt.ylabel('Frequency')

    # Save the plot
    plt.savefig('seaborn_distribution.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_categorical_plots():
    """Create categorical plots."""
    # Set the style
    sns.set_style("whitegrid")

    # Create sample data
    np.random.seed(42)  # For reproducibility
    categories = ['A', 'B', 'C', 'D']
    data = pd.DataFrame({
        'Category': np.random.choice(categories, 100),
        'Value': np.random.randn(100) + 5
    })

    # Box plot
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Category', y='Value', data=data)
    plt.title('Box Plot')

    # Save the plot
    plt.savefig('seaborn_boxplot.png', dpi=300, bbox_inches='tight')
    plt.close()

    # Violin plot
    plt.figure(figsize=(10, 6))
    sns.violinplot(x='Category', y='Value', data=data)
    plt.title('Violin Plot')

    # Save the plot
    plt.savefig('seaborn_violinplot.png', dpi=300, bbox_inches='tight')
    plt.close()

    # Swarm plot
    plt.figure(figsize=(10, 6))
    sns.swarmplot(x='Category', y='Value', data=data)
    plt.title('Swarm Plot')

    # Save the plot
    plt.savefig('seaborn_swarmplot.png', dpi=300, bbox_inches='tight')
    plt.close()

    # Bar plot
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Category', y='Value', data=data)
    plt.title('Bar Plot')

    # Save the plot
    plt.savefig('seaborn_barplot.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_relationship_plots():
    """Create relationship plots."""
    # Set the style
    sns.set_style("whitegrid")

    # Create sample data
    np.random.seed(42)  # For reproducibility
    n = 100
    data = pd.DataFrame({
        'x': np.random.randn(n),
        'y': np.random.randn(n),
        'category': np.random.choice(['Group A', 'Group B', 'Group C'], n),
        'size': np.random.rand(n) * 10
    })

    # Scatter plot with regression line
    plt.figure(figsize=(10, 6))
    sns.regplot(x='x', y='y', data=data, scatter_kws={'alpha': 0.5})
    plt.title('Regression Plot')

    # Save the plot
    plt.savefig('seaborn_regplot.png', dpi=300, bbox_inches='tight')
    plt.close()

    # Scatter plot with categories and sizes
    plt.figure(figsize=(10, 6))
    sns.scatterplot(x='x', y='y', hue='category', size='size', data=data, alpha=0.7)
    plt.title('Categorical Scatter Plot')

    # Save the plot
    plt.savefig('seaborn_scatterplot.png', dpi=300, bbox_inches='tight')
    plt.close()

    # Line plot
    plt.figure(figsize=(10, 6))
    sns.lineplot(x='x', y='y', hue='category', data=data.sort_values('x'))
    plt.title('Line Plot')

    # Save the plot
    plt.savefig('seaborn_lineplot.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_pair_plot():
    """Create a pair plot."""
    # Set the style
    sns.set_style("whitegrid")

    # Generate multivariate data
    np.random.seed(42)  # For reproducibility
    data = pd.DataFrame({
        'Feature A': np.random.randn(100),
        'Feature B': np.random.randn(100),
        'Feature C': np.random.randn(100),
        'Feature D': np.random.randn(100),
        'Category': np.random.choice(['Group 1', 'Group 2'], 100)
    })

    # Create a pair plot
    g = sns.pairplot(data, hue='Category')
    plt.subplots_adjust(top=0.95)
    g.fig.suptitle('Pair Plot of Features', y=1.02)

    # Save the plot
    g.savefig('seaborn_pairplot.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_heatmap():
    """Create a heatmap."""
    # Set the style
    sns.set_style("white")

    # Generate correlation matrix
    np.random.seed(42)  # For reproducibility
    corr_data = pd.DataFrame(np.random.randn(10, 10))
    corr_matrix = corr_data.corr()

    # Create a heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, square=True)
    plt.title('Correlation Heatmap')

    # Save the plot
    plt.savefig('seaborn_heatmap.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_facet_grid():
    """Create a facet grid plot."""
    # Set the style
    sns.set_style("whitegrid")

    # Create sample data
    np.random.seed(42)  # For reproducibility
    n = 200
    data = pd.DataFrame({
        'x': np.random.randn(n),
        'y': np.random.randn(n),
        'category1': np.random.choice(['A', 'B'], n),
        'category2': np.random.choice(['X', 'Y', 'Z'], n)
    })

    # Create a facet grid
    g = sns.FacetGrid(data, col='category1', row='category2', height=4, aspect=1.5)
    g.map(sns.scatterplot, 'x', 'y')
    g.add_legend()
    g.fig.subplots_adjust(top=0.9)
    g.fig.suptitle('Multi-panel Plot by Categories', y=1.05)

    # Save the plot
    g.savefig('seaborn_facetgrid.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_joint_plot():
    """Create a joint plot."""
    # Set the style
    sns.set_style("whitegrid")

    # Generate data
    np.random.seed(42)  # For reproducibility
    x = np.random.randn(1000)
    y = x * 0.5 + np.random.randn(1000) * 0.5

    # Create joint plot
    g = sns.jointplot(x=x, y=y, kind='scatter', marginal_kws=dict(bins=30))
    g.fig.suptitle('Joint Plot', y=1.02)

    # Save the plot
    g.savefig('seaborn_jointplot.png', dpi=300, bbox_inches='tight')
    plt.close()

    # Create joint plot with kernel density estimation
    g = sns.jointplot(x=x, y=y, kind='kde', fill=True)
    g.fig.suptitle('Joint Plot with KDE', y=1.02)

    # Save the plot
    g.savefig('seaborn_jointplot_kde.png', dpi=300, bbox_inches='tight')
    plt.close()


def create_custom_palette_plot():
    """Create a plot with custom color palette."""
    # Define a custom color palette
    colors = ["#ff9999", "#66b3ff", "#99ff99", "#ffcc99"]
    custom_palette = sns.color_palette(colors)

    # Create a plot with the custom palette
    plt.figure(figsize=(10, 6))
    sns.barplot(x=['A', 'B', 'C', 'D'], y=[3, 7, 5, 9], palette=custom_palette)
    plt.title('Custom Color Palette')

    # Save the plot
    plt.savefig('seaborn_custom_palette.png', dpi=300, bbox_inches='tight')
    plt.close()


if __name__ == "__main__":
    create_distribution_plot()
    create_categorical_plots()
    create_relationship_plots()
    create_pair_plot()
    create_heatmap()
    create_facet_grid()
    create_joint_plot()
    create_custom_palette_plot()

    print("All Seaborn plots have been created and saved as PNG files.")