#!/usr/bin/env python3
"""
Test script to verify the Stock Dashboard is working correctly.
This script tests all components of the dashboard independently.
"""

import pandas as pd
import yfinance as yf
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import panel as pn


def test_data_fetch():
    """Test if we can fetch stock data from Yahoo Finance"""
    print("Testing data fetch...")
    try:
        stock = yf.Ticker("AAPL")
        data = stock.history(period="5d")
        info = stock.info

        print(f"✓ Data fetched successfully: {data.shape[0]} rows, {data.shape[1]} columns")
        print(f"✓ Stock info retrieved: {len(info)} fields")
        print(f"✓ Date range: {data.index[0].date()} to {data.index[-1].date()}")
        return True, data, info
    except Exception as e:
        print(f"✗ Error fetching data: {e}")
        return False, pd.DataFrame(), {}


def test_chart_creation(data):
    """Test if we can create Plotly charts"""
    print("\nTesting chart creation...")
    try:
        fig = make_subplots(
            rows=2, cols=1,
            shared_xaxes=True,
            vertical_spacing=0.1,
            subplot_titles=('AAPL Stock Price', 'Volume'),
            row_heights=[0.7, 0.3]
        )

        # Add candlestick
        fig.add_trace(
            go.Candlestick(
                x=data.index,
                open=data['Open'],
                high=data['High'],
                low=data['Low'],
                close=data['Close'],
                name='Price'
            ),
            row=1, col=1
        )

        # Add volume
        fig.add_trace(
            go.Bar(
                x=data.index,
                y=data['Volume'],
                name='Volume'
            ),
            row=2, col=1
        )

        fig.update_layout(
            title='AAPL Stock Analysis',
            xaxis_rangeslider_visible=False,
            height=600
        )

        print("✓ Candlestick chart created successfully")
        print("✓ Volume chart added successfully")
        print("✓ Chart layout configured properly")
        return True, fig
    except Exception as e:
        print(f"✗ Error creating chart: {e}")
        return False, None


def test_panel_components():
    """Test if Panel components work correctly"""
    print("\nTesting Panel components...")
    try:
        pn.extension('plotly')

        # Test basic Panel components
        text_input = pn.widgets.TextInput(name="Ticker", value="AAPL")
        select = pn.widgets.Select(name="Period", options=["1d", "5d", "1mo"])
        button = pn.widgets.Button(name="Update", button_type="primary")

        print("✓ Text input widget created")
        print("✓ Select widget created")
        print("✓ Button widget created")

        # Test HTML pane
        html_pane = pn.pane.HTML("<h3>Test HTML Content</h3>")
        print("✓ HTML pane created")

        return True
    except Exception as e:
        print(f"✗ Error with Panel components: {e}")
        return False


def run_all_tests():
    """Run all dashboard tests"""
    print("=" * 50)
    print("STOCK DASHBOARD TEST SUITE")
    print("=" * 50)

    # Test 1: Data fetching
    data_success, data, info = test_data_fetch()

    # Test 2: Chart creation (only if data fetch succeeded)
    chart_success = False
    if data_success and not data.empty:
        chart_success, fig = test_chart_creation(data)

    # Test 3: Panel components
    panel_success = test_panel_components()

    # Summary
    print("\n" + "=" * 50)
    print("TEST RESULTS SUMMARY")
    print("=" * 50)
    print(f"Data Fetching:     {'✓ PASS' if data_success else '✗ FAIL'}")
    print(f"Chart Creation:    {'✓ PASS' if chart_success else '✗ FAIL'}")
    print(f"Panel Components:  {'✓ PASS' if panel_success else '✗ FAIL'}")

    overall_success = data_success and chart_success and panel_success
    print(f"\nOverall Status:    {'✓ ALL TESTS PASSED' if overall_success else '✗ SOME TESTS FAILED'}")

    if overall_success:
        print("\n🎉 The dashboard should work correctly!")
        print("You can now run: panel serve main.py --show")
    else:
        print("\n⚠️  There are issues that need to be resolved.")

    return overall_success


if __name__ == "__main__":
    run_all_tests()