import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def plot_stock_price(data, ticker, period='1 Month'):
    """
    Plot the stock price over time.

    Args:
        data (pd.DataFrame): DataFrame containing the stock data
        ticker (str): The stock ticker symbol
        period (str): The time period being displayed
    """
    if data.empty:
        return plt.figure()

    plt.figure(figsize=(12, 6))
    plt.plot(data.index, data['Close'], 'b-', linewidth=2, label='Close Price')

    # Add moving averages if available
    if 'MA5' in data.columns and not data['MA5'].isna().all():
        plt.plot(data.index, data['MA5'], 'r--', label='5-Day MA')
    if 'MA20' in data.columns and not data['MA20'].isna().all():
        plt.plot(data.index, data['MA20'], 'g--', label='20-Day MA')
    if 'MA50' in data.columns and not data['MA50'].isna().all():
        plt.plot(data.index, data['MA50'], 'y--', label='50-Day MA')

    plt.title(f'{ticker} Stock Price - {period}')
    plt.xlabel('Date')
    plt.ylabel('Price ($)')
    plt.grid(True, alpha=0.3)
    plt.legend()

    return plt.gcf()  # Return the current figure


def plot_volume(data, ticker):
    """
    Plot the trading volume over time.

    Args:
        data (pd.DataFrame): DataFrame containing the stock data
        ticker (str): The stock ticker symbol
    """
    if data.empty:
        return plt.figure()

    plt.figure(figsize=(12, 4))
    plt.bar(data.index, data['Volume'], color='lightblue', alpha=0.7)
    plt.title(f'{ticker} Trading Volume')
    plt.xlabel('Date')
    plt.ylabel('Volume')
    plt.grid(True, axis='y', alpha=0.3)

    return plt.gcf()


def plot_technical_indicators(data, ticker):
    """
    Plot technical indicators for the stock.

    Args:
        data (pd.DataFrame): DataFrame containing the stock data with indicators
        ticker (str): The stock ticker symbol
    """
    if data.empty:
        return plt.figure()

    # Create subplot grid
    fig, axes = plt.subplots(3, 1, figsize=(12, 15), gridspec_kw={'height_ratios': [3, 1, 1]})

    # Price and Bollinger Bands
    axes[0].plot(data.index, data['Close'], 'b-', label='Close Price')

    if 'Upper_Band' in data.columns and not data['Upper_Band'].isna().all():
        axes[0].plot(data.index, data['Upper_Band'], 'r--', label='Upper Bollinger Band')
        axes[0].plot(data.index, data['MA20'], 'g--', label='20-Day MA')
        axes[0].plot(data.index, data['Lower_Band'], 'r--', label='Lower Bollinger Band')
        axes[0].fill_between(data.index, data['Upper_Band'], data['Lower_Band'], color='gray', alpha=0.2)

    axes[0].set_title(f'{ticker} Price and Bollinger Bands')
    axes[0].set_ylabel('Price ($)')
    axes[0].grid(True, alpha=0.3)
    axes[0].legend()

    # MACD
    if 'MACD' in data.columns and not data['MACD'].isna().all():
        axes[1].plot(data.index, data['MACD'], 'b-', label='MACD')
        axes[1].plot(data.index, data['Signal_Line'], 'r--', label='Signal Line')

        # Color bars based on MACD position relative to signal line
        for i in range(len(data)):
            if i > 0:  # Skip first bar
                if data['MACD'].iloc[i] > data['Signal_Line'].iloc[i]:
                    color = 'g'  # Green for bullish
                else:
                    color = 'r'  # Red for bearish

                axes[1].bar(data.index[i], data['MACD'].iloc[i] - data['Signal_Line'].iloc[i],
                            color=color, alpha=0.5, width=0.7)

        axes[1].set_title(f'{ticker} MACD')
        axes[1].set_ylabel('Value')
        axes[1].grid(True, alpha=0.3)
        axes[1].legend()

    # RSI
    if 'RSI' in data.columns and not data['RSI'].isna().all():
        axes[2].plot(data.index, data['RSI'], 'purple', label='RSI')
        axes[2].axhline(y=70, color='r', linestyle='--', alpha=0.5)
        axes[2].axhline(y=30, color='g', linestyle='--', alpha=0.5)
        axes[2].fill_between(data.index, 70, data['RSI'].where(data['RSI'] >= 70), color='r', alpha=0.2)
        axes[2].fill_between(data.index, 30, data['RSI'].where(data['RSI'] <= 30), color='g', alpha=0.2)
        axes[2].set_title(f'{ticker} RSI')
        axes[2].set_ylabel('RSI')
        axes[2].set_ylim(0, 100)
        axes[2].grid(True, alpha=0.3)

    plt.tight_layout()
    return fig


def create_interactive_chart(data, ticker):
    """
    Create an interactive candlestick chart with Plotly.

    Args:
        data (pd.DataFrame): DataFrame containing the stock data
        ticker (str): The stock ticker symbol

    Returns:
        plotly.graph_objs.Figure: Interactive figure
    """
    if data.empty:
        return go.Figure()

    # Create subplot with 2 rows
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True,
                        vertical_spacing=0.1,
                        subplot_titles=(f'{ticker} Stock Price', 'Volume'),
                        row_heights=[0.7, 0.3])

    # Add candlestick chart
    fig.add_trace(
        go.Candlestick(
            x=data.index,
            open=data['Open'],
            high=data['High'],
            low=data['Low'],
            close=data['Close'],
            name='Price'
        ),
        row=1, col=1
    )

    # Add moving averages if available
    if 'MA20' in data.columns and not data['MA20'].isna().all():
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['MA20'],
                line=dict(color='rgba(72, 72, 180, 0.7)', width=1),
                name='20-Day MA'
            ),
            row=1, col=1
        )

    if 'MA50' in data.columns and not data['MA50'].isna().all():
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['MA50'],
                line=dict(color='rgba(180, 72, 72, 0.7)', width=1),
                name='50-Day MA'
            ),
            row=1, col=1
        )

    # Add Bollinger Bands if available
    if 'Upper_Band' in data.columns and not data['Upper_Band'].isna().all():
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['Upper_Band'],
                line=dict(color='rgba(50, 50, 50, 0.4)', width=1, dash='dash'),
                name='Upper Band'
            ),
            row=1, col=1
        )

        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['Lower_Band'],
                line=dict(color='rgba(50, 50, 50, 0.4)', width=1, dash='dash'),
                name='Lower Band',
                fill='tonexty',
                fillcolor='rgba(50, 50, 50, 0.1)'
            ),
            row=1, col=1
        )

    # Add volume bar chart
    colors = ['green' if data['Close'][i] > data['Open'][i] else 'red'
              for i in range(len(data))]

    fig.add_trace(
        go.Bar(
            x=data.index,
            y=data['Volume'],
            marker_color=colors,
            name='Volume'
        ),
        row=2, col=1
    )

    # Update layout
    fig.update_layout(
        title=f'{ticker} Stock Analysis',
        xaxis_title='Date',
        yaxis_title='Price ($)',
        yaxis2_title='Volume',
        xaxis_rangeslider_visible=False,
        height=800,
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )

    # Update y-axis
    fig.update_yaxes(
        title_text="Price ($)",
        row=1, col=1
    )
    fig.update_yaxes(
        title_text="Volume",
        row=2, col=1
    )

    return fig