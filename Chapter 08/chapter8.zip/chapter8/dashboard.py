import panel as pn
import param
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go

# Import our modules
from stock_data import fetch_stock_data, get_stock_info, calculate_technical_indicators
from visualizations import plot_stock_price, plot_volume, plot_technical_indicators, create_interactive_chart

# Initialize Panel
pn.extension('plotly')


class StockDashboard(param.Parameterized):
    ticker = param.String(default="AAPL", doc="Stock ticker symbol")
    period = param.ObjectSelector(default="1mo", objects=["1d", "5d", "1mo", "3mo", "6mo", "1y", "2y"],
                                  doc="Time period")
    interval = param.ObjectSelector(default="1d", objects=["1m", "5m", "15m", "30m", "60m", "1d", "1wk"],
                                    doc="Data interval")

    refresh = param.Action(lambda x: x.param.trigger('refresh'), doc="Refresh data")

    def __init__(self, **params):
        super(StockDashboard, self).__init__(**params)
        self.data = pd.DataFrame()
        self.info = {}
        self.update_data()

    @param.depends('ticker', 'period', 'interval', 'refresh', watch=True)
    def update_data(self):
        """Fetch and process stock data"""
        try:
            ticker_str = str(self.ticker) if self.ticker is not None else "AAPL"
            period_str = str(self.period) if self.period is not None else "1mo"
            interval_str = str(self.interval) if self.interval is not None else "1d"

            self.data = fetch_stock_data(ticker_str, period_str, interval_str)
            self.info = get_stock_info(ticker_str)
            if not self.data.empty:
                self.data = calculate_technical_indicators(self.data)
        except Exception as e:
            print(f"Error updating data: {e}")
            self.data = pd.DataFrame()
            self.info = {}

    @param.depends('ticker', 'period', 'interval', 'refresh')
    def stock_info_panel(self):
        """Display stock information"""
        if not self.info:
            return pn.pane.Markdown(f"## No information available for {self.ticker}")

        info_md = f"""
        # {self.info.get('name', self.ticker)} ({self.ticker})

        **Sector:** {self.info.get('sector', 'N/A')}  
        **Industry:** {self.info.get('industry', 'N/A')}  
        **Market Cap:** ${self.info.get('market_cap', 0):,}  

        ## Current Trading Information

        **Current Price:** ${self.info.get('current_price', 0):.2f}  
        **Previous Close:** ${self.info.get('previous_close', 0):.2f}  
        **Open:** ${self.info.get('open', 0):.2f}  
        **Day Range:** ${self.info.get('day_low', 0):.2f} - ${self.info.get('day_high', 0):.2f}  

        ## Averages

        **50 Day Avg:** ${self.info.get('fifty_day_avg', 0):.2f}  
        **200 Day Avg:** ${self.info.get('two_hundred_day_avg', 0):.2f}  
        """

        return pn.pane.Markdown(info_md)

    @param.depends('ticker', 'period', 'interval', 'refresh')
    def interactive_chart(self):
        """Display interactive chart"""
        if self.data.empty:
            return pn.pane.Markdown(f"## No data available for {self.ticker}")

        fig = create_interactive_chart(self.data, self.ticker)
        return pn.pane.Plotly(fig, height=800)

    @param.depends('ticker', 'period', 'interval', 'refresh')
    def technical_indicators(self):
        """Display technical indicators"""
        if self.data.empty:
            return pn.pane.Markdown(f"## No data available for {self.ticker}")

        fig = plot_technical_indicators(self.data, self.ticker)
        return pn.pane.Matplotlib(fig, height=800)

    def view(self):
        """Create the dashboard view"""
        # Controls
        controls = pn.Param(
            self.param,
            widgets={
                'ticker': pn.widgets.TextInput,
                'period': pn.widgets.Select,
                'interval': pn.widgets.Select,
                'refresh': pn.widgets.Button(name='Refresh Data', button_type='primary')
            },
            name="Dashboard Controls",
            show_name=False
        )

        # Create tabs for different visualizations
        tabs = pn.Tabs(
            ('Interactive Chart', self.interactive_chart),
            ('Technical Analysis', self.technical_indicators)
        )

        # Assemble the dashboard
        dashboard = pn.Column(
            pn.Row(
                pn.Column(
                    "# Stock Price Dashboard",
                    "Analyze stock prices and technical indicators in real-time",
                    controls,
                    self.stock_info_panel,
                    width=350
                ),
                pn.Column(
                    tabs,
                    width=900
                )
            )
        )

        return dashboard