import panel as pn
import param
import pandas as pd
import numpy as np
import yfinance as yf
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Enable Panel extensions
pn.extension('plotly')


class StockDashboard(param.Parameterized):
    ticker = param.String(default="AAPL", doc="Stock ticker symbol")
    period = param.ObjectSelector(default="1mo", objects=["1d", "5d", "1mo", "3mo", "6mo", "1y"], doc="Time period")

    def __init__(self, **params):
        super().__init__(**params)
        self.data = pd.DataFrame()
        self.stock_info = {}

    def fetch_data(self):
        """Fetch stock data from Yahoo Finance"""
        try:
            stock = yf.Ticker(self.ticker)
            self.data = stock.history(period=self.period)
            self.stock_info = stock.info

            if not self.data.empty:
                # Calculate moving averages
                self.data['MA5'] = self.data['Close'].rolling(window=5).mean()
                self.data['MA20'] = self.data['Close'].rolling(window=20).mean()

        except Exception as e:
            print(f"Error fetching data: {e}")
            self.data = pd.DataFrame()
            self.stock_info = {}

    @param.depends('ticker', 'period', watch=True)
    def update_data(self):
        """Update data when parameters change"""
        self.fetch_data()

    def create_chart(self):
        """Create interactive stock chart"""
        if self.data.empty:
            return pn.pane.HTML("<h3>No data available. Please check the ticker symbol.</h3>")

        # Create candlestick chart
        fig = make_subplots(
            rows=2, cols=1,
            shared_xaxes=True,
            vertical_spacing=0.1,
            subplot_titles=(f'{self.ticker} Stock Price', 'Volume'),
            row_heights=[0.7, 0.3]
        )

        # Add candlestick
        fig.add_trace(
            go.Candlestick(
                x=self.data.index,
                open=self.data['Open'],
                high=self.data['High'],
                low=self.data['Low'],
                close=self.data['Close'],
                name='Price'
            ),
            row=1, col=1
        )

        # Add moving averages
        if 'MA5' in self.data.columns:
            fig.add_trace(
                go.Scatter(
                    x=self.data.index,
                    y=self.data['MA5'],
                    line=dict(color='blue', width=1),
                    name='5-Day MA'
                ),
                row=1, col=1
            )

        if 'MA20' in self.data.columns:
            fig.add_trace(
                go.Scatter(
                    x=self.data.index,
                    y=self.data['MA20'],
                    line=dict(color='red', width=1),
                    name='20-Day MA'
                ),
                row=1, col=1
            )

        # Add volume
        colors = ['green' if close > open else 'red'
                  for close, open in zip(self.data['Close'], self.data['Open'])]

        fig.add_trace(
            go.Bar(
                x=self.data.index,
                y=self.data['Volume'],
                marker_color=colors,
                name='Volume'
            ),
            row=2, col=1
        )

        # Update layout
        fig.update_layout(
            title=f'{self.ticker} Stock Analysis - {self.period}',
            xaxis_rangeslider_visible=False,
            height=600,
            showlegend=True
        )

        return pn.pane.Plotly(fig, height=600)

    def create_info_panel(self):
        """Create stock information panel"""
        if not self.stock_info:
            return pn.pane.HTML("<h3>No stock information available</h3>")

        info_html = f"""
        <div style="background: #f0f0f0; padding: 15px; border-radius: 8px;">
            <h3>{self.stock_info.get('longName', self.ticker)}</h3>
            <p><strong>Sector:</strong> {self.stock_info.get('sector', 'N/A')}</p>
            <p><strong>Industry:</strong> {self.stock_info.get('industry', 'N/A')}</p>
            <p><strong>Market Cap:</strong> ${self.stock_info.get('marketCap', 0):,}</p>
            <p><strong>Current Price:</strong> ${self.stock_info.get('currentPrice', 0):.2f}</p>
            <p><strong>Previous Close:</strong> ${self.stock_info.get('previousClose', 0):.2f}</p>
        </div>
        """
        return pn.pane.HTML(info_html)

    def view(self):
        """Create the complete dashboard view"""
        # Fetch initial data
        self.fetch_data()

        # Create controls
        ticker_input = pn.widgets.TextInput(
            name="Ticker Symbol",
            value=self.ticker,
            placeholder="Enter stock symbol (e.g., AAPL)"
        )
        period_select = pn.widgets.Select(
            name="Time Period",
            value=self.period,
            options=["1d", "5d", "1mo", "3mo", "6mo", "1y"]
        )
        update_button = pn.widgets.Button(name="Update Data", button_type="primary")

        # Link widgets to parameters
        def update_ticker(event):
            self.ticker = event.new
            self.fetch_data()

        def update_period(event):
            self.period = event.new
            self.fetch_data()

        def update_data(event):
            self.fetch_data()

        ticker_input.param.watch(update_ticker, 'value')
        period_select.param.watch(update_period, 'value')
        update_button.on_click(update_data)

        # Create layout
        controls = pn.Column(
            "## Stock Dashboard Controls",
            ticker_input,
            period_select,
            update_button,
            self.create_info_panel,
            width=300
        )

        main_content = pn.Column(
            "# Real-Time Stock Price Dashboard",
            "Interactive stock analysis with live data from Yahoo Finance",
            self.create_chart,
            sizing_mode='stretch_width'
        )

        return pn.Row(controls, main_content)


# Create the dashboard app
def create_app():
    dashboard = StockDashboard()
    return dashboard.view()


# Make the app servable
app = create_app()
app.servable()