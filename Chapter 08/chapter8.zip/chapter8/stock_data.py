import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta


def fetch_stock_data(ticker, period='1mo', interval='1d'):
    """
    Fetch stock data for the given ticker.

    Args:
        ticker (str): The stock ticker symbol
        period (str): The time period to fetch ('1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', etc.)
        interval (str): The data interval ('1m', '2m', '5m', '15m', '30m', '60m', '90m', '1h', '1d', etc.)

    Returns:
        pd.DataFrame: DataFrame containing the stock data
    """
    try:
        # Create ticker object
        stock = yf.Ticker(ticker.upper())

        # Fetch historical data
        data = stock.history(period=period, interval=interval)

        # Check if data is empty
        if data.empty:
            print(f"No data found for ticker {ticker}")
            return pd.DataFrame()

        # Ensure we have the required columns
        required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        if not all(col in data.columns for col in required_columns):
            print(f"Missing required columns for {ticker}")
            return pd.DataFrame()

        return data

    except Exception as e:
        print(f"Error fetching data for {ticker}: {e}")
        return pd.DataFrame()


def get_stock_info(ticker):
    """
    Get basic information about a stock.

    Args:
        ticker (str): The stock ticker symbol

    Returns:
        dict: Dictionary containing stock information
    """
    try:
        stock = yf.Ticker(ticker)
        info = stock.info
        return {
            'name': info.get('shortName', ticker),
            'sector': info.get('sector', 'Unknown'),
            'industry': info.get('industry', 'Unknown'),
            'market_cap': info.get('marketCap', 0),
            'current_price': info.get('currentPrice', 0),
            'previous_close': info.get('previousClose', 0),
            'open': info.get('open', 0),
            'day_high': info.get('dayHigh', 0),
            'day_low': info.get('dayLow', 0),
            'fifty_day_avg': info.get('fiftyDayAverage', 0),
            'two_hundred_day_avg': info.get('twoHundredDayAverage', 0)
        }
    except Exception as e:
        print(f"Error fetching info for {ticker}: {e}")
        return {}


def calculate_technical_indicators(data):
    """
    Calculate technical indicators for the stock data.

    Args:
        data (pd.DataFrame): DataFrame containing the stock data

    Returns:
        pd.DataFrame: DataFrame with technical indicators added
    """
    if data.empty:
        return data

    # Copy data to avoid modifying the original
    df = data.copy()

    # Moving Averages
    df['MA5'] = df['Close'].rolling(window=5).mean()
    df['MA20'] = df['Close'].rolling(window=20).mean()
    df['MA50'] = df['Close'].rolling(window=50).mean()

    # Relative Strength Index (RSI)
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)

    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()

    rs = avg_gain / avg_loss
    df['RSI'] = 100 - (100 / (1 + rs))

    # Moving Average Convergence Divergence (MACD)
    df['EMA12'] = df['Close'].ewm(span=12, adjust=False).mean()
    df['EMA26'] = df['Close'].ewm(span=26, adjust=False).mean()
    df['MACD'] = df['EMA12'] - df['EMA26']
    df['Signal_Line'] = df['MACD'].ewm(span=9, adjust=False).mean()

    # Bollinger Bands
    df['MA20_std'] = df['Close'].rolling(window=20).std()
    df['Upper_Band'] = df['MA20'] + (df['MA20_std'] * 2)
    df['Lower_Band'] = df['MA20'] - (df['MA20_std'] * 2)

    return df