# Python Environment Setup – Command Reference

This document contains a collection of essential terminal commands introduced in Chapter 1. These commands help you install Python, manage virtual environments, use pip, and work with tools like Git, Docker, and CI/CD. Comments are included for quick understanding.

## Python Installation & Version Check

# Check your Python version
python --version

# If Python 3 is required and not default
python3 --version

# Check pip (Python package installer) version
pip --version
pip3 --version

## Virtual Environment Setup

# Create a virtual environment named 'myenv'
python -m venv myenv

# Activate virtual environment on Windows
myenv\Scripts\activate

# Activate virtual environment on macOS/Linux
source myenv/bin/activate

# Deactivate the environment
deactivate

## pip Commands (Package Management)

# Install a package
pip install package_name

# Install a specific version of a package
pip install package_name==1.2.3

# Upgrade a package
pip install --upgrade package_name

# Install from a requirements file
pip install -r requirements.txt

# Uninstall a package
pip uninstall package_name

# List installed packages
pip list

# Show all packages and versions (useful for sharing environment)
pip freeze

# Save current packages to requirements file
pip freeze > requirements.txt

# Show info about a package
pip show package_name

# Search for a package on PyPI
pip search keyword

# List outdated packages
pip list --outdated

# Check for broken dependencies
pip check

# Show pip help
pip help

## Git & GitHub Commands

# Configure Git user identity (run once)
git config --global user.name "Your Name"
git config --global user.email "you@example.com"

# Initialize a Git repository
git init

# Check repo status
git status

# Stage a specific file
git add filename.py

# Stage all files
git add .

# Commit with message
git commit -m "Initial commit"

# View commit history
git log

# Add remote GitHub repository
git remote add origin https://github.com/yourusername/yourrepo.git

# Rename branch to main
git branch -M main

# Push local changes to GitHub
git push -u origin main

# Clone a repository
git clone https://github.com/username/repo.git

# Pull latest changes
git pull origin main

## Docker Commands

# Build a Docker image (from Dockerfile)
docker build -t myapp .

# Run the Docker container on port 8000
docker run -p 8000:8000 myapp

## Docker Compose Setup

version: '3'
services:
  app:
    build: .
    ports:
      - "5000:5000"
    volumes:
      - .:/app
    environment:
      - DEBUG=True
      - DATABASE_URL=postgresql://user:password@db/dbname
    depends_on:
      - db

  db:
    image: postgres:14
    volumes:
      - postgres_data:/var/lib/postgresql/data/
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=dbname

volumes:
  postgres_data:

## Python Testing, Linting, and Formatting

# Run tests
pytest

# Lint code
flake8 .

# Format code using Black
black .

# Run Pylint
pylint your_script.py

## Documentation Tools

# Install Sphinx
pip install sphinx

# Start Sphinx config
sphinx-quickstart

# Generate HTML documentation
make html

# Install MkDocs
pip install mkdocs

# Create MkDocs project
mkdocs new my-project

# Preview site locally
mkdocs serve

## GitHub Actions – CI Setup

name: Python Tests
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]
jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.8, 3.9, 3.10, 3.11]
    steps:
      - uses: actions/checkout@v3
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: ${{ matrix.python-version }}
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install flake8 pytest
          if [ -f requirements.txt ]; then pip install -r requirements.txt; fi
      - name: Lint
        run: flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics
      - name: Run tests
        run: pytest

## Environment Variables (.env Example)

# Example .env file (not committed to Git)
API_KEY=your_secret_api_key
DEBUG=True
DATABASE_URL=postgresql://user:password@localhost/db

from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.environ.get("API_KEY")


## Monitoring (New Relic and Datadog)

# Install New Relic agent
pip install newrelic
newrelic-admin generate-config YOUR_LICENSE_KEY newrelic.ini
NEW_RELIC_CONFIG_FILE=newrelic.ini newrelic-admin run-program gunicorn myapp:app

# Install Datadog tracing
pip install ddtrace
DD_SERVICE=myapp DD_ENV=production ddtrace-run gunicorn myapp:app

