import sys
import platform
import pkg_resources

def check_python_info():
    print("Python Version:", sys.version)
    print("Implementation:", platform.python_implementation())
    print("Platform:", platform.system(), platform.release())
    print("Architecture:", platform.architecture()[0])

def list_installed_packages():
    print("\nInstalled Packages:")
    for dist in pkg_resources.working_set:
        print(f"{dist.project_name}=={dist.version}")

if __name__ == "__main__":
    check_python_info()
    list_installed_packages()
    