BASE_URL = 'https://www.foxnews.com'
HEADERS = {
    'User-Agent': 'NewsScraperBot/1.0 (educational purposes)',
    'Accept': 'text/html,application/xhtml+xml,application/xml'
}
