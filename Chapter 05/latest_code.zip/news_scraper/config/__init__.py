# -*- coding: utf-8 -*-
# news_scraper.config
#  This module contains the configuration for the news scraper.
