# News Article Scraper

This project scrapes news articles and stores them in CSV/JSON formats. It includes basic scraping, robots.txt checking, and data analysis.
