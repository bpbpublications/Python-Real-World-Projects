# Suggested code may be subject to a license. Learn more: ~LicenseLog:477722132.
import csv
from datetime import datetime

def save_to_csv(data, filename=None):
    if not filename:
        filename = f"news_articles_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        # Write each item in the array (which are dictionaries) to the csv file
        # Here we are assuming that each item in the data array is a list of strings or single strings.
        # If they are dictionaries, the previous implementation with writerow(item.values()) might be more suitable.
        # This change assumes each "item" should be a single entry in the CSV, potentially a string.
        for item in data:
            writer.writerow([item]) # Write each item as a single column in the CSV row
    print(f"Saved {len(data)} items to {filename}")
