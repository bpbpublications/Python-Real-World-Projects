import pandas as pd

def analyze_scraped_data(data):
    df = pd.DataFrame(data)
    print(f"Total items: {len(df)}")
    if 'category' in df.columns:
        print("\nCategory Distribution:")
        print(df['category'].value_counts())
    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        print("\nArticles by Date:")
        print(df.groupby(df['timestamp'].dt.date).size())
    return df
