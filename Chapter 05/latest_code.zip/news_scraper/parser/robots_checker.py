import requests
import urllib.parse

def check_robots_txt(url):
    parsed = urllib.parse.urlparse(url)
    base_url = f"{parsed.scheme}://{parsed.netloc}"
    robots_url = f"{base_url}/robots.txt"
    try:
        response = requests.get(robots_url)
        if response.status_code != 200:
            return {'success': False, 'message': f"robots.txt error {response.status_code}", 'can_scrape': None}
        content = response.text
        result = {'success': True, 'robots_url': robots_url, 'content': content[:500], 'disallowed_paths': [], 'can_scrape': True}
        path = parsed.path or '/'
        for line in content.splitlines():
            line = line.strip().lower()
            if not line or line.startswith('#'):
                continue
            if line.startswith('disallow:'):
                dis_path = line.split(':', 1)[1].strip()
                if dis_path and (path == dis_path or path.startswith(dis_path.rstrip('*'))):
                    result['can_scrape'] = False
                    result['disallowed_paths'].append(dis_path)
        return result
    except Exception as e:
        return {'success': False, 'message': str(e), 'can_scrape': None}
