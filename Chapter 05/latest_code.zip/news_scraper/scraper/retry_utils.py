import requests
import time
import random

def fetch_with_retry(url, max_retries=3, base_delay=2):
    headers = {'User-Agent': 'SimplePythonScraper/1.0 (Educational)', 'Accept': 'text/html'}
    for attempt in range(1, max_retries + 1):
        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            print(f"Attempt {attempt} failed: {e}")
            if attempt < max_retries:
                delay = base_delay * (2 ** (attempt - 1)) + random.uniform(0, 1)
                print(f"Retrying in {delay:.2f} seconds...")
                time.sleep(delay)
    return None
