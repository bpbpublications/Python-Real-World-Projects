import requests
from bs4 import BeautifulSoup
import time

def simple_scraper(url):
    time.sleep(1)
    headers = {'User-Agent': 'SimplePythonScraper/1.0 (Educational)', 'Accept': 'text/html'}
    try:
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            return {'error': f'Status code: {response.status_code}'}
        soup = BeautifulSoup(response.text, 'html.parser')
        result = {
            'title': soup.title.string if soup.title else "No title",
            'headings': {h: [tag.get_text(strip=True) for tag in soup.find_all(h)] for h in ['h1', 'h2', 'h3']},
            'links': [{'text': a.get_text(strip=True) or "[No text]", 'url': a['href']} for a in soup.find_all('a', href=True)[:10]],
            'meta': {
                'description': soup.find('meta', attrs={'name': 'description'})['content'] if soup.find('meta', attrs={'name': 'description'}) else None,
                'keywords': soup.find('meta', attrs={'name': 'keywords'})['content'] if soup.find('meta', attrs={'name': 'keywords'}) else None
            },
            'images': [{'alt': img.get('alt', ''), 'src': img['src']} for img in soup.find_all('img', src=True)[:5]]
        }
        return result
    except Exception as e:
        return {'error': str(e)}
