import requests
from bs4 import BeautifulSoup
import time
from datetime import datetime
from config.settings import HEADERS
import re

class NewsArticleScraper:
    def __init__(self, base_url):
        self.base_url = base_url
        self.headers = HEADERS

    def fetch_page(self, url, delay=1):
        time.sleep(delay)
        try:
            response = requests.get(url, headers=self.headers)
            if response.status_code == 200:
                return response.text
            print(f"Error fetching {url}: Status code {response.status_code}")
        except Exception as e:
            print(f"Exception occurred: {e}")
        return None

    def parse_articles(self, html_content):
        print (f"length of html_content: {len(html_content)}")
        if len(html_content) < 1:
            print("No HTML content to parse")
            return []

        soup = BeautifulSoup(html_content, 'html.parser')
        text_content = soup.prettify()

        return text_content


    def scrape_multiple_pages(self):
        all_articles = []
        news_topics = ["us", "politics", "sports"]

        for topic in news_topics:
            page_url = f"{self.base_url}/{topic}/"
            print(f"\nFetching: {page_url}")
            html_content = self.fetch_page(page_url)
            articles = self.parse_articles(html_content)

            if articles:
                # Extract titles
                titles = re.findall(r'title:"(.*?)"', articles)
                print(f"\nExtracted Titles for '{topic}':")
                for title in titles:
                    print(f"- {title}")

            all_articles.extend(titles)

        return all_articles

