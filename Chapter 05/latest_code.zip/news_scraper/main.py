from scraper.news_scraper import NewsArticleScraper
from storage.csv_writer import save_to_csv
from config.settings import BASE_URL

def main():
    scraper = NewsArticleScraper(BASE_URL)
    articles = scraper.scrape_multiple_pages()
    if articles:
        save_to_csv(articles)
    else:
        print("No articles found or error occurred during scraping")

if __name__ == "__main__":
    main()
