# app/service.py
from app.models import Task, TaskCreate, TaskUpdate
from datetime import datetime
from typing import List, Dict
import uuid


class TaskService:
    def __init__(self):
        self.tasks: Dict[str, Task] = {}

    def create_task(self, task_create: TaskCreate) -> Task:
        """Create a new task."""
        now = datetime.now()
        task = Task(
            id=str(uuid.uuid4()),
            **task_create.model_dump(),
            created_at=now,
            updated_at=now
        )
        self.tasks[task.id] = task
        return task

    def get_task(self, task_id: str) -> Task:
        """Get a task by ID."""
        if task_id not in self.tasks:
            raise KeyError(f"Task with ID {task_id} not found")
        return self.tasks[task_id]

    def get_all_tasks(self) -> List[Task]:
        """Get all tasks."""
        return list(self.tasks.values())

    def update_task(self, task_id: str, task_update: TaskUpdate) -> Task:
        """Update a task."""
        if task_id not in self.tasks:
            raise KeyError(f"Task with ID {task_id} not found")

        task = self.tasks[task_id]
        update_data = task_update.model_dump(exclude_unset=True)

        for key, value in update_data.items():
            setattr(task, key, value)

        task.updated_at = datetime.now()
        self.tasks[task_id] = task
        return task

    def delete_task(self, task_id: str) -> None:
        """Delete a task."""
        if task_id not in self.tasks:
            raise KeyError(f"Task with ID {task_id} not found")

        del self.tasks[task_id]