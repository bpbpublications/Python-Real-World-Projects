# app/main.py
from fastapi import FastAPI, HTTPException, status
from app.models import Task, TaskCreate, TaskUpdate
from app.service import TaskService
from typing import List

app = FastAPI(title="Task Manager API")
task_service = TaskService()

@app.post("/tasks/", response_model=Task, status_code=status.HTTP_201_CREATED)
async def create_task(task: TaskCreate):
    """Create a new task."""
    return task_service.create_task(task)

@app.get("/tasks/{task_id}", response_model=Task)
async def get_task(task_id: str):
    """Get a task by ID."""
    try:
        return task_service.get_task(task_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task with ID {task_id} not found"
        )

@app.get("/tasks/", response_model=List[Task])
async def get_all_tasks():
    """Get all tasks."""
    return task_service.get_all_tasks()

@app.put("/tasks/{task_id}", response_model=Task)
async def update_task(task_id: str, task_update: TaskUpdate):
    """Update a task."""
    try:
        return task_service.update_task(task_id, task_update)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task with ID {task_id} not found"
        )

@app.delete("/tasks/{task_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_task(task_id: str):
    """Delete a task."""
    try:
        task_service.delete_task(task_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task with ID {task_id} not found"
        )