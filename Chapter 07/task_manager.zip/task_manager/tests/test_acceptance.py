import pytest
from fastapi.testclient import TestClient
from pytest_bdd import given, when, then, parsers, scenarios
from app.main import app

# Load the feature file
scenarios("features/task_management.feature")


# ---------- Fixtures ----------

@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def context():
    return {}


# ---------- Step Definitions ----------

@given(parsers.parse('I have a task with title "{title}"'))
def create_initial_task(client, context, title):
    response = client.post("/tasks/", json={"title": title})
    assert response.status_code == 201
    context["task"] = response.json()


@when(parsers.parse('I create a task with title "{title}"'))
def create_task(client, context, title):
    response = client.post("/tasks/", json={"title": title})
    assert response.status_code == 201
    context["task"] = response.json()


@then('the task should be created successfully')
def task_created(context):
    assert "id" in context["task"]


@then(parsers.parse('the task should have title "{title}"'))
def task_has_title(context, title):
    assert context["task"]["title"] == title


@when('I mark the task as completed')
def mark_task_completed(client, context):
    task_id = context["task"]["id"]
    response = client.put(f"/tasks/{task_id}", json={"completed": True})
    assert response.status_code == 200
    context["task"] = response.json()


@then('the task should be marked as completed')
def task_is_completed(context):
    assert context["task"]["completed"] is True
