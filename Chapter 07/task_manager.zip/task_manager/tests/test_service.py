# tests/test_service.py
import pytest
from app.service import TaskService
from app.models import TaskCreate, TaskUpdate


@pytest.fixture
def task_service():
    """Creates a TaskService with empty storage for testing."""
    return TaskService()


def test_create_task(task_service):
    """Test creating a new task."""
    task_data = TaskCreate(
        title="Test Task",
        description="A test task",
        priority=3
    )

    task = task_service.create_task(task_data)

    assert task.title == "Test Task"
    assert task.description == "A test task"
    assert task.priority == 3
    assert task.completed is False
    assert task.id is not None


def test_get_task(task_service):
    """Test retrieving a task by ID."""
    # Create a task first
    task_data = TaskCreate(title="Get Test", priority=2)
    created_task = task_service.create_task(task_data)

    # Retrieve the task
    task = task_service.get_task(created_task.id)

    assert task is not None
    assert task.id == created_task.id
    assert task.title == "Get Test"

    # Test non-existent task
    with pytest.raises(KeyError):
        task_service.get_task("non-existent-id")


def test_get_all_tasks(task_service):
    """Test retrieving all tasks."""
    # Create a few tasks
    task_service.create_task(TaskCreate(title="Task 1"))
    task_service.create_task(TaskCreate(title="Task 2"))
    task_service.create_task(TaskCreate(title="Task 3"))

    tasks = task_service.get_all_tasks()

    assert len(tasks) == 3
    assert any(task.title == "Task 1" for task in tasks)
    assert any(task.title == "Task 2" for task in tasks)
    assert any(task.title == "Task 3" for task in tasks)


def test_update_task(task_service):
    """Test updating a task."""
    # Create a task first
    task_data = TaskCreate(title="Original Title", description="Original Description", priority=1)
    created_task = task_service.create_task(task_data)

    # Update the task
    update_data = TaskUpdate(title="Updated Title", priority=4, completed=True)
    updated_task = task_service.update_task(created_task.id, update_data)

    assert updated_task.id == created_task.id
    assert updated_task.title == "Updated Title"  # Updated
    assert updated_task.description == "Original Description"  # Unchanged
    assert updated_task.priority == 4  # Updated
    assert updated_task.completed is True  # Updated

    # Test updating non-existent task
    with pytest.raises(KeyError):
        task_service.update_task("non-existent-id", update_data)


def test_delete_task(task_service):
    """Test deleting a task."""
    # Create a task first
    task_data = TaskCreate(title="Task to Delete")
    created_task = task_service.create_task(task_data)

    # Verify task exists
    tasks_before = task_service.get_all_tasks()
    assert any(task.id == created_task.id for task in tasks_before)

    # Delete the task
    task_service.delete_task(created_task.id)

    # Verify task no longer exists
    tasks_after = task_service.get_all_tasks()
    assert not any(task.id == created_task.id for task in tasks_after)

    # Test deleting non-existent task
    with pytest.raises(KeyError):
        task_service.delete_task("non-existent-id")