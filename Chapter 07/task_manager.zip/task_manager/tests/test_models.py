# tests/test_models.py
import pytest
from datetime import datetime
from app.models import Task, TaskCreate, TaskUpdate


def test_task_model():
    """Test the Task model creation and attributes."""
    task_data = {
        "id": "123",
        "title": "Test Task",
        "description": "This is a test task",
        "priority": 2,
        "completed": False,
        "created_at": datetime.now(),
        "updated_at": datetime.now()
    }

    task = Task(**task_data)

    assert task.id == "123"
    assert task.title == "Test Task"
    assert task.description == "This is a test task"
    assert task.priority == 2
    assert task.completed is False
    assert isinstance(task.created_at, datetime)


def test_task_create_model():
    """Test the TaskCreate model validation."""
    task_data = {
        "title": "New Task",
        "description": "A new task description",
        "priority": 3
    }

    task = TaskCreate(**task_data)

    assert task.title == "New Task"
    assert task.description == "A new task description"
    assert task.priority == 3
    assert task.completed is False  # Default value

    # Test validation
    with pytest.raises(ValueError):
        TaskCreate(title="", description="Empty title test")

    with pytest.raises(ValueError):
        TaskCreate(title="Invalid Priority", priority=6)  # Priority > 5