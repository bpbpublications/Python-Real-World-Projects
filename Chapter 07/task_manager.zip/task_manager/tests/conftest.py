# tests/conftest.py
import pytest
import sys
import os

# Add the app directory to the path so we can import the modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))