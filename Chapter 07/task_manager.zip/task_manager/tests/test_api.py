# tests/test_api.py
import pytest
from fastapi.testclient import TestClient
from app.main import app

@pytest.fixture
def client():
    return TestClient(app)

def test_create_task(client):
    """Test creating a task via API."""
    task_data = {
        "title": "API Test Task",
        "description": "Testing task creation via API",
        "priority": 3
    }

    response = client.post("/tasks/", json=task_data)

    assert response.status_code == 201
    data = response.json()
    assert data["title"] == task_data["title"]
    assert data["description"] == task_data["description"]
    assert data["priority"] == task_data["priority"]
    assert "id" in data


def test_get_task(client):
    """Test retrieving a task via API."""
    # First, create a task
    task_data = {"title": "Task to Retrieve"}
    create_response = client.post("/tasks/", json=task_data)
    task_id = create_response.json()["id"]

    # Now retrieve it
    response = client.get(f"/tasks/{task_id}")

    assert response.status_code == 200
    data = response.json()
    assert data["id"] == task_id
    assert data["title"] == task_data["title"]

    # Test retrieving non-existent task
    response = client.get("/tasks/non-existent-id")
    assert response.status_code == 404


def test_get_all_tasks(client):
    """Test retrieving all tasks via API."""
    # Create a few tasks
    client.post("/tasks/", json={"title": "API Task 1"})
    client.post("/tasks/", json={"title": "API Task 2"})

    response = client.get("/tasks/")

    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert len(data) >= 2  # At least the 2 we just created


def test_update_task(client):
    """Test updating a task via API."""
    # Create a task first
    task_data = {"title": "Original API Title", "priority": 1}
    create_response = client.post("/tasks/", json=task_data)
    task_id = create_response.json()["id"]

    # Update it
    update_data = {"title": "Updated API Title", "completed": True}
    response = client.put(f"/tasks/{task_id}", json=update_data)

    assert response.status_code == 200
    data = response.json()
    assert data["id"] == task_id
    assert data["title"] == update_data["title"]
    assert data["completed"] == update_data["completed"]

    # Test updating non-existent task
    response = client.put("/tasks/non-existent-id", json=update_data)
    assert response.status_code == 404


def test_delete_task(client):
    """Test deleting a task via API."""
    # Create a task first
    task_data = {"title": "Task to Delete via API"}
    create_response = client.post("/tasks/", json=task_data)
    task_id = create_response.json()["id"]

    # Delete it
    response = client.delete(f"/tasks/{task_id}")
    assert response.status_code == 204

    # Verify it's gone
    get_response = client.get(f"/tasks/{task_id}")
    assert get_response.status_code == 404

    # Test deleting non-existent task
    response = client.delete("/tasks/non-existent-id")
    assert response.status_code == 404