# Movie Database Application

A complete FastAPI-based web application demonstrating database integration with Python, featuring movie management, user authentication, and review systems.

## Features

- **Movie Management**: Add, search, view, and manage movies
- **User Authentication**: Registration and login system
- **Reviews & Ratings**: User-generated reviews with rating system
- **Responsive UI**: Modern, mobile-friendly web interface
- **REST API**: Complete API endpoints for all operations
- **Database Integration**: SQLAlchemy ORM with SQLite

## Project Structure

```
movie_database_app/
├── config.py                 # Configuration settings
├── main.py                   # Application entry point
├── models/                   # Database models
│   ├── __init__.py
│   ├── movie.py             # Movie model
│   ├── user.py              # User model
│   └── review.py            # Review model
├── database/                # Database connection setup
│   ├── __init__.py
│   └── database.py          # Database configuration
├── services/                # Business logic
│   ├── __init__.py
│   ├── movie_service.py     # Movie operations
│   ├── user_service.py      # User management
│   └── review_service.py    # Review management
├── routes/                  # API routes and controllers
│   ├── __init__.py
│   ├── main_routes.py       # Main application routes
│   ├── movie_routes.py      # Movie-related routes
│   └── user_routes.py       # Authentication routes
├── templates/               # HTML templates
│   ├── base.html           # Base template
│   ├── index.html          # Home page
│   ├── search.html         # Search page
│   ├── add_movie.html      # Add movie form
│   ├── movie_detail.html   # Movie details
│   ├── login.html          # Login form
│   └── register.html       # Registration form
├── static/                 # Static files
│   ├── css/
│   │   └── styles.css      # Application styles
│   └── js/
│       └── main.js         # JavaScript functionality
└── examples/              # Database examples
    ├── sql/
    │   ├── basic_operations.py      # Raw SQL examples
    │   └── sqlalchemy_example.py   # SQLAlchemy ORM examples
    └── nosql/
        └── mongodb_example.py       # MongoDB examples
```

## Installation & Setup

### Prerequisites

```bash
pip install fastapi uvicorn sqlalchemy jinja2 python-multipart
```

### Running the Application

1. **Start the web application:**
   ```bash
   cd movie_database_app
   python main.py
   ```

2. **Visit the application:**
   - Web Interface: http://localhost:8000
   - API Documentation: http://localhost:8000/docs

### Running the Examples

1. **SQLAlchemy Example:**
   ```bash
   cd examples/sql
   python sqlalchemy_example.py
   ```

2. **Basic SQL Operations:**
   ```bash
   cd examples/sql
   python basic_operations.py
   ```

3. **MongoDB Example:**
   ```bash
   cd examples/nosql
   python mongodb_example.py
   ```

## Usage Guide

### Web Interface

1. **Browse Movies**: Visit the home page to see featured movies
2. **Search Movies**: Use the search page to find movies by title, director, or genre
3. **Add Movies**: Use the "Add Movie" form to contribute new movies
4. **View Details**: Click on any movie to see full details and reviews
5. **User Account**: Register and login to add reviews

### API Endpoints

- `GET /` - Home page
- `GET /movies/` - Search movies
- `GET /movies/{id}` - Movie details
- `POST /movies/add` - Add new movie
- `GET /auth/login` - Login page
- `POST /auth/login` - Process login
- `GET /auth/register` - Registration page
- `POST /auth/register` - Process registration
- `GET /api/movies` - List all movies (JSON)
- `GET /api/movies/{id}` - Get movie details (JSON)
- `GET /health` - Health check

### Demo Account

For testing purposes, use:
- **Username**: demo_user
- **Password**: demo123

## Database Operations

The application demonstrates all CRUD operations:

### CREATE (Add)
- Add new movies with full details
- Register new users
- Submit movie reviews

### READ (Search/View)
- Search movies by title, director, genre
- View movie details with reviews
- List all movies with pagination

### UPDATE (Modify)
- Update movie information
- Modify user profiles
- Edit reviews

### DELETE (Remove)
- Remove movies from database
- Delete user accounts
- Remove reviews

## Architecture Features

### Database Design
- **Relational Model**: Movies, Users, Reviews with proper foreign keys
- **Data Integrity**: Cascading deletes and constraints
- **Indexing**: Optimized queries with database indexes

### Service Layer
- **Separation of Concerns**: Business logic separated from routes
- **Reusable Components**: Services can be used across different interfaces
- **Error Handling**: Proper exception handling and validation

### Web Framework
- **FastAPI**: Modern, fast framework with automatic API documentation
- **Template Engine**: Jinja2 for dynamic HTML generation
- **Static Files**: Efficient serving of CSS, JavaScript, and images

### Security
- **Password Hashing**: Secure password storage with SHA-256
- **Input Validation**: Form validation and sanitization
- **Error Handling**: Graceful error responses

## Learning Objectives

This application demonstrates:

1. **Database Integration**: Connecting Python applications to databases
2. **ORM Usage**: Using SQLAlchemy for database operations
3. **Web Development**: Building complete web applications with FastAPI
4. **API Design**: Creating RESTful APIs with proper endpoints
5. **Frontend Integration**: Combining backend APIs with responsive frontends
6. **Code Organization**: Proper project structure and separation of concerns

## Next Steps

- Add user sessions and JWT authentication
- Implement advanced search filters
- Add image upload for movie posters
- Create admin interface for content management
- Add email notifications for new reviews
- Implement caching for better performance

## Troubleshooting

### Common Issues

1. **Port already in use**: Change the port in `config.py`
2. **Database errors**: Check file permissions and database path
3. **Template not found**: Ensure templates are in the correct directory
4. **Static files not loading**: Verify static file mounting in `main.py`

### Getting Help

- Check the application logs for detailed error messages
- Visit the API documentation at `/docs` for endpoint details
- Review the example files for reference implementations