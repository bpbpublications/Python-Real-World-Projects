"""
Review service layer for business logic
"""

from sqlalchemy.orm import Session
from sqlalchemy import func
from models.review import Review
from models.movie import Movie
from typing import List, Optional

class ReviewService:
    """Service class for review operations"""
    
    @staticmethod
    def get_all_reviews(db: Session) -> List[Review]:
        """Get all reviews"""
        return db.query(Review).all()
    
    @staticmethod
    def get_review_by_id(db: Session, review_id: int) -> Optional[Review]:
        """Get a review by ID"""
        return db.query(Review).filter(Review.review_id == review_id).first()
    
    @staticmethod
    def get_reviews_by_movie(db: Session, movie_id: int) -> List[Review]:
        """Get all reviews for a specific movie"""
        return db.query(Review).filter(Review.movie_id == movie_id).all()
    
    @staticmethod
    def get_reviews_by_user(db: Session, user_id: int) -> List[Review]:
        """Get all reviews by a specific user"""
        return db.query(Review).filter(Review.user_id == user_id).all()
    
    @staticmethod
    def create_review(db: Session, review_data: dict) -> Review:
        """Create a new review"""
        review = Review(**review_data)
        db.add(review)
        db.commit()
        db.refresh(review)
        
        # Update movie rating after adding review
        ReviewService.update_movie_rating(db, review.movie_id)
        
        return review
    
    @staticmethod
    def update_review(db: Session, review_id: int, update_data: dict) -> Optional[Review]:
        """Update an existing review"""
        review = db.query(Review).filter(Review.review_id == review_id).first()
        if review:
            movie_id = review.movie_id
            for key, value in update_data.items():
                if hasattr(review, key):
                    setattr(review, key, value)
            db.commit()
            db.refresh(review)
            
            # Update movie rating after updating review
            ReviewService.update_movie_rating(db, movie_id)
        
        return review
    
    @staticmethod
    def delete_review(db: Session, review_id: int) -> bool:
        """Delete a review"""
        review = db.query(Review).filter(Review.review_id == review_id).first()
        if review:
            movie_id = review.movie_id
            db.delete(review)
            db.commit()
            
            # Update movie rating after deleting review
            ReviewService.update_movie_rating(db, movie_id)
            
            return True
        return False
    
    @staticmethod
    def update_movie_rating(db: Session, movie_id: int):
        """Update the average rating for a movie based on its reviews"""
        average_rating = db.query(func.avg(Review.rating)).filter(Review.movie_id == movie_id).scalar()
        
        movie = db.query(Movie).filter(Movie.movie_id == movie_id).first()
        if movie:
            movie.rating = round(average_rating, 1) if average_rating else 0.0
            db.commit()
    
    @staticmethod
    def get_user_review_for_movie(db: Session, user_id: int, movie_id: int) -> Optional[Review]:
        """Check if user has already reviewed a specific movie"""
        return db.query(Review).filter(
            Review.user_id == user_id,
            Review.movie_id == movie_id
        ).first()
    
    @staticmethod
    def get_recent_reviews(db: Session, limit: int = 10) -> List[Review]:
        """Get recent reviews"""
        return db.query(Review).order_by(Review.created_at.desc()).limit(limit).all()
    
    @staticmethod
    def get_top_reviews(db: Session, limit: int = 10) -> List[Review]:
        """Get highest rated reviews"""
        return db.query(Review).order_by(Review.rating.desc()).limit(limit).all()