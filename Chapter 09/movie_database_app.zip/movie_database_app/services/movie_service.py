"""
Movie service layer for business logic
"""

from sqlalchemy.orm import Session
from models.movie import Movie
from typing import List, Optional

class MovieService:
    """Service class for movie operations"""
    
    @staticmethod
    def get_all_movies(db: Session) -> List[Movie]:
        """Get all movies ordered by release year"""
        return db.query(Movie).order_by(Movie.release_year.desc()).all()
    
    @staticmethod
    def get_movie_by_id(db: Session, movie_id: int) -> Optional[Movie]:
        """Get a movie by its ID"""
        return db.query(Movie).filter(Movie.movie_id == movie_id).first()
    
    @staticmethod
    def search_movies(db: Session, search_term: str) -> List[Movie]:
        """Search movies by title, director, or genre"""
        search_pattern = f"%{search_term}%"
        return db.query(Movie).filter(
            (Movie.title.ilike(search_pattern)) |
            (Movie.director.ilike(search_pattern)) |
            (Movie.genre.ilike(search_pattern))
        ).order_by(Movie.release_year.desc()).all()
    
    @staticmethod
    def create_movie(db: Session, movie_data: dict) -> Movie:
        """Create a new movie"""
        movie = Movie(**movie_data)
        db.add(movie)
        db.commit()
        db.refresh(movie)
        return movie
    
    @staticmethod
    def update_movie(db: Session, movie_id: int, update_data: dict) -> Optional[Movie]:
        """Update an existing movie"""
        movie = db.query(Movie).filter(Movie.movie_id == movie_id).first()
        if movie:
            for key, value in update_data.items():
                if hasattr(movie, key):
                    setattr(movie, key, value)
            db.commit()
            db.refresh(movie)
        return movie
    
    @staticmethod
    def delete_movie(db: Session, movie_id: int) -> bool:
        """Delete a movie"""
        movie = db.query(Movie).filter(Movie.movie_id == movie_id).first()
        if movie:
            db.delete(movie)
            db.commit()
            return True
        return False
    
    @staticmethod
    def get_movies_by_genre(db: Session, genre: str) -> List[Movie]:
        """Get movies by genre"""
        return db.query(Movie).filter(Movie.genre.ilike(f"%{genre}%")).all()
    
    @staticmethod
    def get_movies_by_director(db: Session, director: str) -> List[Movie]:
        """Get movies by director"""
        return db.query(Movie).filter(Movie.director.ilike(f"%{director}%")).all()
    
    @staticmethod
    def get_top_rated_movies(db: Session, limit: int = 10) -> List[Movie]:
        """Get top rated movies"""
        return db.query(Movie).order_by(Movie.rating.desc()).limit(limit).all()