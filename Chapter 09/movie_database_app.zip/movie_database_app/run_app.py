#!/usr/bin/env python3
"""
Standalone Movie Database Application - Fixed Import Version
Run this file directly to start the application

Usage:
    python run_app.py

Visit: http://localhost:8000
"""

import os
import sys
from datetime import datetime
import hashlib

from fastapi import FastAPI, Request, Depends, HTTPException, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from sqlalchemy import create_engine, Column, Integer, String, Text, Float, DateTime, ForeignKey, func
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship
from typing import List, Optional
from contextlib import asynccontextmanager
import uvicorn

# Configuration
DATABASE_URL = "sqlite:///./movie_database.db"
SECRET_KEY = "your-secret-key-here"
DEBUG = True
HOST = "0.0.0.0"
PORT = 8000

# Database setup
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Database Models
class Movie(Base):
    __tablename__ = "movies"
    
    movie_id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    release_year = Column(Integer)
    genre = Column(String(100))
    director = Column(String(255))
    plot = Column(Text)
    runtime = Column(Integer)
    rating = Column(Float, default=0.0)
    poster_url = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    reviews = relationship("Review", back_populates="movie", cascade="all, delete-orphan")
    
    def to_dict(self):
        return {
            "movie_id": self.movie_id,
            "title": self.title,
            "release_year": self.release_year,
            "genre": self.genre,
            "director": self.director,
            "plot": self.plot,
            "runtime": self.runtime,
            "rating": self.rating,
            "poster_url": self.poster_url,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

class User(Base):
    __tablename__ = "users"
    
    user_id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now())
    
    reviews = relationship("Review", back_populates="user", cascade="all, delete-orphan")
    
    @staticmethod
    def hash_password(password: str) -> str:
        return hashlib.sha256(password.encode()).hexdigest()
    
    def verify_password(self, password: str) -> bool:
        return self.password_hash == self.hash_password(password)

class Review(Base):
    __tablename__ = "reviews"
    
    review_id = Column(Integer, primary_key=True, index=True)
    movie_id = Column(Integer, ForeignKey("movies.movie_id", ondelete="CASCADE"))
    user_id = Column(Integer, ForeignKey("users.user_id", ondelete="CASCADE"))
    rating = Column(Integer)
    review_text = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    movie = relationship("Movie", back_populates="reviews")
    user = relationship("User", back_populates="reviews")

# Database functions
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    Base.metadata.create_all(bind=engine)

# Service functions
def get_all_movies(db: Session, limit: int = 100):
    return db.query(Movie).limit(limit).all()

def get_movie_by_id(db: Session, movie_id: int):
    return db.query(Movie).filter(Movie.movie_id == movie_id).first()

def search_movies(db: Session, search_term: str):
    if not search_term or not search_term.strip():
        return []
    
    search_pattern = f"%{search_term.strip()}%"
    return db.query(Movie).filter(
        Movie.title.like(search_pattern) |
        Movie.director.like(search_pattern) |
        Movie.genre.like(search_pattern)
    ).all()

def create_movie(db: Session, movie_data: dict):
    movie = Movie(**movie_data)
    db.add(movie)
    db.commit()
    db.refresh(movie)
    return movie

def get_user_by_username(db: Session, username: str):
    return db.query(User).filter(User.username == username).first()

def create_user(db: Session, user_data: dict):
    user = User(**user_data)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def authenticate_user(db: Session, username: str, password: str):
    user = get_user_by_username(db, username)
    if user and user.verify_password(password):
        return user
    return None

def get_reviews_by_movie(db: Session, movie_id: int):
    return db.query(Review).filter(Review.movie_id == movie_id).all()

def create_review(db: Session, review_data: dict):
    review = Review(**review_data)
    db.add(review)
    db.commit()
    db.refresh(review)
    return review

def init_sample_data(db: Session):
    """Initialize with sample data if database is empty"""
    if db.query(Movie).count() == 0:
        sample_movies = [
            {
                "title": "The Shawshank Redemption",
                "release_year": 1994,
                "genre": "Drama",
                "director": "Frank Darabont",
                "plot": "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
                "runtime": 142,
                "rating": 9.3
            },
            {
                "title": "The Godfather",
                "release_year": 1972,
                "genre": "Crime, Drama",
                "director": "Francis Ford Coppola",
                "plot": "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.",
                "runtime": 175,
                "rating": 9.2
            },
            {
                "title": "Pulp Fiction",
                "release_year": 1994,
                "genre": "Crime, Drama",
                "director": "Quentin Tarantino",
                "plot": "The lives of two mob hitmen, a boxer, a gangster and his wife intertwine in four tales of violence and redemption.",
                "runtime": 154,
                "rating": 8.9
            }
        ]
        
        for movie_data in sample_movies:
            create_movie(db, movie_data)
        
        # Create demo user
        demo_user_data = {
            "username": "demo_user",
            "email": "demo@example.com",
            "password_hash": User.hash_password("demo123")
        }
        create_user(db, demo_user_data)

# Database initialization function for lifespan
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    init_db()
    db = SessionLocal()
    init_sample_data(db)
    db.close()
    print("Database initialized with sample data")
    yield
    # Shutdown (if needed)

# Create FastAPI app with lifespan
app = FastAPI(
    title="Movie Database Application", 
    version="1.0.0",
    lifespan=lifespan
)

# Setup templates and static files
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Routes
@app.get("/", response_class=HTMLResponse)
async def home(request: Request, db: Session = Depends(get_db)):
    movies = get_all_movies(db, limit=6)
    return templates.TemplateResponse("index.html", {
        "request": request,
        "movies": movies,
        "page_title": "Home"
    })

@app.get("/movies/add", response_class=HTMLResponse)
async def movies_add_page(request: Request):
    return templates.TemplateResponse("add_movie.html", {
        "request": request,
        "page_title": "Add Movie"
    })

@app.post("/movies/add")
async def movies_add_post(
    request: Request,
    title: str = Form(...),
    release_year: int = Form(...),
    genre: str = Form(...),
    director: str = Form(...),
    plot: str = Form(...),
    runtime: int = Form(...),
    rating: float = Form(0.0),
    db: Session = Depends(get_db)
):
    movie_data = {
        "title": title,
        "release_year": release_year,
        "genre": genre,
        "director": director,
        "plot": plot,
        "runtime": runtime,
        "rating": rating
    }
    
    movie = create_movie(db, movie_data)
    return RedirectResponse(url=f"/movies/{movie.movie_id}", status_code=303)

@app.get("/movies/", response_class=HTMLResponse)
async def movies_list(request: Request, db: Session = Depends(get_db)):
    movies = get_all_movies(db)
    return templates.TemplateResponse("search.html", {
        "request": request,
        "movies": movies,
        "search_term": "",
        "page_title": "All Movies"
    })

@app.get("/movies/{movie_id}", response_class=HTMLResponse)
async def movie_detail(request: Request, movie_id: int, db: Session = Depends(get_db)):
    movie = get_movie_by_id(db, movie_id)
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    
    reviews = get_reviews_by_movie(db, movie_id)
    return templates.TemplateResponse("movie_detail.html", {
        "request": request,
        "movie": movie,
        "reviews": reviews,
        "page_title": movie.title
    })

@app.get("/search", response_class=HTMLResponse)
async def search(request: Request, q: str = "", db: Session = Depends(get_db)):
    movies = []
    search_performed = False
    
    if q.strip():  # Only search if there's a non-empty search term
        movies = search_movies(db, q.strip())
        search_performed = True
    
    return templates.TemplateResponse("search.html", {
        "request": request,
        "movies": movies,
        "search_term": q,
        "search_performed": search_performed,
        "page_title": "Search Movies"
    })

@app.get("/add-movie", response_class=HTMLResponse)
async def add_movie_page(request: Request):
    return templates.TemplateResponse("add_movie.html", {
        "request": request,
        "page_title": "Add Movie"
    })

@app.post("/add-movie")
async def add_movie(
    request: Request,
    title: str = Form(...),
    release_year: int = Form(...),
    genre: str = Form(...),
    director: str = Form(...),
    plot: str = Form(...),
    runtime: int = Form(...),
    rating: float = Form(0.0),
    db: Session = Depends(get_db)
):
    movie_data = {
        "title": title,
        "release_year": release_year,
        "genre": genre,
        "director": director,
        "plot": plot,
        "runtime": runtime,
        "rating": rating
    }
    
    movie = create_movie(db, movie_data)
    return RedirectResponse(url=f"/movies/{movie.movie_id}", status_code=303)

# Login and register functionality removed per user request

@app.post("/movies/{movie_id}/reviews")
async def add_review(
    request: Request,
    movie_id: int,
    rating: int = Form(...),
    review_text: str = Form(...),
    user_name: str = Form("Anonymous"),
    db: Session = Depends(get_db)
):
    # For demo purposes, create a simple review without full user authentication
    review_data = {
        "movie_id": movie_id,
        "user_id": 1,  # Default demo user
        "rating": rating,
        "review_text": review_text
    }
    
    create_review(db, review_data)
    return RedirectResponse(url=f"/movies/{movie_id}", status_code=303)

# API Routes
@app.get("/api/movies")
async def api_movies(db: Session = Depends(get_db)):
    movies = get_all_movies(db)
    return [movie.to_dict() for movie in movies]

@app.get("/api/movies/{movie_id}")
async def api_movie_detail(movie_id: int, db: Session = Depends(get_db)):
    movie = get_movie_by_id(db, movie_id)
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    return movie.to_dict()

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# Startup handled by lifespan function above

def main():
    print("Starting Movie Database Application...")
    print(f"Visit: http://localhost:{PORT}")
    print("API Docs: http://localhost:8000/docs")
    
    uvicorn.run("run_app:app", host=HOST, port=PORT, reload=DEBUG)

if __name__ == "__main__":
    main()