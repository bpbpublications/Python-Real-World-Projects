"""
Database configuration and connection setup
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from config import Config

# Create SQLAlchemy engine
engine = create_engine(Config.DATABASE_URL)

# Create SessionLocal class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create Base class
Base = declarative_base()

def get_db():
    """Dependency to get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    """Initialize the database"""
    # Import all models to ensure they are registered with SQLAlchemy
    from ..models import Movie, User, Review
    
    # Create all tables
    Base.metadata.create_all(bind=engine)
    
    # Add sample data if database is empty
    db = SessionLocal()
    try:
        if db.query(Movie).count() == 0:
            sample_data = [
                Movie(
                    title="The Shawshank Redemption",
                    release_year=1994,
                    genre="Drama",
                    director="Frank Darabont",
                    plot="Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
                    runtime=142,
                    rating=9.3
                ),
                Movie(
                    title="The Godfather",
                    release_year=1972,
                    genre="Crime, Drama",
                    director="Francis Ford Coppola",
                    plot="The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.",
                    runtime=175,
                    rating=9.2
                ),
                Movie(
                    title="Pulp Fiction",
                    release_year=1994,
                    genre="Crime, Drama",
                    director="Quentin Tarantino",
                    plot="The lives of two mob hitmen, a boxer, a gangster and his wife intertwine in four tales of violence and redemption.",
                    runtime=154,
                    rating=8.9
                )
            ]
            
            for movie in sample_data:
                db.add(movie)
            
            # Add sample user
            sample_user = User(
                username="demo_user",
                email="demo@example.com",
                password_hash=User.hash_password("demo123")
            )
            db.add(sample_user)
            
            db.commit()
            print("Sample data initialized successfully!")
    except Exception as e:
        db.rollback()
        print(f"Error initializing sample data: {e}")
    finally:
        db.close()