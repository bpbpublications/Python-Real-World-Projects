"""
Configuration settings for the Movie Database Application
"""

import os

class Config:
    # Database configuration
    DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///movie_database.db')
    
    # Application settings
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-here')
    DEBUG = os.getenv('DEBUG', 'True').lower() in ['true', '1', 'on']
    
    # Server settings
    HOST = os.getenv('HOST', '0.0.0.0')
    PORT = int(os.getenv('PORT', 8000))
    
    # Application metadata
    APP_NAME = "Movie Database Application"
    VERSION = "1.0.0"