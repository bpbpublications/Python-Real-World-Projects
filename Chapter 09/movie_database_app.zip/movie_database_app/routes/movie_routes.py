"""
Movie-related route handlers
"""

from fastapi import APIRouter, Request, Depends, HTTPException, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database.database import get_db
from services.movie_service import MovieService
from services.review_service import ReviewService
from typing import Optional

class MovieRoutes:
    def __init__(self):
        self.router = APIRouter(prefix="/movies", tags=["movies"])
        self.api_router = APIRouter(prefix="/api/movies", tags=["movies-api"])
        self.templates = Jinja2Templates(directory="movie_database_app/templates")
        self._setup_routes()
    
    def _setup_routes(self):
        """Setup all movie routes"""
        
        @self.router.get("/{movie_id}", response_class=HTMLResponse)
        async def movie_detail(request: Request, movie_id: int, db: Session = Depends(get_db)):
            """Movie detail page"""
            movie = MovieService.get_movie_by_id(db, movie_id)
            if not movie:
                raise HTTPException(status_code=404, detail="Movie not found")
            
            reviews = ReviewService.get_reviews_by_movie(db, movie_id)
            return self.templates.TemplateResponse(
                "movie_detail.html",
                {"request": request, "movie": movie, "reviews": reviews}
            )
        
        @self.router.get("/", response_class=HTMLResponse)
        async def search_movies(request: Request, q: str = "", db: Session = Depends(get_db)):
            """Search movies page"""
            if q:
                movies = MovieService.search_movies(db, q)
            else:
                movies = []
            return self.templates.TemplateResponse(
                "search.html",
                {"request": request, "movies": movies, "query": q}
            )
        
        @self.router.get("/add", response_class=HTMLResponse)
        async def add_movie_page(request: Request):
            """Add movie form page"""
            return self.templates.TemplateResponse(
                "add_movie.html",
                {"request": request}
            )
        
        @self.router.post("/add")
        async def add_movie(
            title: str = Form(...),
            release_year: int = Form(...),
            genre: str = Form(...),
            director: str = Form(...),
            plot: str = Form(...),
            runtime: int = Form(...),
            poster_url: Optional[str] = Form(None),
            db: Session = Depends(get_db)
        ):
            """Add a new movie"""
            movie_data = {
                "title": title,
                "release_year": release_year,
                "genre": genre,
                "director": director,
                "plot": plot,
                "runtime": runtime,
                "rating": 0.0,  # Default rating
                "poster_url": poster_url
            }
            MovieService.create_movie(db, movie_data)
            return RedirectResponse(url="/", status_code=303)
        
        # API Routes
        @self.api_router.get("/")
        async def api_get_movies(db: Session = Depends(get_db)):
            """Get all movies via API"""
            movies = MovieService.get_all_movies(db)
            return [movie.to_dict() for movie in movies]
        
        @self.api_router.get("/{movie_id}")
        async def api_get_movie(movie_id: int, db: Session = Depends(get_db)):
            """Get specific movie via API"""
            movie = MovieService.get_movie_by_id(db, movie_id)
            if not movie:
                raise HTTPException(status_code=404, detail="Movie not found")
            return movie.to_dict()
        
        @self.api_router.get("/search/{query}")
        async def api_search_movies(query: str, db: Session = Depends(get_db)):
            """Search movies via API"""
            movies = MovieService.search_movies(db, query)
            return [movie.to_dict() for movie in movies]