"""
Route handlers for the Movie Database Application
"""

from .movie_routes import MovieRoutes
from .user_routes import UserRoutes
from .main_routes import MainRoutes

__all__ = ['MovieRoutes', 'UserRoutes', 'MainRoutes']