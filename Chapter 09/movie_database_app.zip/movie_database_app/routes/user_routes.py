"""
User-related route handlers
"""

from fastapi import APIRouter, Request, Depends, HTTPException, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database.database import get_db
from services.user_service import UserService

class UserRoutes:
    def __init__(self):
        self.router = APIRouter(prefix="/auth", tags=["auth"])
        self.templates = Jinja2Templates(directory="movie_database_app/templates")
        self._setup_routes()
    
    def _setup_routes(self):
        """Setup all user authentication routes"""
        
        @self.router.get("/login", response_class=HTMLResponse)
        async def login_page(request: Request):
            """Login page"""
            return self.templates.TemplateResponse(
                "login.html",
                {"request": request}
            )
        
        @self.router.post("/login")
        async def login(
            username: str = Form(...),
            password: str = Form(...),
            db: Session = Depends(get_db)
        ):
            """Process login form"""
            user = UserService.authenticate_user(db, username, password)
            if not user:
                raise HTTPException(status_code=401, detail="Invalid username or password")
            
            # In a real app, set session/JWT here
            response = RedirectResponse(url="/", status_code=303)
            return response
        
        @self.router.get("/register", response_class=HTMLResponse)
        async def register_page(request: Request):
            """Registration page"""
            return self.templates.TemplateResponse(
                "register.html",
                {"request": request}
            )
        
        @self.router.post("/register")
        async def register(
            username: str = Form(...),
            email: str = Form(...),
            password: str = Form(...),
            db: Session = Depends(get_db)
        ):
            """Process registration form"""
            # Check if username or email already exists
            if UserService.username_exists(db, username):
                raise HTTPException(status_code=400, detail="Username already registered")
            
            if UserService.email_exists(db, email):
                raise HTTPException(status_code=400, detail="Email already registered")
            
            # Create new user
            user_data = {
                "username": username,
                "email": email,
                "password": password  # Will be hashed in the service
            }
            UserService.create_user(db, user_data)
            
            # Redirect to login
            return RedirectResponse(url="/auth/login", status_code=303)