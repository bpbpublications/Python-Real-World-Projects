"""
Main route handlers for the application
"""

from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database.database import get_db
from services.movie_service import MovieService

class MainRoutes:
    def __init__(self):
        self.router = APIRouter()
        self.templates = Jinja2Templates(directory="movie_database_app/templates")
        self._setup_routes()
    
    def _setup_routes(self):
        """Setup all main routes"""
        
        @self.router.get("/", response_class=HTMLResponse)
        async def home(request: Request, db: Session = Depends(get_db)):
            """Home page with recent movies"""
            movies = MovieService.get_all_movies(db)
            return self.templates.TemplateResponse(
                "index.html", 
                {"request": request, "movies": movies}
            )
        
        @self.router.get("/health")
        async def health_check():
            """Health check endpoint"""
            return {"status": "healthy", "message": "Movie Database API is running"}
        
        @self.router.get("/about")
        async def about(request: Request):
            """About page"""
            return self.templates.TemplateResponse(
                "about.html",
                {"request": request}
            )