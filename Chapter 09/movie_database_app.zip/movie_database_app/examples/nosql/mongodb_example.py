#!/usr/bin/env python3
"""
Chapter 9: Database Integration - MongoDB Example
Movie Database with MongoDB NoSQL

Requirements:
pip install pymongo

Usage:
python chapter9_mongodb_example.py

Note: This example uses an in-memory MongoDB simulation for portability.
To use with real MongoDB, replace MongoMockClient with MongoClient.
"""

try:
    from pymongo import MongoClient
    REAL_MONGO = True
except ImportError:
    # Fallback to in-memory simulation
    REAL_MONGO = False
    print("Warning: pymongo not installed. Using in-memory simulation.")

from datetime import datetime
from bson.objectid import ObjectId
import json

class InMemoryMongoDB:
    """Simple in-memory MongoDB simulation for demo purposes."""
    
    def __init__(self):
        self.databases = {}
    
    def __getitem__(self, db_name):
        if db_name not in self.databases:
            self.databases[db_name] = InMemoryDatabase(db_name)
        return self.databases[db_name]

class InMemoryDatabase:
    def __init__(self, name):
        self.name = name
        self.collections = {}
    
    def __getitem__(self, collection_name):
        if collection_name not in self.collections:
            self.collections[collection_name] = InMemoryCollection(collection_name)
        return self.collections[collection_name]

class InMemoryCollection:
    def __init__(self, name):
        self.name = name
        self.documents = []
        self._id_counter = 1
    
    def insert_one(self, document):
        document = document.copy()
        document['_id'] = ObjectId()
        self.documents.append(document)
        return type('InsertResult', (), {'inserted_id': document['_id']})()
    
    def find_one(self, query):
        for doc in self.documents:
            if self._matches_query(doc, query):
                return doc
        return None
    
    def find(self, query=None):
        if query is None:
            query = {}
        results = [doc for doc in self.documents if self._matches_query(doc, query)]
        return InMemoryCursor(results)
    
    def update_one(self, query, update):
        for i, doc in enumerate(self.documents):
            if self._matches_query(doc, query):
                if '$set' in update:
                    doc.update(update['$set'])
                return type('UpdateResult', (), {'modified_count': 1})()
        return type('UpdateResult', (), {'modified_count': 0})()
    
    def delete_one(self, query):
        for i, doc in enumerate(self.documents):
            if self._matches_query(doc, query):
                del self.documents[i]
                return type('DeleteResult', (), {'deleted_count': 1})()
        return type('DeleteResult', (), {'deleted_count': 0})()
    
    def delete_many(self, query):
        original_count = len(self.documents)
        self.documents = [doc for doc in self.documents if not self._matches_query(doc, query)]
        deleted_count = original_count - len(self.documents)
        return type('DeleteResult', (), {'deleted_count': deleted_count})()
    
    def _matches_query(self, doc, query):
        if not query:
            return True
        
        for key, value in query.items():
            if key == '_id':
                if doc.get('_id') != value:
                    return False
            elif key == '$or':
                if not any(self._matches_query(doc, sub_query) for sub_query in value):
                    return False
            elif key not in doc:
                return False
            elif isinstance(value, type(lambda: None)) and hasattr(value, 'pattern'):
                # Regex pattern
                import re
                if not re.search(value.pattern, str(doc[key]), value.flags):
                    return False
            elif doc[key] != value:
                return False
        return True

class InMemoryCursor:
    def __init__(self, documents):
        self.documents = documents
    
    def sort(self, key, direction):
        reverse = direction == -1
        self.documents.sort(key=lambda x: x.get(key, 0), reverse=reverse)
        return self
    
    def limit(self, count):
        self.documents = self.documents[:count]
        return self
    
    def __iter__(self):
        return iter(self.documents)

# Initialize MongoDB connection
if REAL_MONGO:
    try:
        client = MongoClient('mongodb://localhost:27017/', serverSelectionTimeoutMS=2000)
        # Test connection
        client.admin.command('ismaster')
        print("Connected to MongoDB")
    except:
        print("Could not connect to MongoDB. Using in-memory simulation.")
        client = InMemoryMongoDB()
else:
    client = InMemoryMongoDB()

# Get or create a database
db = client['movie_database']

# Get or create collections
movies_collection = db['movies']
users_collection = db['users']
reviews_collection = db['reviews']

def add_movie_mongodb(movie_data):
    """Add a new movie to MongoDB."""
    # Add created_at if not present
    if 'created_at' not in movie_data:
        movie_data['created_at'] = datetime.utcnow()
    
    result = movies_collection.insert_one(movie_data)
    print(f"Added movie: {movie_data['title']} (ID: {result.inserted_id})")
    return result.inserted_id

def get_movie_by_id_mongodb(movie_id):
    """Get a movie by its ID from MongoDB."""
    if isinstance(movie_id, str):
        movie_id = ObjectId(movie_id)
    
    movie = movies_collection.find_one({'_id': movie_id})
    return movie

def search_movies_mongodb(search_term, limit=10):
    """Search for movies in MongoDB."""
    # Create a regex pattern for case-insensitive search
    import re
    pattern = re.compile(search_term, re.IGNORECASE)
    
    # Search in multiple fields
    query = {
        '$or': [
            {'title': pattern},
            {'director': pattern},
            {'genre': pattern}
        ]
    }
    
    # Execute the query
    movies = list(movies_collection.find(query).sort('release_year', -1).limit(limit))
    return movies

def update_movie_mongodb(movie_id, update_data):
    """Update a movie in MongoDB."""
    if isinstance(movie_id, str):
        movie_id = ObjectId(movie_id)
    
    result = movies_collection.update_one(
        {'_id': movie_id},
        {'$set': update_data}
    )
    
    success = result.modified_count > 0
    print(f"{'Updated' if success else 'Failed to update'} movie with ID: {movie_id}")
    return success

def delete_movie_mongodb(movie_id):
    """Delete a movie from MongoDB."""
    if isinstance(movie_id, str):
        movie_id = ObjectId(movie_id)
    
    result = movies_collection.delete_one({'_id': movie_id})
    
    success = result.deleted_count > 0
    print(f"{'Deleted' if success else 'Failed to delete'} movie with ID: {movie_id}")
    return success

def add_user_mongodb(user_data):
    """Add a new user to MongoDB."""
    # Add created_at if not present
    if 'created_at' not in user_data:
        user_data['created_at'] = datetime.utcnow()
    
    result = users_collection.insert_one(user_data)
    print(f"Added user: {user_data['username']} (ID: {result.inserted_id})")
    return result.inserted_id

def add_review_mongodb(review_data):
    """Add a new review to MongoDB."""
    # Add created_at if not present
    if 'created_at' not in review_data:
        review_data['created_at'] = datetime.utcnow()
    
    # Convert string IDs to ObjectId if needed
    if 'movie_id' in review_data and isinstance(review_data['movie_id'], str):
        review_data['movie_id'] = ObjectId(review_data['movie_id'])
    
    if 'user_id' in review_data and isinstance(review_data['user_id'], str):
        review_data['user_id'] = ObjectId(review_data['user_id'])
    
    result = reviews_collection.insert_one(review_data)
    print(f"Added review for movie {review_data['movie_id']} (ID: {result.inserted_id})")
    return result.inserted_id

def get_movie_with_reviews_mongodb(movie_id):
    """Get a movie with all its reviews."""
    if isinstance(movie_id, str):
        movie_id = ObjectId(movie_id)
    
    # Get the movie
    movie = movies_collection.find_one({'_id': movie_id})
    if not movie:
        return None
    
    # Get reviews for the movie
    reviews = list(reviews_collection.find({'movie_id': movie_id}))
    
    # Add reviews to the movie
    movie['reviews'] = reviews
    return movie

def demo_mongodb():
    """Demonstrate MongoDB operations."""
    print("=== Chapter 9: MongoDB Movie Database Demo ===")
    print("Setting up MongoDB...")
    
    # Clear collections for demo
    movies_collection.delete_many({})
    users_collection.delete_many({})
    reviews_collection.delete_many({})
    
    print("\nAdding a movie...")
    movie = {
        'title': 'The Dark Knight',
        'release_year': 2008,
        'genre': 'Action, Crime, Drama',
        'director': 'Christopher Nolan',
        'plot': 'When the menace known as The Joker emerges from his mysterious past, he wreaks havoc and chaos on the people of Gotham.',
        'runtime': 152,
        'rating': 9.0,
        'poster_url': 'https://example.com/dark_knight.jpg',
        'created_at': datetime.utcnow()
    }
    movie_id = add_movie_mongodb(movie)
    
    print("\nAdding a user...")
    user = {
        'username': 'batman_fan',
        'email': 'batman@example.com',
        'password_hash': 'hashed_password_here',
        'created_at': datetime.utcnow()
    }
    user_id = add_user_mongodb(user)
    
    print("\nAdding a review...")
    review = {
        'movie_id': movie_id,
        'user_id': user_id,
        'rating': 10,
        'review_text': 'Heath Ledger\'s performance as the Joker is absolutely incredible. A masterpiece of modern cinema.',
        'created_at': datetime.utcnow()
    }
    review_id = add_review_mongodb(review)
    
    print("\nRetrieving the movie...")
    retrieved_movie = get_movie_by_id_mongodb(movie_id)
    print(f"Movie: {retrieved_movie['title']} ({retrieved_movie['release_year']})")
    
    print("\nSearching for movies...")
    results = search_movies_mongodb("dark knight")
    print(f"Found {len(results)} movies")
    
    print("\nUpdating the movie...")
    update_movie_mongodb(movie_id, {'rating': 9.5, 'genre': 'Superhero, Crime'})
    
    print("\nGetting movie with reviews...")
    movie_with_reviews = get_movie_with_reviews_mongodb(movie_id)
    print(f"Movie: {movie_with_reviews['title']}")
    print(f"Number of reviews: {len(movie_with_reviews['reviews'])}")
    
    print("\nDemo completed successfully!")
    if not REAL_MONGO:
        print("Note: This demo used in-memory simulation. Install pymongo for real MongoDB support.")

if __name__ == "__main__":
    demo_mongodb()