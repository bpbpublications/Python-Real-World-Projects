#!/usr/bin/env python3
"""
Basic SQL Operations Example
Demonstrates raw SQL queries with Python

Requirements:
pip install sqlite3 (built-in with Python)

Usage:
python basic_operations.py
"""

import sqlite3
import os
from datetime import datetime

def create_database():
    """Create the movie database and tables"""
    # Create database file
    db_path = 'basic_movie_db.sqlite'
    
    # Remove existing database for clean demo
    if os.path.exists(db_path):
        os.remove(db_path)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create movies table
    cursor.execute('''
        CREATE TABLE movies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            release_year INTEGER,
            genre TEXT,
            director TEXT,
            plot TEXT,
            runtime INTEGER,
            rating REAL DEFAULT 0.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create users table
    cursor.execute('''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create reviews table
    cursor.execute('''
        CREATE TABLE reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER,
            user_id INTEGER,
            rating INTEGER,
            review_text TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (movie_id) REFERENCES movies (id),
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    conn.commit()
    conn.close()
    print(f"Database created: {db_path}")
    return db_path

def add_movie(db_path, title, year, genre, director, plot, runtime, rating=0.0):
    """Add a movie to the database"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO movies (title, release_year, genre, director, plot, runtime, rating)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (title, year, genre, director, plot, runtime, rating))
    
    movie_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    print(f"Added movie: {title} (ID: {movie_id})")
    return movie_id

def search_movies(db_path, search_term):
    """Search for movies by title, director, or genre"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    search_pattern = f"%{search_term}%"
    cursor.execute('''
        SELECT id, title, release_year, director, genre, rating
        FROM movies
        WHERE title LIKE ? OR director LIKE ? OR genre LIKE ?
        ORDER BY release_year DESC
    ''', (search_pattern, search_pattern, search_pattern))
    
    movies = cursor.fetchall()
    conn.close()
    
    print(f"\nSearch results for '{search_term}':")
    for movie in movies:
        print(f"  ID {movie[0]}: {movie[1]} ({movie[2]}) by {movie[3]} - Rating: {movie[5]}")
    
    return movies

def update_movie(db_path, movie_id, **updates):
    """Update movie details"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Build dynamic update query
    set_clauses = []
    values = []
    
    for field, value in updates.items():
        set_clauses.append(f"{field} = ?")
        values.append(value)
    
    if set_clauses:
        values.append(movie_id)
        query = f"UPDATE movies SET {', '.join(set_clauses)} WHERE id = ?"
        
        cursor.execute(query, values)
        
        if cursor.rowcount > 0:
            print(f"Updated movie ID {movie_id}: {updates}")
        else:
            print(f"Movie ID {movie_id} not found")
    
    conn.commit()
    conn.close()

def delete_movie(db_path, movie_id):
    """Delete a movie from the database"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get movie title first
    cursor.execute("SELECT title FROM movies WHERE id = ?", (movie_id,))
    result = cursor.fetchone()
    
    if result:
        title = result[0]
        cursor.execute("DELETE FROM movies WHERE id = ?", (movie_id,))
        conn.commit()
        print(f"Deleted movie: {title} (ID: {movie_id})")
        return True
    else:
        print(f"Movie ID {movie_id} not found")
        return False
    
    conn.close()

def list_all_movies(db_path):
    """List all movies in the database"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, title, release_year, director, rating
        FROM movies
        ORDER BY release_year DESC
    ''')
    
    movies = cursor.fetchall()
    conn.close()
    
    print("\nAll movies in database:")
    for movie in movies:
        print(f"  ID {movie[0]}: {movie[1]} ({movie[2]}) by {movie[3]} - Rating: {movie[4]}")
    
    return movies

def add_user(db_path, username, email, password_hash):
    """Add a user to the database"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO users (username, email, password_hash)
            VALUES (?, ?, ?)
        ''', (username, email, password_hash))
        
        user_id = cursor.lastrowid
        conn.commit()
        print(f"Added user: {username} (ID: {user_id})")
        return user_id
    except sqlite3.IntegrityError as e:
        print(f"Error adding user: {e}")
        return None
    finally:
        conn.close()

def add_review(db_path, movie_id, user_id, rating, review_text):
    """Add a review for a movie"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO reviews (movie_id, user_id, rating, review_text)
        VALUES (?, ?, ?, ?)
    ''', (movie_id, user_id, rating, review_text))
    
    review_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    print(f"Added review: Movie ID {movie_id}, User ID {user_id}, Rating {rating}")
    return review_id

def demo_basic_sql():
    """Demonstrate basic SQL operations"""
    print("=== Basic SQL Operations Demo ===")
    
    # Create database
    db_path = create_database()
    
    # Add sample movies
    movie1_id = add_movie(
        db_path, "The Shawshank Redemption", 1994, "Drama",
        "Frank Darabont", "Two imprisoned men bond over a number of years...",
        142, 9.3
    )
    
    movie2_id = add_movie(
        db_path, "The Godfather", 1972, "Crime, Drama",
        "Francis Ford Coppola", "The aging patriarch of an organized crime dynasty...",
        175, 9.2
    )
    
    movie3_id = add_movie(
        db_path, "Pulp Fiction", 1994, "Crime, Drama",
        "Quentin Tarantino", "The lives of two mob hitmen...",
        154, 8.9
    )
    
    # Add a user
    user_id = add_user(db_path, "movie_lover", "fan@example.com", "hashed_password")
    
    # Add a review
    if user_id:
        add_review(db_path, movie1_id, user_id, 10, "Absolutely incredible movie!")
    
    # Search movies
    search_movies(db_path, "Drama")
    search_movies(db_path, "Tarantino")
    
    # Update a movie
    update_movie(db_path, movie1_id, rating=9.5, genre="Drama, Hope")
    
    # List all movies
    list_all_movies(db_path)
    
    # Delete a movie
    delete_movie(db_path, movie3_id)
    
    # List remaining movies
    list_all_movies(db_path)
    
    print(f"\nDemo completed! Database saved as: {db_path}")

if __name__ == "__main__":
    demo_basic_sql()