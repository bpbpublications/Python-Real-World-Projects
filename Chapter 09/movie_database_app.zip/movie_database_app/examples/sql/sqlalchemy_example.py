#!/usr/bin/env python3
"""
Chapter 9: Database Integration - SQLAlchemy Example
Movie Database with SQLAlchemy ORM

Requirements:
pip install sqlalchemy psycopg2-binary

Usage:
python chapter9_sqlalchemy_example.py
"""

from sqlalchemy import create_engine, Column, Integer, String, Text, Float, DateTime, ForeignKey, UniqueConstraint, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import datetime

# Create the SQLAlchemy engine (modify connection string as needed)
engine = create_engine('sqlite:///movie_database.db')  # Using SQLite for portability
Base = declarative_base()

# Define models
class Movie(Base):
    __tablename__ = 'movies'
    
    movie_id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    release_year = Column(Integer)
    genre = Column(String(100))
    director = Column(String(255))
    plot = Column(Text)
    runtime = Column(Integer)
    rating = Column(Float)
    poster_url = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    # Relationship to reviews
    reviews = relationship("Review", back_populates="movie", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Movie(title='{self.title}', year={self.release_year})>"

class User(Base):
    __tablename__ = 'users'
    
    user_id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now())
    
    # Relationship to reviews
    reviews = relationship("Review", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(username='{self.username}')>"

class Review(Base):
    __tablename__ = 'reviews'
    
    review_id = Column(Integer, primary_key=True)
    movie_id = Column(Integer, ForeignKey('movies.movie_id', ondelete='CASCADE'))
    user_id = Column(Integer, ForeignKey('users.user_id', ondelete='CASCADE'))
    rating = Column(Integer)
    review_text = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    movie = relationship("Movie", back_populates="reviews")
    user = relationship("User", back_populates="reviews")
    
    # One review per movie per user
    __table_args__ = (UniqueConstraint('movie_id', 'user_id', name='uix_user_movie_review'),)
    
    def __repr__(self):
        return f"<Review(movie_id={self.movie_id}, user_id={self.user_id}, rating={self.rating})>"

# Create all tables
Base.metadata.create_all(engine)

# Create a session factory
Session = sessionmaker(bind=engine)

# CRUD operations using SQLAlchemy
def add_movie_sqlalchemy(title, release_year, genre, director, plot, runtime, rating, poster_url=None):
    """Add a new movie using SQLAlchemy."""
    session = Session()
    try:
        movie = Movie(
            title=title,
            release_year=release_year,
            genre=genre,
            director=director,
            plot=plot,
            runtime=runtime,
            rating=rating,
            poster_url=poster_url
        )
        
        session.add(movie)
        session.commit()
        print(f"Added movie: {title} (ID: {movie.movie_id})")
        return movie.movie_id
    except Exception as e:
        session.rollback()
        print(f"Error adding movie: {e}")
        raise
    finally:
        session.close()

def get_movie_by_id_sqlalchemy(movie_id):
    """Get a movie by its ID using SQLAlchemy."""
    session = Session()
    try:
        movie = session.query(Movie).filter(Movie.movie_id == movie_id).first()
        return movie
    finally:
        session.close()

def search_movies_sqlalchemy(search_term, limit=10):
    """Search for movies using SQLAlchemy."""
    session = Session()
    try:
        search_pattern = f"%{search_term}%"
        movies = session.query(Movie).filter(
            (Movie.title.ilike(search_pattern)) |
            (Movie.director.ilike(search_pattern)) |
            (Movie.genre.ilike(search_pattern))
        ).order_by(Movie.release_year.desc()).limit(limit).all()
        return movies
    finally:
        session.close()

def update_movie_sqlalchemy(movie_id, **kwargs):
    """Update a movie using SQLAlchemy."""
    session = Session()
    try:
        movie = session.query(Movie).filter(Movie.movie_id == movie_id).first()
        if movie:
            for key, value in kwargs.items():
                if hasattr(movie, key):
                    setattr(movie, key, value)
            session.commit()
            print(f"Updated movie: {movie.title} (ID: {movie.movie_id})")
            return True
        print(f"Movie with ID {movie_id} not found")
        return False
    except Exception as e:
        session.rollback()
        print(f"Error updating movie: {e}")
        raise
    finally:
        session.close()

def delete_movie_sqlalchemy(movie_id):
    """Delete a movie using SQLAlchemy."""
    session = Session()
    try:
        movie = session.query(Movie).filter(Movie.movie_id == movie_id).first()
        if movie:
            session.delete(movie)
            session.commit()
            print(f"Deleted movie with ID: {movie_id}")
            return True
        print(f"Movie with ID {movie_id} not found")
        return False
    except Exception as e:
        session.rollback()
        print(f"Error deleting movie: {e}")
        raise
    finally:
        session.close()

def add_user_sqlalchemy(username, email, password_hash):
    """Add a new user using SQLAlchemy."""
    session = Session()
    try:
        user = User(
            username=username,
            email=email,
            password_hash=password_hash
        )
        
        session.add(user)
        session.commit()
        print(f"Added user: {username} (ID: {user.user_id})")
        return user.user_id
    except Exception as e:
        session.rollback()
        print(f"Error adding user: {e}")
        raise
    finally:
        session.close()

def add_review_sqlalchemy(movie_id, user_id, rating, review_text):
    """Add a new review using SQLAlchemy."""
    session = Session()
    try:
        review = Review(
            movie_id=movie_id,
            user_id=user_id,
            rating=rating,
            review_text=review_text
        )
        
        session.add(review)
        session.commit()
        print(f"Added review: Movie ID {movie_id}, User ID {user_id}, Rating {rating}")
        return review.review_id
    except Exception as e:
        session.rollback()
        print(f"Error adding review: {e}")
        raise
    finally:
        session.close()

def demo_sqlalchemy():
    """Demonstrate SQLAlchemy operations."""
    print("=== Chapter 9: SQLAlchemy Movie Database Demo ===")
    print("Setting up SQLAlchemy...")
    
    print("\nAdding a movie...")
    movie_id = add_movie_sqlalchemy(
        title="Inception",
        release_year=2010,
        genre="Science Fiction, Action",
        director="Christopher Nolan",
        plot="A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
        runtime=148,
        rating=8.8,
        poster_url="https://example.com/inception.jpg"
    )
    
    print("\nAdding a user...")
    user_id = add_user_sqlalchemy(
        username="movie_fan",
        email="fan@example.com",
        password_hash="hashed_password_here"
    )
    
    print("\nAdding a review...")
    review_id = add_review_sqlalchemy(
        movie_id=movie_id,
        user_id=user_id,
        rating=9,
        review_text="One of the most mind-bending movies I've ever seen. The concept is brilliant and the execution is flawless."
    )
    
    print("\nRetrieving the movie...")
    movie = get_movie_by_id_sqlalchemy(movie_id)
    print(f"Movie: {movie.title} ({movie.release_year})")
    print(f"Reviews: {len(movie.reviews)}")
    
    print("\nSearching for movies...")
    results = search_movies_sqlalchemy("inception")
    print(f"Found {len(results)} movies")
    
    print("\nUpdating the movie...")
    update_movie_sqlalchemy(movie_id, rating=9.0, genre="Sci-Fi, Thriller")
    
    print("\nDemo completed successfully!")
    print("Database file created: movie_database.db")

if __name__ == "__main__":
    demo_sqlalchemy()