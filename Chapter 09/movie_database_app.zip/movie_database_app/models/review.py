"""
Review model for the database
"""

from sqlalchemy import Column, Integer, Text, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from database.database import Base

class Review(Base):
    __tablename__ = "reviews"
    
    review_id = Column(Integer, primary_key=True, index=True)
    movie_id = Column(Integer, ForeignKey("movies.movie_id", ondelete="CASCADE"))
    user_id = Column(Integer, ForeignKey("users.user_id", ondelete="CASCADE"))
    rating = Column(Integer)  # 1-10 rating scale
    review_text = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    movie = relationship("Movie", back_populates="reviews")
    user = relationship("User", back_populates="reviews")
    
    def __repr__(self):
        return f"<Review(id={self.review_id}, movie_id={self.movie_id}, user_id={self.user_id}, rating={self.rating})>"
    
    def to_dict(self):
        """Convert review object to dictionary"""
        return {
            'id': self.review_id,
            'movie_id': self.movie_id,
            'user_id': self.user_id,
            'rating': self.rating,
            'review_text': self.review_text,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'user': self.user.to_dict() if self.user else None,
            'movie': {'id': self.movie.movie_id, 'title': self.movie.title} if self.movie else None
        }