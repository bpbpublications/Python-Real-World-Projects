"""
Movie model for the database
"""

from sqlalchemy import Column, Integer, String, Text, Float, DateTime, func
from sqlalchemy.orm import relationship
from database.database import Base

class Movie(Base):
    __tablename__ = "movies"
    
    movie_id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    release_year = Column(Integer)
    genre = Column(String(100))
    director = Column(String(255))
    plot = Column(Text)
    runtime = Column(Integer)  # in minutes
    rating = Column(Float, default=0.0)
    poster_url = Column(Text)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    reviews = relationship("Review", back_populates="movie", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Movie(id={self.movie_id}, title='{self.title}', year={self.release_year})>"
    
    def to_dict(self):
        """Convert movie object to dictionary"""
        return {
            'id': self.movie_id,
            'title': self.title,
            'release_year': self.release_year,
            'genre': self.genre,
            'director': self.director,
            'plot': self.plot,
            'runtime': self.runtime,
            'rating': self.rating,
            'poster_url': self.poster_url,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }