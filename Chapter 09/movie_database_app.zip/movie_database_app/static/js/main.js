// Movie Database Application JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize application
    initializeApp();
});

function initializeApp() {
    // Set up search functionality
    setupSearch();
    
    // Set up form validation
    setupFormValidation();
    
    // Set up interactive elements
    setupInteractiveElements();
    
    console.log('Movie Database App initialized');
}

function setupSearch() {
    const searchForm = document.querySelector('.search-form');
    const searchInput = document.querySelector('.search-input');
    
    if (searchForm && searchInput) {
        // Auto-focus search input on search page
        if (window.location.pathname.includes('/movies/')) {
            searchInput.focus();
        }
        
        // Add search suggestions (if needed in future)
        searchInput.addEventListener('input', function() {
            // Placeholder for search suggestions
        });
    }
}

function setupFormValidation() {
    // Movie form validation
    const movieForm = document.querySelector('.movie-form');
    if (movieForm) {
        movieForm.addEventListener('submit', function(e) {
            if (!validateMovieForm()) {
                e.preventDefault();
                return false;
            }
        });
    }
    
    // Auth form validation
    const authForms = document.querySelectorAll('.auth-form');
    authForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateAuthForm(this)) {
                e.preventDefault();
                return false;
            }
        });
    });
}

function validateMovieForm() {
    const title = document.getElementById('title');
    const year = document.getElementById('release_year');
    const director = document.getElementById('director');
    const genre = document.getElementById('genre');
    const runtime = document.getElementById('runtime');
    const plot = document.getElementById('plot');
    
    let isValid = true;
    
    // Clear previous errors
    clearFormErrors();
    
    // Validate title
    if (!title.value.trim()) {
        showFieldError(title, 'Title is required');
        isValid = false;
    }
    
    // Validate year
    const currentYear = new Date().getFullYear();
    if (!year.value || year.value < 1900 || year.value > currentYear + 5) {
        showFieldError(year, `Year must be between 1900 and ${currentYear + 5}`);
        isValid = false;
    }
    
    // Validate director
    if (!director.value.trim()) {
        showFieldError(director, 'Director is required');
        isValid = false;
    }
    
    // Validate genre
    if (!genre.value.trim()) {
        showFieldError(genre, 'Genre is required');
        isValid = false;
    }
    
    // Validate runtime
    if (!runtime.value || runtime.value < 1 || runtime.value > 600) {
        showFieldError(runtime, 'Runtime must be between 1 and 600 minutes');
        isValid = false;
    }
    
    // Validate plot
    if (!plot.value.trim()) {
        showFieldError(plot, 'Plot summary is required');
        isValid = false;
    } else if (plot.value.length < 20) {
        showFieldError(plot, 'Plot summary should be at least 20 characters');
        isValid = false;
    }
    
    return isValid;
}

function validateAuthForm(form) {
    const username = form.querySelector('#username');
    const email = form.querySelector('#email');
    const password = form.querySelector('#password');
    
    let isValid = true;
    
    // Clear previous errors
    clearFormErrors();
    
    // Validate username
    if (username && (!username.value.trim() || username.value.length < 3)) {
        showFieldError(username, 'Username must be at least 3 characters');
        isValid = false;
    }
    
    // Validate email (for registration)
    if (email && !isValidEmail(email.value)) {
        showFieldError(email, 'Please enter a valid email address');
        isValid = false;
    }
    
    // Validate password
    if (!password.value || password.value.length < 6) {
        showFieldError(password, 'Password must be at least 6 characters');
        isValid = false;
    }
    
    return isValid;
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showFieldError(field, message) {
    // Remove existing error
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
    
    // Add error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.color = '#e74c3c';
    errorDiv.style.fontSize = '0.9rem';
    errorDiv.style.marginTop = '0.25rem';
    
    field.parentNode.appendChild(errorDiv);
    field.style.borderColor = '#e74c3c';
}

function clearFormErrors() {
    // Remove all error messages
    const errors = document.querySelectorAll('.field-error');
    errors.forEach(error => error.remove());
    
    // Reset field border colors
    const fields = document.querySelectorAll('input, textarea, select');
    fields.forEach(field => {
        field.style.borderColor = '#ecf0f1';
    });
}

function setupInteractiveElements() {
    // Rating stars interaction
    setupRatingStars();
    
    // Image error handling
    setupImageErrorHandling();
    
    // Smooth scrolling for anchors
    setupSmoothScrolling();
}

function setupRatingStars() {
    const ratingSelect = document.getElementById('rating');
    if (ratingSelect) {
        ratingSelect.addEventListener('change', function() {
            updateRatingDisplay(this.value);
        });
    }
}

function updateRatingDisplay(rating) {
    // This could be used to show star preview when selecting rating
    console.log('Rating selected:', rating);
}

function setupImageErrorHandling() {
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('error', function() {
            this.style.display = 'none';
            
            // Optionally show a placeholder
            const placeholder = document.createElement('div');
            placeholder.className = 'image-placeholder';
            placeholder.textContent = 'Image not available';
            placeholder.style.cssText = `
                background: #f8f9fa;
                border: 2px dashed #dee2e6;
                padding: 2rem;
                text-align: center;
                color: #6c757d;
                border-radius: 8px;
            `;
            
            this.parentNode.insertBefore(placeholder, this);
        });
    });
}

function setupSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Utility functions
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        border-radius: 5px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);