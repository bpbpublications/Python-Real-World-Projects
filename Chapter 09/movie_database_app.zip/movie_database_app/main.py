#!/usr/bin/env python3
"""
Movie Database Application - Main Entry Point
Chapter 9: Database Integration with Python

A complete FastAPI-based web application demonstrating database integration
with SQLAlchemy ORM, user authentication, and CRUD operations.

Usage:
    python main.py

Features:
    - Movie database with search functionality
    - User registration and authentication
    - Movie reviews and ratings
    - Responsive web interface
    - REST API endpoints
"""

import os
import sys
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse

# Add the current directory to Python path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Import application modules
from config import Config
from database import init_db
from routes.main_routes import MainRoutes
from routes.movie_routes import MovieRoutes
from routes.user_routes import UserRoutes

def create_app() -> FastAPI:
    """Create and configure the FastAPI application"""
    
    # Initialize FastAPI app
    app = FastAPI(
        title=Config.APP_NAME,
        version=Config.VERSION,
        description="A comprehensive movie database application with user reviews and ratings"
    )
    
    # Mount static files
    static_path = os.path.join(current_dir, "static")
    if os.path.exists(static_path):
        app.mount("/static", StaticFiles(directory=static_path), name="static")
    
    # Initialize database
    init_db()
    
    # Set up routes
    main_routes = MainRoutes()
    movie_routes = MovieRoutes()
    user_routes = UserRoutes()
    
    # Include routers
    app.include_router(main_routes.router)
    app.include_router(movie_routes.router)
    app.include_router(movie_routes.api_router)
    app.include_router(user_routes.router)
    
    # Add review submission route
    @app.post("/movies/{movie_id}/reviews")
    async def add_review(
        movie_id: int,
        rating: int,
        review_text: str,
        db=None  # This would normally use Depends(get_db) and current user
    ):
        """Add a review for a movie (simplified for demo)"""
        from fastapi import Form, Depends
        from sqlalchemy.orm import Session
        from database import get_db
        from services.review_service import ReviewService
        
        # In a real app, get user_id from session/JWT
        # For demo, use a fixed user ID
        user_id = 1
        
        review_data = {
            "movie_id": movie_id,
            "user_id": user_id,
            "rating": rating,
            "review_text": review_text
        }
        
        # This would need proper dependency injection in a real implementation
        # ReviewService.create_review(db, review_data)
        
        from fastapi.responses import RedirectResponse
        return RedirectResponse(url=f"/movies/{movie_id}", status_code=303)
    
    return app

def main():
    """Main entry point for the application"""
    print("=" * 60)
    print("🎬 Movie Database Application - Chapter 9")
    print("=" * 60)
    print(f"Starting {Config.APP_NAME} v{Config.VERSION}")
    print(f"Database: {Config.DATABASE_URL}")
    print(f"Debug mode: {Config.DEBUG}")
    print()
    
    # Create the application
    app = create_app()
    
    print("Application initialized successfully!")
    print(f"Visit: http://{Config.HOST}:{Config.PORT}")
    print("API Documentation: http://localhost:8000/docs")
    print()
    print("Features available:")
    print("✓ Browse and search movies")
    print("✓ Add new movies")
    print("✓ User registration and login")
    print("✓ Movie reviews and ratings")
    print("✓ REST API endpoints")
    print()
    
    # Run the application
    import uvicorn
    uvicorn.run(
        app,
        host=Config.HOST,
        port=Config.PORT,
        reload=Config.DEBUG
    )

if __name__ == "__main__":
    main()