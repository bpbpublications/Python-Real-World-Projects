
import json
import os
import tempfile
from datetime import datetime
import pytest
from src.todo_cli.todo import TodoList


@pytest.fixture
def todo_file():
    fd, path = tempfile.mkstemp()
    os.close(fd)
    yield path
    os.unlink(path)


def test_add_todo(todo_file):
    todo_list = TodoList(todo_file)
    todo_id = todo_list.add_todo("Test todo")
    assert todo_id == 1
    todos = todo_list.list_todos()
    assert len(todos) == 1
    assert todos[0]["description"] == "Test todo"
    assert not todos[0]["completed"]


def test_complete_todo(todo_file):
    todo_list = TodoList(todo_file)
    todo_id = todo_list.add_todo("Test todo")
    success = todo_list.complete_todo(todo_id)
    assert success
    todo = todo_list.get_todo(todo_id)
    assert todo["completed"]
    assert todo["completed_at"] is not None


def test_delete_todo(todo_file):
    todo_list = TodoList(todo_file)
    todo_id = todo_list.add_todo("Test todo")
    success = todo_list.delete_todo(todo_id)
    assert success
    todos = todo_list.list_todos()
    assert len(todos) == 0


def test_persistence(todo_file):
    todo_list1 = TodoList(todo_file)
    todo_list1.add_todo("Test todo")
    todo_list2 = TodoList(todo_file)
    todos = todo_list2.list_todos()
    assert len(todos) == 1
    assert todos[0]["description"] == "Test todo"
