
"""Todo list management module."""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional


class TodoList:
    def __init__(self, file_path: str = None):
        self.file_path = file_path or os.path.expanduser("~/.todo.json")
        self.todos = self._load_todos()

    def _load_todos(self) -> List[Dict]:
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, "r") as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return []
        return []

    def _save_todos(self) -> None:
        with open(self.file_path, "w") as f:
            json.dump(self.todos, f, indent=2)

    def add_todo(self, description: str) -> int:
        todo_id = len(self.todos) + 1
        self.todos.append({
            "id": todo_id,
            "description": description,
            "completed": False,
            "created_at": datetime.now().isoformat(),
            "completed_at": None
        })
        self._save_todos()
        return todo_id

    def list_todos(self) -> List[Dict]:
        return self.todos

    def complete_todo(self, todo_id: int) -> bool:
        for todo in self.todos:
            if todo["id"] == todo_id:
                todo["completed"] = True
                todo["completed_at"] = datetime.now().isoformat()
                self._save_todos()
                return True
        return False

    def delete_todo(self, todo_id: int) -> bool:
        for i, todo in enumerate(self.todos):
            if todo["id"] == todo_id:
                self.todos.pop(i)
                self._save_todos()
                return True
        return False

    def get_todo(self, todo_id: int) -> Optional[Dict]:
        for todo in self.todos:
            if todo["id"] == todo_id:
                return todo
        return None
