
"""Command-line interface for the todo application."""

import argparse
import sys
from typing import List, Optional
from .todo import TodoList


def parse_args(args: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="A simple todo list application")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    add_parser = subparsers.add_parser("add", help="Add a new todo")
    add_parser.add_argument("description", help="Todo description")

    subparsers.add_parser("list", help="List all todos")

    complete_parser = subparsers.add_parser("complete", help="Mark a todo as completed")
    complete_parser.add_argument("id", type=int, help="Todo ID")

    delete_parser = subparsers.add_parser("delete", help="Delete a todo")
    delete_parser.add_argument("id", type=int, help="Todo ID")

    return parser.parse_args(args)


def main(args: Optional[List[str]] = None) -> int:
    parsed_args = parse_args(args)
    todo_list = TodoList()

    if parsed_args.command == "add":
        todo_id = todo_list.add_todo(parsed_args.description)
        print(f"Added todo {todo_id}: {parsed_args.description}")
        return 0

    elif parsed_args.command == "list":
        todos = todo_list.list_todos()
        if not todos:
            print("No todos found.")
            return 0
        print("ID | Status | Description")
        print("-" * 50)
        for todo in todos:
            status = "✓" if todo["completed"] else " "
            print(f"{todo['id']:2d} | [{status}]    | {todo['description']}")
        return 0

    elif parsed_args.command == "complete":
        success = todo_list.complete_todo(parsed_args.id)
        print(f"Marked todo {parsed_args.id} as completed." if success else f"Todo with ID {parsed_args.id} not found.")
        return 0

    elif parsed_args.command == "delete":
        success = todo_list.delete_todo(parsed_args.id)
        print(f"Deleted todo {parsed_args.id}." if success else f"Todo with ID {parsed_args.id} not found.")
        return 0

    else:
        print("Please specify a valid command.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
