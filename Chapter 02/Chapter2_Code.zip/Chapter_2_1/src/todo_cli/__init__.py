"""Todo CLI - A simple command-line todo list application."""

__version__ = "0.1.0"
