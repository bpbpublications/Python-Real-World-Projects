# To-Do CLI

A simple command-line todo list application.
