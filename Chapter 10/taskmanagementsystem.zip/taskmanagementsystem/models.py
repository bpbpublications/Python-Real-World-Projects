"""
Database models for the Task Management System
"""

from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(UserMixin, db.Model):
    """User model for authentication"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    tasks = db.relationship('Task', backref='user', lazy=True, cascade='all, delete-orphan')
    categories = db.relationship('Category', backref='user', lazy=True, cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if password is correct"""
        return check_password_hash(self.password_hash, password)
    
    def get_task_stats(self):
        """Get user's task statistics"""
        total_tasks = len(self.tasks)
        completed_tasks = len([t for t in self.tasks if t.status == 'completed'])
        pending_tasks = len([t for t in self.tasks if t.status == 'pending'])
        in_progress_tasks = len([t for t in self.tasks if t.status == 'in_progress'])
        
        return {
            'total': total_tasks,
            'completed': completed_tasks,
            'pending': pending_tasks,
            'in_progress': in_progress_tasks,
            'completion_rate': (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        }
    
    def __repr__(self):
        return f'<User {self.username}>'

class Category(db.Model):
    """Category model for organizing tasks"""
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    color = db.Column(db.String(7), default='#007bff')  # Hex color code
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    
    # Relationships
    tasks = db.relationship('Task', backref='category', lazy=True)
    
    def __repr__(self):
        return f'<Category {self.name}>'

class Task(db.Model):
    """Task model for task management"""
    __tablename__ = 'tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')  # pending, in_progress, completed
    priority = db.Column(db.String(20), default='medium')  # low, medium, high, critical
    due_date = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    
    def mark_completed(self):
        """Mark task as completed"""
        self.status = 'completed'
        self.completed_at = datetime.now(timezone.utc)
        self.updated_at = datetime.now(timezone.utc)
    
    def mark_pending(self):
        """Mark task as pending"""
        self.status = 'pending'
        self.completed_at = None
        self.updated_at = datetime.now(timezone.utc)
    
    def mark_in_progress(self):
        """Mark task as in progress"""
        self.status = 'in_progress'
        self.completed_at = None
        self.updated_at = datetime.now(timezone.utc)
    
    def is_overdue(self):
        """Check if task is overdue"""
        if self.due_date and self.status != 'completed':
            # Handle timezone-aware comparison
            now = datetime.now(timezone.utc)
            due_date = self.due_date
            
            # If due_date is naive, make it timezone-aware
            if due_date.tzinfo is None:
                due_date = due_date.replace(tzinfo=timezone.utc)
            
            return now > due_date
        return False
    
    def days_until_due(self):
        """Calculate days until due date"""
        if self.due_date:
            now = datetime.now(timezone.utc)
            due_date = self.due_date
            
            # If due_date is naive, make it timezone-aware
            if due_date.tzinfo is None:
                due_date = due_date.replace(tzinfo=timezone.utc)
            
            delta = due_date - now
            return delta.days
        return None
    
    def get_priority_class(self):
        """Get CSS class for priority styling"""
        priority_classes = {
            'low': 'text-success',
            'medium': 'text-warning',
            'high': 'text-danger',
            'critical': 'text-danger fw-bold'
        }
        return priority_classes.get(self.priority, 'text-secondary')
    
    def get_status_class(self):
        """Get CSS class for status styling"""
        status_classes = {
            'pending': 'text-secondary',
            'in_progress': 'text-primary',
            'completed': 'text-success'
        }
        return status_classes.get(self.status, 'text-secondary')
    
    def __repr__(self):
        return f'<Task {self.title}>'