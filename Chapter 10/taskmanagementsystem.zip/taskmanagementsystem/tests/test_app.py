"""
Unit tests for the Task Management System
"""

import pytest
from app import create_app
from models import db, User, Task, Category


@pytest.fixture
def app():
    """Create test application"""
    app = create_app('testing')
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    """Create test client"""
    return app.test_client()


@pytest.fixture
def sample_user(app):
    """Create a sample user for testing"""
    with app.app_context():
        user = User(
            first_name='Test',
            last_name='User',
            username='testuser',
            email='test@example.com'
        )
        user.set_password('password')
        db.session.add(user)
        db.session.commit()
        return user


@pytest.fixture
def sample_category(app, sample_user):
    """Create a sample category for testing"""
    with app.app_context():
        category = Category(
            name='Test Category',
            description='Test description',
            color='#007bff',
            user_id=sample_user.id
        )
        db.session.add(category)
        db.session.commit()
        return category


@pytest.fixture
def sample_task(app, sample_user, sample_category):
    """Create a sample task for testing"""
    with app.app_context():
        task = Task(
            title='Test Task',
            description='Test description',
            status='pending',
            priority='medium',
            user_id=sample_user.id,
            category_id=sample_category.id
        )
        db.session.add(task)
        db.session.commit()
        return task


def login_user(client, email='test@example.com', password='password'):
    """Helper function to login a user"""
    return client.post('/login', data={
        'email': email,
        'password': password
    }, follow_redirects=True)


def test_app_creation(app):
    """Test that the app is created successfully"""
    assert app is not None
    assert app.config['TESTING'] is True


def test_index_page(client):
    """Test the index page"""
    response = client.get('/')
    assert response.status_code == 200
    assert b'Task Management System' in response.data


def test_user_registration(client):
    """Test user registration"""
    response = client.post('/register', data={
        'first_name': 'John',
        'last_name': 'Doe',
        'username': 'johndoe',
        'email': 'john@example.com',
        'password': 'password123',
        'confirm_password': 'password123'
    }, follow_redirects=True)
    
    assert response.status_code == 200
    assert b'Registration successful' in response.data


def test_user_login(client, sample_user):
    """Test user login"""
    response = login_user(client)
    assert response.status_code == 200
    assert b'Dashboard' in response.data


def test_dashboard_requires_login(client):
    """Test that dashboard requires login"""
    response = client.get('/dashboard')
    assert response.status_code == 302  # Redirect to login


def test_dashboard_with_login(client, sample_user):
    """Test dashboard with logged in user"""
    login_user(client)
    response = client.get('/dashboard')
    assert response.status_code == 200
    assert b'Dashboard' in response.data


def test_create_task(client, sample_user):
    """Test task creation"""
    login_user(client)
    response = client.post('/tasks/create', data={
        'title': 'New Task',
        'description': 'Task description',
        'status': 'pending',
        'priority': 'high',
        'category_id': 0
    }, follow_redirects=True)
    
    assert response.status_code == 200
    assert b'Task created successfully' in response.data


def test_view_tasks(client, sample_user, sample_task):
    """Test viewing tasks"""
    login_user(client)
    response = client.get('/tasks')
    assert response.status_code == 200
    assert b'Test Task' in response.data


def test_edit_task(client, sample_user, sample_task):
    """Test editing a task"""
    login_user(client)
    response = client.post(f'/tasks/{sample_task.id}/edit', data={
        'title': 'Updated Task',
        'description': 'Updated description',
        'status': 'completed',
        'priority': 'high',
        'category_id': 0
    }, follow_redirects=True)
    
    assert response.status_code == 200
    assert b'Task updated successfully' in response.data


def test_delete_task(client, sample_user, sample_task):
    """Test deleting a task"""
    login_user(client)
    response = client.post(f'/tasks/{sample_task.id}/delete', follow_redirects=True)
    assert response.status_code == 200
    assert b'Task deleted successfully' in response.data


def test_create_category(client, sample_user):
    """Test category creation"""
    login_user(client)
    response = client.post('/categories/create', data={
        'name': 'New Category',
        'description': 'Category description',
        'color': '#28a745'
    }, follow_redirects=True)
    
    assert response.status_code == 200
    assert b'Category created successfully' in response.data


def test_view_categories(client, sample_user, sample_category):
    """Test viewing categories"""
    login_user(client)
    response = client.get('/categories')
    assert response.status_code == 200
    assert b'Test Category' in response.data


def test_task_search(client, sample_user, sample_task):
    """Test task search functionality"""
    login_user(client)
    response = client.get('/tasks?search_query=Test')
    assert response.status_code == 200
    assert b'Test Task' in response.data


def test_task_filter_by_status(client, sample_user, sample_task):
    """Test filtering tasks by status"""
    login_user(client)
    response = client.get('/tasks?status_filter=pending')
    assert response.status_code == 200


def test_task_filter_by_priority(client, sample_user, sample_task):
    """Test filtering tasks by priority"""
    login_user(client)
    response = client.get('/tasks?priority_filter=medium')
    assert response.status_code == 200


def test_toggle_task_status(client, sample_user, sample_task):
    """Test toggling task status via AJAX"""
    login_user(client)
    response = client.post(f'/tasks/{sample_task.id}/toggle-status',
                          headers={'Content-Type': 'application/json'})
    assert response.status_code == 200
    
    json_data = response.get_json()
    assert json_data['success'] is True
    assert json_data['status'] == 'completed'


def test_user_logout(client, sample_user):
    """Test user logout"""
    login_user(client)
    response = client.get('/logout', follow_redirects=True)
    assert response.status_code == 200
    assert b'You have been logged out' in response.data


def test_user_model_password_hashing(sample_user):
    """Test user password hashing"""
    assert sample_user.password_hash != 'password'
    assert sample_user.check_password('password') is True
    assert sample_user.check_password('wrongpassword') is False


def test_task_model_methods(sample_task):
    """Test task model methods"""
    assert sample_task.is_overdue() is False
    
    sample_task.mark_completed()
    assert sample_task.status == 'completed'
    assert sample_task.completed_at is not None
    
    sample_task.mark_pending()
    assert sample_task.status == 'pending'
    assert sample_task.completed_at is None


def test_user_task_stats(sample_user, sample_task):
    """Test user task statistics"""
    stats = sample_user.get_task_stats()
    assert stats['total'] == 1
    assert stats['pending'] == 1
    assert stats['completed'] == 0
    assert stats['completion_rate'] == 0.0


def test_404_error_handler(client):
    """Test 404 error handler"""
    response = client.get('/nonexistent-page')
    assert response.status_code == 404
    assert b'404 Not Found' in response.data


def test_invalid_login(client):
    """Test invalid login credentials"""
    response = client.post('/login', data={
        'email': 'invalid@example.com',
        'password': 'wrongpassword'
    })
    assert response.status_code == 200
    assert b'Invalid email or password' in response.data


def test_duplicate_username_registration(client, sample_user):
    """Test duplicate username registration"""
    response = client.post('/register', data={
        'first_name': 'Jane',
        'last_name': 'Doe',
        'username': 'testuser',  # Same as sample_user
        'email': 'jane@example.com',
        'password': 'password123',
        'confirm_password': 'password123'
    })
    assert response.status_code == 200
    assert b'Username already exists' in response.data


def test_password_confirmation_mismatch(client):
    """Test password confirmation mismatch"""
    response = client.post('/register', data={
        'first_name': 'Jane',
        'last_name': 'Doe',
        'username': 'janedoe',
        'email': 'jane@example.com',
        'password': 'password123',
        'confirm_password': 'differentpassword'
    })
    assert response.status_code == 200
    assert b'Passwords must match' in response.data


if __name__ == '__main__':
    pytest.main([__file__])