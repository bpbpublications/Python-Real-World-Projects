#!/usr/bin/env python3
"""
Setup script for Task Management System
"""

import os
import sys
import subprocess
import platform

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("Error: Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        sys.exit(1)
    print(f"✓ Python {sys.version.split()[0]} is compatible")

def create_virtual_environment():
    """Create virtual environment"""
    venv_name = "venv"
    
    if os.path.exists(venv_name):
        print("✓ Virtual environment already exists")
        return
    
    print("Creating virtual environment...")
    try:
        subprocess.run([sys.executable, "-m", "venv", venv_name], check=True)
        print("✓ Virtual environment created successfully")
    except subprocess.CalledProcessError:
        print("✗ Failed to create virtual environment")
        sys.exit(1)

def get_activation_command():
    """Get the command to activate virtual environment"""
    if platform.system() == "Windows":
        return "venv\\Scripts\\activate"
    else:
        return "source venv/bin/activate"

def install_dependencies():
    """Install project dependencies"""
    print("Installing dependencies...")
    
    # Get the appropriate pip command
    if platform.system() == "Windows":
        pip_cmd = "venv\\Scripts\\pip"
    else:
        pip_cmd = "venv/bin/pip"
    
    try:
        subprocess.run([pip_cmd, "install", "-r", "requirements.txt"], check=True)
        print("✓ Dependencies installed successfully")
    except subprocess.CalledProcessError:
        print("✗ Failed to install dependencies")
        sys.exit(1)

def initialize_database():
    """Initialize the database with sample data"""
    print("Initializing database...")
    
    # Get the appropriate python command
    if platform.system() == "Windows":
        python_cmd = "venv\\Scripts\\python"
    else:
        python_cmd = "venv/bin/python"
    
    try:
        subprocess.run([python_cmd, "init_db.py"], check=True)
        print("✓ Database initialized successfully")
    except subprocess.CalledProcessError:
        print("✗ Failed to initialize database")
        sys.exit(1)

def main():
    """Main setup function"""
    print("=" * 60)
    print("Task Management System - Setup")
    print("=" * 60)
    
    # Check Python version
    check_python_version()
    
    # Create virtual environment
    create_virtual_environment()
    
    # Install dependencies
    install_dependencies()
    
    # Initialize database
    initialize_database()
    
    print("\n" + "=" * 60)
    print("Setup completed successfully!")
    print("=" * 60)
    print("\nTo run the application:")
    print(f"1. Activate virtual environment: {get_activation_command()}")
    print("2. Run the application: python app.py")
    print("3. Visit: http://localhost:5000")
    print("\nDemo Account:")
    print("  Email: demo@example.com")
    print("  Password: demo123")
    print("\nFor development:")
    print("  Run: python run_local.py")
    print("\nFor testing:")
    print("  Run: pytest tests/")
    print("=" * 60)

if __name__ == "__main__":
    main()