"""
Main Flask application for the Task Management System
"""

import os
import logging
from datetime import datetime, timezone
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect, generate_csrf
from config import config
from models import db, User, Task, Category
from forms import LoginForm, RegisterForm, TaskForm, CategoryForm, SearchForm

def create_app(config_name=None):
    """Create and configure the Flask application"""
    app = Flask(__name__)
    
    # Load configuration
    config_name = config_name or os.environ.get('FLASK_ENV', 'development')
    app.config.from_object(config[config_name])
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    logger.info(f"Starting Task Management System in {config_name} mode")
    
    # Initialize extensions
    db.init_app(app)
    
    # Setup CSRF protection
    csrf = CSRFProtect(app)
    
    # Setup Flask-Login
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'
    
    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))
    
    # Make csrf_token available in templates
    @app.template_global()
    def csrf_token():
        return generate_csrf()
    
    return app

app = create_app()

# Routes
@app.route('/')
def index():
    """Homepage"""
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    form = RegisterForm()
    if form.validate_on_submit():
        user = User(
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            username=form.username.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        
        # Create default categories
        db.session.add(user)
        db.session.commit()
        
        default_categories = [
            {'name': 'Work', 'description': 'Work-related tasks', 'color': '#007bff'},
            {'name': 'Personal', 'description': 'Personal tasks', 'color': '#28a745'},
            {'name': 'Shopping', 'description': 'Shopping list items', 'color': '#ffc107'},
            {'name': 'Health', 'description': 'Health and fitness tasks', 'color': '#dc3545'}
        ]
        
        for cat_data in default_categories:
            category = Category(
                name=cat_data['name'],
                description=cat_data['description'],
                color=cat_data['color'],
                user_id=user.id
            )
            db.session.add(category)
        
        db.session.commit()
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('auth/register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        flash('Invalid email or password.', 'danger')
    
    return render_template('auth/login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard"""
    stats = current_user.get_task_stats()
    recent_tasks = Task.query.filter_by(user_id=current_user.id).order_by(Task.created_at.desc()).limit(5).all()
    overdue_tasks = [task for task in current_user.tasks if task.is_overdue()]
    
    return render_template('dashboard.html', 
                         stats=stats, 
                         recent_tasks=recent_tasks,
                         overdue_tasks=overdue_tasks)

@app.route('/tasks')
@login_required
def tasks():
    """List all tasks with filtering and search"""
    form = SearchForm(user=current_user)
    
    query = Task.query.filter_by(user_id=current_user.id)
    
    # Apply filters
    if form.search_query.data:
        search_term = f"%{form.search_query.data}%"
        query = query.filter(Task.title.like(search_term) | Task.description.like(search_term))
    
    if form.status_filter.data != 'all':
        query = query.filter_by(status=form.status_filter.data)
    
    if form.priority_filter.data != 'all':
        query = query.filter_by(priority=form.priority_filter.data)
    
    if form.category_filter.data != 0:
        query = query.filter_by(category_id=form.category_filter.data)
    
    # Apply sorting
    if form.sort_by.data == 'created_at_desc':
        query = query.order_by(Task.created_at.desc())
    elif form.sort_by.data == 'created_at_asc':
        query = query.order_by(Task.created_at.asc())
    elif form.sort_by.data == 'due_date_asc':
        query = query.order_by(Task.due_date.asc().nullslast())
    elif form.sort_by.data == 'due_date_desc':
        query = query.order_by(Task.due_date.desc().nullsfirst())
    elif form.sort_by.data == 'title_asc':
        query = query.order_by(Task.title.asc())
    elif form.sort_by.data == 'title_desc':
        query = query.order_by(Task.title.desc())
    
    # Pagination
    page = request.args.get('page', 1, type=int)
    per_page = app.config.get('TASKS_PER_PAGE', 10)
    tasks_pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('tasks/list.html', 
                         tasks=tasks_pagination.items,
                         pagination=tasks_pagination,
                         form=form)

@app.route('/tasks/create', methods=['GET', 'POST'])
@login_required
def create_task():
    """Create a new task"""
    form = TaskForm(user=current_user)
    
    if form.validate_on_submit():
        task = Task(
            title=form.title.data,
            description=form.description.data,
            status=form.status.data,
            priority=form.priority.data,
            due_date=form.due_date.data,
            user_id=current_user.id,
            category_id=form.category_id.data if form.category_id.data != 0 else None
        )
        
        db.session.add(task)
        db.session.commit()
        flash('Task created successfully!', 'success')
        return redirect(url_for('tasks'))
    
    return render_template('tasks/create.html', form=form)

@app.route('/tasks/<int:task_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    """Edit an existing task"""
    logger = logging.getLogger(__name__)
    logger.info(f"Editing task {task_id} for user {current_user.id}")
    
    task = Task.query.filter_by(id=task_id, user_id=current_user.id).first_or_404()
    form = TaskForm(user=current_user, obj=task)
    
    if form.validate_on_submit():
        logger.info(f"Form validated successfully for task {task_id}")
        form.populate_obj(task)
        task.category_id = form.category_id.data if form.category_id.data != 0 else None
        task.updated_at = datetime.now(timezone.utc)
        
        if task.status == 'completed' and not task.completed_at:
            task.completed_at = datetime.now(timezone.utc)
            logger.info(f"Task {task_id} marked as completed")
        elif task.status != 'completed':
            task.completed_at = None
            logger.info(f"Task {task_id} status changed to {task.status}")
        
        try:
            db.session.commit()
            logger.info(f"Task {task_id} updated successfully")
            flash('Task updated successfully!', 'success')
            return redirect(url_for('tasks'))
        except Exception as e:
            logger.error(f"Error updating task {task_id}: {str(e)}")
            db.session.rollback()
            flash('Error updating task. Please try again.', 'error')
    else:
        if form.errors:
            logger.warning(f"Form validation errors for task {task_id}: {form.errors}")
    
    return render_template('tasks/edit.html', form=form, task=task)

@app.route('/tasks/<int:task_id>/delete', methods=['POST'])
@login_required
def delete_task(task_id):
    """Delete a task"""
    task = Task.query.filter_by(id=task_id, user_id=current_user.id).first_or_404()
    db.session.delete(task)
    db.session.commit()
    flash('Task deleted successfully!', 'success')
    return redirect(url_for('tasks'))

@app.route('/tasks/<int:task_id>/toggle-status', methods=['POST'])
@login_required
def toggle_task_status(task_id):
    """Toggle task status (AJAX endpoint)"""
    logger = logging.getLogger(__name__)
    logger.info(f"Toggling status for task {task_id} by user {current_user.id}")
    
    try:
        task = Task.query.filter_by(id=task_id, user_id=current_user.id).first_or_404()
        old_status = task.status
        
        if task.status == 'completed':
            task.mark_pending()
        else:
            task.mark_completed()
        
        db.session.commit()
        logger.info(f"Task {task_id} status changed from {old_status} to {task.status}")
        
        return jsonify({
            'success': True,
            'status': task.status,
            'completed_at': task.completed_at.isoformat() if task.completed_at else None
        })
    except Exception as e:
        logger.error(f"Error toggling task {task_id} status: {str(e)}")
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Error updating task status'
        }), 500

@app.route('/categories')
@login_required
def categories():
    """List all categories"""
    categories = Category.query.filter_by(user_id=current_user.id).all()
    return render_template('categories/list.html', categories=categories)

@app.route('/categories/create', methods=['GET', 'POST'])
@login_required
def create_category():
    """Create a new category"""
    form = CategoryForm(user=current_user)
    
    if form.validate_on_submit():
        category = Category(
            name=form.name.data,
            description=form.description.data,
            color=form.color.data,
            user_id=current_user.id
        )
        
        db.session.add(category)
        db.session.commit()
        flash('Category created successfully!', 'success')
        return redirect(url_for('categories'))
    
    return render_template('categories/create.html', form=form)

@app.route('/categories/<int:category_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_category(category_id):
    """Edit an existing category"""
    category = Category.query.filter_by(id=category_id, user_id=current_user.id).first_or_404()
    form = CategoryForm(user=current_user, category=category, obj=category)
    
    if form.validate_on_submit():
        form.populate_obj(category)
        db.session.commit()
        flash('Category updated successfully!', 'success')
        return redirect(url_for('categories'))
    
    return render_template('categories/edit.html', form=form, category=category)

@app.route('/categories/<int:category_id>/delete', methods=['POST'])
@login_required
def delete_category(category_id):
    """Delete a category"""
    category = Category.query.filter_by(id=category_id, user_id=current_user.id).first_or_404()
    
    # Update tasks to remove category reference
    Task.query.filter_by(category_id=category_id).update({'category_id': None})
    
    db.session.delete(category)
    db.session.commit()
    flash('Category deleted successfully!', 'success')
    return redirect(url_for('categories'))

# Error handlers
@app.errorhandler(404)
def not_found(error):
    """404 error handler"""
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """500 error handler"""
    db.session.rollback()
    return render_template('errors/500.html'), 500

# Template filters
@app.template_filter('datetime')
def datetime_filter(value):
    """Format datetime for display"""
    if value is None:
        return ''
    return value.strftime('%Y-%m-%d %H:%M')

@app.template_filter('date')
def date_filter(value):
    """Format date for display"""
    if value is None:
        return ''
    return value.strftime('%Y-%m-%d')

@app.template_filter('time_ago')
def time_ago_filter(value):
    """Human-readable time ago"""
    if value is None:
        return ''
    
    now = datetime.now(timezone.utc)
    
    # Handle timezone-aware comparison for time_ago
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    
    diff = now - value
    
    if diff.days > 0:
        return f"{diff.days} day{'s' if diff.days != 1 else ''} ago"
    elif diff.seconds > 3600:
        hours = diff.seconds // 3600
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif diff.seconds > 60:
        minutes = diff.seconds // 60
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    else:
        return "Just now"

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)