# Chapter 10: Task Management System
## Flask Web Application Mini-Project

A comprehensive task management web application built with Flask demonstrating full-stack web development concepts.

## Features

- **Task Management**: Create, read, update, and delete tasks
- **User Authentication**: Register, login, and logout functionality
- **Task Categories**: Organize tasks by categories (Work, Personal, Shopping, etc.)
- **Priority Levels**: Set task priorities (Low, Medium, High, Critical)
- **Due Dates**: Set and track task deadlines
- **Status Tracking**: Mark tasks as pending, in progress, or completed
- **Search & Filter**: Find tasks by title, category, or status
- **Responsive Design**: Works on desktop and mobile devices
- **Data Persistence**: SQLite database for data storage

## Technology Stack

- **Backend**: Flask (Python web framework)
- **Database**: SQLite with SQLAlchemy ORM
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Authentication**: Flask-Login for session management
- **Forms**: Flask-WTF for form handling and validation
- **Security**: CSRF protection, password hashing

## Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Installation Steps

1. **Clone or Extract the Project**
   ```bash
   cd chapter10_task_management_system
   ```

2. **Create Virtual Environment**
   ```bash
   python -m venv venv
   ```

3. **Activate Virtual Environment**
   
   On Windows:
   ```bash
   venv\Scripts\activate
   ```
   
   On macOS/Linux:
   ```bash
   source venv/bin/activate
   ```

4. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

5. **Initialize Database**
   ```bash
   python init_db.py
   ```

6. **Run the Application**
   ```bash
   python app.py
   ```

7. **Access the Application**
   Open your browser and go to: `http://localhost:5000`

## Usage

1. **Registration**: Create a new account or use the demo account
2. **Login**: Sign in with your credentials
3. **Dashboard**: View all your tasks and statistics
4. **Create Task**: Add new tasks with details, categories, and due dates
5. **Manage Tasks**: Edit, delete, or mark tasks as completed
6. **Filter Tasks**: Use the search and filter options to find specific tasks
7. **Categories**: Organize tasks by creating custom categories

## Project Structure

```
chapter10_task_management_system/
├── app.py                 # Main Flask application
├── models.py              # Database models (User, Task, Category)
├── forms.py               # WTForms for form validation
├── init_db.py             # Database initialization script
├── requirements.txt       # Python dependencies
├── config.py              # Application configuration
├── static/
│   ├── css/
│   │   └── styles.css     # Custom stylesheets
│   └── js/
│       └── main.js        # JavaScript functionality
├── templates/
│   ├── base.html          # Base template
│   ├── index.html         # Homepage
│   ├── dashboard.html     # User dashboard
│   ├── auth/
│   │   ├── login.html     # Login form
│   │   └── register.html  # Registration form
│   └── tasks/
│       ├── list.html      # Task list view
│       ├── create.html    # Task creation form
│       └── edit.html      # Task editing form
└── tests/
    └── test_app.py        # Unit tests
```

## Configuration

The application uses environment variables for configuration:

- `SECRET_KEY`: Flask secret key for session management
- `DATABASE_URL`: Database connection string (defaults to SQLite)
- `DEBUG`: Enable/disable debug mode

## Demo Account

For testing purposes, the application includes a demo account:
- **Username**: demo@example.com
- **Password**: demo123

## Learning Objectives

This project demonstrates:

1. **Flask Fundamentals**: Routing, templates, request handling
2. **Database Integration**: SQLAlchemy ORM, migrations, relationships
3. **User Authentication**: Registration, login, session management
4. **Form Handling**: WTForms validation, CSRF protection
5. **Frontend Integration**: HTML templates, CSS styling, JavaScript
6. **Security**: Password hashing, input validation, authentication
7. **Project Structure**: Organizing a Flask application properly
8. **Testing**: Unit tests with pytest and Flask-Testing

## Next Steps

After completing this project, consider:

1. **Add Features**: Task sharing, file attachments, notifications
2. **Improve UI**: Add more interactive elements, better styling
3. **Deploy**: Deploy to Heroku, AWS, or other cloud platforms
4. **API**: Add REST API endpoints for mobile app integration
5. **Real-time**: Implement WebSocket for real-time updates
6. **Advanced Auth**: Add OAuth, two-factor authentication

## Troubleshooting

**Database Issues**:
- Delete `tasks.db` and run `python init_db.py` again

**Module Not Found Errors**:
- Ensure virtual environment is activated
- Run `pip install -r requirements.txt`

**Port Already in Use**:
- Change the port in `app.py` or stop the conflicting process

**Permission Errors**:
- Ensure you have write permissions in the project directory

## License

This project is created for educational purposes as part of the Python learning curriculum.