"""
WTForms for the Task Management System
"""

from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, DateTimeField, PasswordField, BooleanField
from wtforms.validators import DataRequired, Email, Length, EqualTo, Optional, ValidationError
from datetime import datetime
from models import User, Category

class LoginForm(FlaskForm):
    """Login form"""
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')

class RegisterForm(FlaskForm):
    """Registration form"""
    first_name = StringField('First Name', validators=[DataRequired(), Length(min=2, max=50)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(min=2, max=50)])
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=80)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=6, message='Password must be at least 6 characters long')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    
    def validate_username(self, username):
        """Check if username already exists"""
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already exists. Please choose a different one.')
    
    def validate_email(self, email):
        """Check if email already exists"""
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already exists. Please choose a different one.')

class TaskForm(FlaskForm):
    """Task creation and editing form"""
    title = StringField('Title', validators=[DataRequired(), Length(min=1, max=200)])
    description = TextAreaField('Description', validators=[Optional(), Length(max=1000)])
    status = SelectField('Status', choices=[
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed')
    ], default='pending')
    priority = SelectField('Priority', choices=[
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical')
    ], default='medium')
    category_id = SelectField('Category', coerce=int, validators=[Optional()])
    due_date = DateTimeField('Due Date', validators=[Optional()], format='%Y-%m-%d %H:%M')
    
    def __init__(self, user=None, *args, **kwargs):
        super(TaskForm, self).__init__(*args, **kwargs)
        if user:
            self.category_id.choices = [(0, 'No Category')] + [
                (cat.id, cat.name) for cat in user.categories
            ]
        else:
            self.category_id.choices = [(0, 'No Category')]
    
    def validate_due_date(self, due_date):
        """Check if due date is not in the past"""
        if due_date.data and due_date.data < datetime.now():
            raise ValidationError('Due date cannot be in the past.')

class CategoryForm(FlaskForm):
    """Category creation and editing form"""
    name = StringField('Name', validators=[DataRequired(), Length(min=1, max=50)])
    description = TextAreaField('Description', validators=[Optional(), Length(max=500)])
    color = StringField('Color', validators=[Optional(), Length(min=7, max=7)], default='#007bff')
    
    def __init__(self, user=None, category=None, *args, **kwargs):
        super(CategoryForm, self).__init__(*args, **kwargs)
        self.user = user
        self.category = category
    
    def validate_name(self, name):
        """Check if category name already exists for this user"""
        if self.user:
            query = Category.query.filter_by(user_id=self.user.id, name=name.data)
            if self.category:
                query = query.filter(Category.id != self.category.id)
            if query.first():
                raise ValidationError('Category name already exists.')

class SearchForm(FlaskForm):
    """Search and filter form"""
    search_query = StringField('Search', validators=[Optional(), Length(max=200)])
    status_filter = SelectField('Status', choices=[
        ('all', 'All Statuses'),
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed')
    ], default='all')
    priority_filter = SelectField('Priority', choices=[
        ('all', 'All Priorities'),
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical')
    ], default='all')
    category_filter = SelectField('Category', coerce=int, default=0)
    sort_by = SelectField('Sort By', choices=[
        ('created_at_desc', 'Newest First'),
        ('created_at_asc', 'Oldest First'),
        ('due_date_asc', 'Due Date (Earliest)'),
        ('due_date_desc', 'Due Date (Latest)'),
        ('priority_desc', 'Priority (High to Low)'),
        ('priority_asc', 'Priority (Low to High)'),
        ('title_asc', 'Title (A-Z)'),
        ('title_desc', 'Title (Z-A)')
    ], default='created_at_desc')
    
    def __init__(self, user=None, *args, **kwargs):
        super(SearchForm, self).__init__(*args, **kwargs)
        if user:
            self.category_filter.choices = [(0, 'All Categories')] + [
                (cat.id, cat.name) for cat in user.categories
            ]
        else:
            self.category_filter.choices = [(0, 'All Categories')]