#!/usr/bin/env python3
"""
Local development server runner for Task Management System
"""

import os
import sys
from app import create_app
from models import db

def main():
    """Run the development server"""
    print("=" * 60)
    print("Task Management System - Chapter 10")
    print("=" * 60)
    
    # Create the Flask app
    app = create_app('development')
    
    # Create database tables
    with app.app_context():
        try:
            db.create_all()
            print("✓ Database tables created successfully")
        except Exception as e:
            print(f"✗ Database error: {e}")
            sys.exit(1)
    
    print("\nStarting development server...")
    print("Server will be available at: http://localhost:5000")
    print("\nDemo Account:")
    print("  Email: demo@example.com")
    print("  Password: demo123")
    print("\nPress Ctrl+C to stop the server")
    print("=" * 60)
    
    try:
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=True,
            use_reloader=True
        )
    except KeyboardInterrupt:
        print("\n\nServer stopped by user")
    except Exception as e:
        print(f"\n\nServer error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()