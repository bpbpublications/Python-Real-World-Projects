"""
Database initialization script for the Task Management System
"""

from app import create_app
from models import db, User, Category, Task
from datetime import datetime, timedelta

def init_database():
    """Initialize the database with tables and sample data"""
    app = create_app()
    
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Check if demo user already exists
        demo_user = User.query.filter_by(email='demo@example.com').first()
        
        if not demo_user:
            # Create demo user
            demo_user = User(
                first_name='Demo',
                last_name='User',
                username='demo',
                email='demo@example.com'
            )
            demo_user.set_password('demo123')
            db.session.add(demo_user)
            db.session.commit()
            
            # Create categories for demo user
            categories = [
                Category(name='Work', description='Work-related tasks', color='#007bff', user_id=demo_user.id),
                Category(name='Personal', description='Personal tasks', color='#28a745', user_id=demo_user.id),
                Category(name='Shopping', description='Shopping list items', color='#ffc107', user_id=demo_user.id),
                Category(name='Health', description='Health and fitness tasks', color='#dc3545', user_id=demo_user.id),
                Category(name='Learning', description='Educational and skill development', color='#6f42c1', user_id=demo_user.id)
            ]
            
            for category in categories:
                db.session.add(category)
            
            db.session.commit()
            
            # Create sample tasks for demo user
            work_category = Category.query.filter_by(name='Work', user_id=demo_user.id).first()
            personal_category = Category.query.filter_by(name='Personal', user_id=demo_user.id).first()
            shopping_category = Category.query.filter_by(name='Shopping', user_id=demo_user.id).first()
            health_category = Category.query.filter_by(name='Health', user_id=demo_user.id).first()
            learning_category = Category.query.filter_by(name='Learning', user_id=demo_user.id).first()
            
            sample_tasks = [
                Task(
                    title='Complete project documentation',
                    description='Finish writing the technical documentation for the new feature',
                    status='in_progress',
                    priority='high',
                    due_date=datetime.now() + timedelta(days=3),
                    user_id=demo_user.id,
                    category_id=work_category.id
                ),
                Task(
                    title='Team meeting preparation',
                    description='Prepare agenda and slides for the weekly team meeting',
                    status='pending',
                    priority='medium',
                    due_date=datetime.now() + timedelta(days=1),
                    user_id=demo_user.id,
                    category_id=work_category.id
                ),
                Task(
                    title='Code review for PR #123',
                    description='Review the pull request and provide feedback',
                    status='completed',
                    priority='medium',
                    completed_at=datetime.now() - timedelta(days=1),
                    user_id=demo_user.id,
                    category_id=work_category.id
                ),
                Task(
                    title='Pay electricity bill',
                    description='Monthly electricity bill payment',
                    status='pending',
                    priority='high',
                    due_date=datetime.now() + timedelta(days=5),
                    user_id=demo_user.id,
                    category_id=personal_category.id
                ),
                Task(
                    title='Call dentist for appointment',
                    description='Schedule routine dental checkup',
                    status='pending',
                    priority='low',
                    user_id=demo_user.id,
                    category_id=health_category.id
                ),
                Task(
                    title='Buy groceries',
                    description='Milk, bread, eggs, vegetables, fruits',
                    status='pending',
                    priority='medium',
                    due_date=datetime.now() + timedelta(days=2),
                    user_id=demo_user.id,
                    category_id=shopping_category.id
                ),
                Task(
                    title='Learn Flask tutorial',
                    description='Complete the Flask web development tutorial',
                    status='in_progress',
                    priority='low',
                    user_id=demo_user.id,
                    category_id=learning_category.id
                ),
                Task(
                    title='Gym workout',
                    description='Cardio and strength training session',
                    status='completed',
                    priority='medium',
                    completed_at=datetime.now() - timedelta(hours=2),
                    user_id=demo_user.id,
                    category_id=health_category.id
                ),
                Task(
                    title='Plan weekend trip',
                    description='Research and book accommodation for the weekend getaway',
                    status='pending',
                    priority='low',
                    due_date=datetime.now() + timedelta(days=10),
                    user_id=demo_user.id,
                    category_id=personal_category.id
                ),
                Task(
                    title='Update resume',
                    description='Add recent projects and skills to resume',
                    status='pending',
                    priority='medium',
                    user_id=demo_user.id,
                    category_id=work_category.id
                )
            ]
            
            for task in sample_tasks:
                db.session.add(task)
            
            db.session.commit()
            print("Database initialized successfully!")
            print("Demo user created:")
            print("  Email: demo@example.com")
            print("  Password: demo123")
            print(f"  {len(categories)} categories created")
            print(f"  {len(sample_tasks)} sample tasks created")
        
        else:
            print("Database already initialized.")
            print("Demo user exists:")
            print("  Email: demo@example.com")
            print("  Password: demo123")

if __name__ == '__main__':
    init_database()